#!/usr/bin/env python3
"""Connection diagnosis for the Google-translate bridge."""
import socket
import sys

import requests

import bridge_all as b

HOST = "www-mouser-com.translate.goog"
print("1) DNS lookup:", HOST)
try:
    print("   ->", sorted({a[4][0] for a in socket.getaddrinfo(HOST, 443)}))
except Exception as e:
    print("   FAILED:", e)
    print("   Fix: set DNS to 8.8.8.8 / 8.8.4.4 (see README).")
    sys.exit(1)

print("2) Search request through the bridge")
s = requests.Session()
s.headers.update(b.HDRS)
try:
    r = s.get(b.search_url("GRM1555C1E2R2CA01D"), timeout=40)
except Exception as e:
    print("   FAILED:", type(e).__name__, e)
    sys.exit(1)
print("   status     :", r.status_code)
print("   final url  :", r.url[:120])
print("   redirects  :", [h.status_code for h in r.history])
print("   length     :", len(r.text))
print("   challenge  :", b.is_challenge(r.text))
print("   real Mouser:", b.looks_real(r.text))
m = b.TITLE_RE.search(r.text)
print("   <title>    :", b.clean(m.group(1))[:100] if m else "(none)")

print()
if r.status_code == 200 and b.looks_real(r.text) and not b.is_challenge(r.text):
    print("RESULT: bridge OK - the harvest should work.")
elif r.status_code == 429 or "google.com/sorry" in r.url or b.is_challenge(r.text):
    print("RESULT: Google is rate-limiting your IP (429 / sorry page).")
    print("        Wait 1-4 hours (or try another network), then run again.")
else:
    print("RESULT: bridge returned an unexpected page - send me this output.")
