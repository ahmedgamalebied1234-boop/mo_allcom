#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FAST batch version of the Mouser harvester (built for thousands of URLs).

Speed comes from: one long-lived browser per worker (warm-up once, not per URL),
parallel workers, no per-URL fallback chain / document HEAD-verification / full link
sweep, and results streamed to results.jsonl so an interrupted run RESUMES.

Anti-blocking is done by BEING POLITE, not by evasion: a global pace limit, jittered
timing, adaptive slow-down + exponential cool-down when a challenge appears, a fresh
session after a block, and a stop-and-resume circuit breaker. It never solves CAPTCHAs.

Tuning (env vars):  SAFE=1  WORKERS=2  TARGET_RPM=12  HEADLESS=0  BLOCK_HEAVY=1  FAST_ALL_PANELS=1
"""
import os, sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)


# --- proxy_patch auto-loaded (injected by inject_patch.py) ---
try:
    import proxy_patch; proxy_patch.install()
except Exception as _e:
    print('[proxy_patch] disabled:', _e)
# --- end --- proxy_patch auto-loaded (injected by inject_patch.py) --- end ---

# [2/10] Configuration — edit these for other parts ------------------------------
import os
from datetime import datetime, timezone

# Canonical signed product URL (?qs= token). For other parts, open the product
# page on mouser.com and copy the URL from the address bar.
PART_URL = ("https://www.mouser.com/ProductDetail/STMicroelectronics/"
            "STM32F103C8T6?qs=bhCVus9SdFtq6kqxsU5%2FDA%3D%3D")
PART_HINT = "STM32F103C8T6"            # filenames / sitemap search / fallback queries
MANUFACTURER_HINT = "STMicroelectronics"

RETRY_DELAYS_S = [0, 20, 45]           # backoff chain before declaring access failure
RETRY_JITTER_S = (0.0, 5.0)
NAV_TIMEOUT_MS = 90_000                # per-navigation timeout
POLL_WINDOW_S = 60                     # patient poll: wait out late challenge release
VERIFY_TIMEOUT_S = (10, 25)            # (connect, read) timeouts for HEAD/range probes
RANGE_BYTES = 4096                     # ranged-GET probe size (never full downloads)
BROWSER_VERIFY_CAP = 40                # max ambiguous URLs re-checked via navigation

DOC_PANEL_XPATH = "/html/body/main/div/div/div[2]/div/div[1]/div[2]"   # body of the "Documents (n)" panel
# Panels whose links (with section names) are extracted. Collapsed ones are expanded first.
# (Only "Documents" is needed for the datasheet/models/spec/technical-resources table.)
DOC_PANEL_TITLES = ["Documents", "Environmental Documents", "Product & Trade Compliance"]

MOUSER_ONLY = True                     # scope policy: keep Mouser-hosted documents only
IN_COLAB = False
OUT_DIR = os.path.join(BASE_DIR, "mouser_harvest")
LOCAL_URL_FILE = None   # local run: path to your .xlsx/.csv (default: auto-detect urls.xlsx / U.xlsx / mo.xlsx / urls.csv next to the notebook)
INTER_PART_DELAY_S = 5                 # polite pause between parts in batch mode

# Official Mouser Search API key (free: mouser.com > My Mouser > APIs). Returns
# datasheet URL, lifecycle, RoHS etc. WITHOUT touching the bot-protected web page,
# so it works from Colab/cloud IPs. Put it in Colab Secrets as MOUSER_API_KEY
# (key icon in the left sidebar) or paste it below.
def _get_secret(name):
    v = os.environ.get(name)
    if v:
        return v
    try:
        from google.colab import userdata
        return userdata.get(name)
    except Exception:
        return None

def _read_key_file():
    p = os.path.join(BASE_DIR, "mouser_api_key.txt")
    try:
        with open(p, encoding="utf-8") as fh:
            return fh.read().strip()
    except Exception:
        return ""

MOUSER_API_KEY = (os.environ.get("MOUSER_API_KEY") or _read_key_file() or "").strip()

RUNSTAMP = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print("Config ready.")
print("  target :", PART_URL)
print("  part   :", PART_HINT)
print("  scope  :", "Mouser-hosted resources only" if MOUSER_ONLY else "all hosts")
print("  mouser API key:", "set" if MOUSER_API_KEY else "NOT set (put it in mouser_api_key.txt for a fallback)")
print("  environment:", "Google Colab (datacenter IP - Mouser usually blocks it)" if IN_COLAB else "LOCAL (your own IP)")
print("  output dir :", OUT_DIR)


# [input helpers] Upload an Excel/CSV list of Mouser part URLs to crawl (optional) -------
# Upload a .xlsx / .xls / .csv file with a column of Mouser part URLs.
# Optional extra columns (matched case-insensitively, any of these names):
#   URL column            : "url", "urls", "part_url", "mouser_url", "link"
#   part-hint column      : "part_hint", "part", "mpn", "part_number"
#   manufacturer column   : "manufacturer_hint", "manufacturer", "mfr", "brand"
# If none of the URL-like column names match, the first column is used.
# If you skip/cancel the upload dialog, the notebook falls back to the single
# PART_URL / PART_HINT / MANUFACTURER_HINT set in the configuration cell above.
import re
import pandas as pd


def _pick_col(df, candidates):
    cols = {str(c).lower().strip(): c for c in df.columns}
    for cand in candidates:
        if cand in cols:
            return cols[cand]
    return None


def _cell(row, col):
    if not col:
        return None
    val = row.get(col)
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    val = str(val).strip()
    return val or None


def _fix_double_encoded_qs(u):
    """Collapse doubly percent-encoded qs tokens (%252B -> %2B).

    Some spreadsheets export Mouser links with the '+' inside the signed token
    encoded twice. Mouser never redirects away, so the wrong token silently
    reaches the edge; the corrected single-encoded form renders correctly.
    """
    m = re.search(r"((?:^|&)qs=)([^&]+)", u)
    if m and "%25" in m.group(2):
        return u[:m.start()] + m.group(1) + re.sub(r"%25([0-9A-Fa-f]{2})", r"%\1", m.group(2)) + u[m.end():]
    return u


def _slug_hints(u):
    """Derive (part_hint, manufacturer_hint) from a ProductDetail URL slug."""
    m = re.search(r"/ProductDetail/([^/]+)/([^/?#]+)", u or "")
    if not m:
        return None, None
    from urllib.parse import unquote
    return unquote(m.group(2)), unquote(m.group(1)).replace("-", " ")



# [3/10] Core helpers — URL normalization, dedupe, classification, part ID -------
import html as html_mod
import re
from collections import Counter, OrderedDict
from urllib.parse import parse_qsl, urldefrag, urljoin, urlencode, urlparse, urlunsplit

# --- regex sweep patterns (second-chance harvest outside plain anchors) --------
HREF_LIKE = re.compile(
    r'(?:href|src|action|poster|data-url|data-href|data-link|data-src|data-file'
    r'|data-document|data-download)\s*=\s*["\']([^"\']{4,2000})["\']', re.I)
JSON_URL = re.compile(r'"[^"]*(?:url|Url|URL)[^"]*"\s*:\s*"([^"\\]{4,2000})"')
LITERAL = re.compile(r'https?://[^\s"\'<>\\)\}\]]+', re.I)

LIKELY_DOC_PATH_PATTERNS = [
    ".pdf", "/pcn/", "/pcn", "/pdn/", "/eol/", "/documents/", "/document/",
    "/datasheet/", "/download/", "/downloads/", "/faq/", "/environmental/",
    "/compliance/", "/technical/", "/manufacturer/",
]

CATEGORY_RULES = OrderedDict([
    ("datasheet", [r"datasheet", r"data[-\s]sheet"]),
    ("pcn", [r"\bpcn\b", r"product[-\s]change[-\s]notifications?",
             r"product[-\s]change[-\s]notices?"]),
    ("pdn_eol", [r"\bpdn\b", r"\beol\b", r"end[-\s]of[-\s]life", r"discontinuation",
                 r"last[-\s]time[-\s]buy"]),
    ("faq", [r"\bfaqs?\b", r"frequently[-\s]asked"]),
    ("environmental_compliance", [
        r"rohs", r"\breach\b", r"conflict[-\s]minerals?", r"material[-\s]declaration",
        r"environmental", r"\bsvhc\b", r"proposition[-\s]65", r"\bmsds\b", r"\bsds\b",
        r"compliance", r"export[-\s]class"]),
    ("reliability_qualification", [r"reliabilit", r"qualific", r"\bmtbf\b", r"quality"]),
    ("application_technical", [
        r"application[-\s]notes?", r"\bapp[-\s]notes?\b",
        r"technical[-\s](?:document|brief|paper|note)", r"white[-\s]paper",
        r"user[-\s](?:manual|guide)", r"reference[-\s]manual",
        r"programming[-\s]manual", r"getting[-\s]started"]),
    ("safety_regulatory", [r"safety", r"regulatory", r"certificat"]),
])

SECTION_KEYWORDS = [
    "Datasheet", "PCN", "Product Change Notification", "PDN", "EOL", "End of Life",
    "FAQ", "Environmental", "RoHS", "REACH", "Conflict Minerals", "Material Declaration",
    "Compliance", "Application Note", "Reliability", "Qualification",
    "Manufacturer Part Details", "Manufacturer Details", "Manufacturer Resources",
    "Manufacturer Website", "Technical Resources", "Additional Documents",
    "Related Documents", "Resources", "Support",
]

# Tracking params dropped during normalization (signed tokens like ?qs= are kept)
TRACKING_PARAMS = {"srsltid", "spm", "gclid", "fbclid", "mc_cid", "mc_eid", "ref"}


def _strip_tracking(u):
    """Remove tracking params (utm_*, srsltid, ...) if present; else return u."""
    try:
        parts = urlparse(u)
        if not parts.query:
            return u
        pairs = parse_qsl(parts.query, keep_blank_values=True)
        kept = [(k, v) for k, v in pairs
                if k.lower() not in TRACKING_PARAMS
                and not k.lower().startswith("utm_")]
        if len(kept) == len(pairs):
            return u
        return urlunsplit((parts.scheme, parts.netloc, parts.path,
                           urlencode(kept), parts.fragment))
    except Exception:
        return u


def normalize_url(raw, base_url=None):
    """Normalize any discovered URL candidate to an absolute http(s) URL.

    Handles JSON-escaped forms (backslash-slash, u002F), HTML entities,
    protocol-relative URLs, relative paths, and trailing punctuation.
    """
    if raw is None:
        return None
    u = str(raw).strip()
    if not u or len(u) > 2000:
        return None
    u = u.replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/")
    u = u.replace("\\u0026", "&").replace("\\", "")
    u = html_mod.unescape(u)
    u = re.split(r'["<>\s]', u, maxsplit=1)[0]   # drop regex-sweep debris after a stray quote
    if u.startswith("//"):
        u = "https:" + u
    low = u.lower()
    if low.startswith(("mailto:", "tel:", "javascript:", "about:", "data:", "#")):
        return None
    if not low.startswith(("http://", "https://")):
        if not base_url:
            return None
        # reject obvious junk, allow query-bearing relative paths
        if re.search(r'[\s"\'<>\\^`{}|\[\]]', u):
            return None
        try:
            u = urljoin(base_url, u)
        except Exception:
            return None
    try:
        parts = urlparse(u)
    except Exception:
        return None
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return None
    u = _strip_tracking(u)
    u = u.rstrip('.,;:!\'"')
    while u.endswith(")") and u.count("(") < u.count(")"):
        u = u[:-1]
    return u


def regex_sweep(rendered_html, base_url):
    """Sweep rendered HTML for URL candidates outside plain anchors."""
    hits = []
    if not rendered_html:
        return hits
    for m in HREF_LIKE.finditer(rendered_html):
        hits.append((m.group(1), "html_attr"))
    for m in JSON_URL.finditer(rendered_html):
        hits.append((m.group(1), "json_key"))
    flat = (rendered_html.replace("\\/", "/").replace("\\u002F", "/")
            .replace("\\u002f", "/").replace('\\"', '"'))
    for m in LITERAL.finditer(flat):
        hits.append((m.group(0), "literal"))
    return hits


def merge_links(dom_links, regex_hits, base_url):
    """Normalize + deduplicate every candidate into one unique-URL inventory."""
    merged = {}

    def put(raw, source, anchor="", hint=""):
        nu = normalize_url(raw, base_url)
        if not nu:
            return
        # scheme-insensitive identity: http/https variants collapse to one record
        p0 = urlparse(urldefrag(nu)[0])
        identity = urlunsplit(("https", p0.netloc, p0.path, p0.query, ""))
        rec = merged.get(identity)
        if rec is None:
            rec = {"url": nu, "identity": identity, "anchors": [], "hints": [],
                   "sources": []}
            merged[identity] = rec
        else:
            cur = urlparse(rec["url"])
            new = urlparse(nu)
            if new.scheme == "https" and cur.scheme != "https":
                rec["url"] = nu
        if anchor and anchor not in rec["anchors"] and len(rec["anchors"]) < 5:
            rec["anchors"].append(anchor)
        if hint and hint not in rec["hints"] and len(rec["hints"]) < 3:
            rec["hints"].append(hint)
        if source and source not in rec["sources"]:
            rec["sources"].append(source)

    for item in dom_links or []:
        put(item.get("url"), item.get("source") or "dom",
            item.get("anchor") or "", item.get("hint") or "")
    for raw, source in regex_hits or []:
        put(raw, source)
    return list(merged.values())


def host_of(u):
    try:
        return (urlparse(u).netloc or "").lower()
    except Exception:
        return ""


# Mouser-owned country mirrors: mouser.de, mouser.co.uk, mouser.com.tr, ...
MOUSER_MIRROR_HOST_RE = re.compile(r"^(?:www\.)?mouser\.[a-z]{2,3}(?:\.[a-z]{2,3})?$")


def is_mouser(u):
    """Scope-policy test: hosted on a Mouser-owned domain.

    True for the mouser.com family (mouser.com, eu.mouser.com, ar.mouser.com,
    sub.info.mouser.com, ...) and for Mouser country mirrors (mouser.de,
    www.mouser.at, mouser.co.uk, ...). False for lookalikes (evil-mouser.com)
    and for everything non-Mouser (st.com, snapeda.com, ...).
    """
    h = host_of(u)
    if h == "mouser.com" or h.endswith(".mouser.com"):
        return True
    return bool(MOUSER_MIRROR_HOST_RE.match(h))


def same_part_product_url(u, part):
    """True if u is a product-detail page for the same part on any Mouser
    domain (canonical, locale variant, or country mirror) — i.e. a duplicate
    of the canonical page rather than a distinct document.

    The part must match a full path segment: STM32F103C8T6TR (tape-and-reel,
    a distinct product) is NOT matched when part is STM32F103C8T6.
    """
    seg = re.escape(str(part or "").lower())
    try:
        p = urlparse(u or "")
    except Exception:
        return False
    path = (p.path or "").lower()
    return bool(re.search(rf"/productdetail/[^/]+/{seg}(?:/|$)", path))


def classify(record, mfr_name=None):
    """Return (category, likely_document, is_manufacturer) for a link record."""
    p = urlparse(record["url"])
    path = (p.path or "").lower()
    host = (p.netloc or "").lower()
    anchor_str = " ".join(record.get("anchors") or []).lower()
    hint_str = " ".join(record.get("hints") or []).lower()
    hay = " | ".join(x for x in (anchor_str, hint_str, path) if x)
    cat = None
    for category, pats in CATEGORY_RULES.items():
        for pat in pats:
            if re.search(pat, hay):
                cat = category
                break
        if cat:
            break
    is_mfr = False
    if mfr_name:
        slug = mfr_name.lower()
        if slug in host or slug in hay:
            is_mfr = True
    if cat is None and is_mfr:
        cat = "manufacturer_resource"
    likely = any(pat in path for pat in LIKELY_DOC_PATH_PATTERNS) or path.endswith(".pdf")
    if cat is None and likely:
        cat = "other_document"
    return cat, likely, is_mfr


def identify_part(page_text, url):
    """Pull Manufacturer / MPN from page text, fall back to URL slug."""
    ident = {"manufacturer": None, "mpn": None, "description": None, "method": None}
    if page_text:
        m = re.search(r"Manufacturer\s*(?:Part\s*Details|Details)?\s*[:\r\n]+\s*"
                      r"([A-Za-z][A-Za-z0-9 .&/\-()']{1,60})", page_text)
        if m:
            ident["manufacturer"] = m.group(1).strip().rstrip(".")
        m = re.search(r"(?:Manufacturer\s*Product\s*Number|Manufacturer\s*Part\s*"
                      r"(?:Number|No\.?)|Mfr\.?\s*(?:Part\s*)?(?:Number|#))\s*[:#]?\s*"
                      r"([A-Z0-9][A-Z0-9._/\-]{2,40})", page_text)
        if m:
            ident["mpn"] = m.group(1).strip()
        m = re.search(r"(?:Product|Part)\s*(?:Description|Detail)\s*[:\r\n]+\s*"
                      r"([^\r\n]{5,120})", page_text)
        if m:
            ident["description"] = m.group(1).strip()
        if ident["manufacturer"] or ident["mpn"]:
            ident["method"] = "page_text"
    pm = re.search(r"/ProductDetail/([^/]+)/([^/?#]+)", url or "")
    if pm:
        if not ident["manufacturer"]:
            ident["manufacturer"] = pm.group(1)
            ident["method"] = "url_slug"
        if not ident["mpn"]:
            ident["mpn"] = pm.group(2)
            ident["method"] = "url_slug"
    return ident


def section_presence(page_text):
    """Which required sections/topics appear in the page text."""
    found = {}
    low = (page_text or "").lower()
    for kw in SECTION_KEYWORDS:
        found[kw] = kw.lower() in low
    return found


print("Core helpers ready "
      f"({len(CATEGORY_RULES)} document categories, mouser-only test active).")


# [4/10] In-page extraction JS (runs inside the rendered page) --------------------
# STATE_JS  : compact page-state probe (text length + challenge fingerprints)
# EXTRACT_JS: full-text + complete link inventory in one pass
# SCROLL_JS : progressive scroll to trigger lazy-loaded sections
STATE_JS = r"""
() => ({
    len: document.body ? document.body.innerText.length : -1,
    product: !!(document.body && /Mouser No\s*:|Mfr\. No\s*:/i.test(document.body.innerText)),
    hasAkam: !!(document.querySelector('script[src*="/akam/"]') ||
                (document.body && document.body.innerHTML.includes('bazadebezolkohpepadr'))),
    hasDD: !!(document.querySelector('script[src*="captcha-delivery.com"]') ||
              (document.body && document.body.innerHTML.includes('dd={')))
})
"""


def _page_ready(s):
    """Real product page = has 'Mouser No:' / 'Mfr. No:' (a full page is only ~2.4k chars,
    so a text-length threshold alone never fires). Otherwise fall back to length + no challenge."""
    return bool(s.get("product")) or (s.get("len", 0) > 3000 and not s.get("hasAkam") and not s.get("hasDD"))


EXTRACT_JS = r"""
() => {
  const out = { text: '', links: [], canonical: '' };
  const seen = new Set();
  const baseURI = document.baseURI || location.href;
  const abs = (u) => { try { return new URL(u, baseURI).href; } catch (e) { return null; } };
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  const hintFor = (el) => {
    let node = el;
    for (let i = 0; i < 5 && node; i++) {
      let sib = node.previousElementSibling;
      let depth = 0;
      while (sib && depth < 3) {
        if (/^H[1-4]$/i.test(sib.tagName)) return clean(sib.textContent);
        sib = sib.previousElementSibling; depth++;
      }
      node = node.parentElement;
    }
    return '';
  };
  const add = (raw, anchor, source, hint) => {
    if (!raw) return;
    const a = abs(raw);
    if (!a || !/^https?:/i.test(a)) return;
    const key = a.split('#')[0];
    if (seen.has(key)) return;
    seen.add(key);
    out.links.push({ url: a, anchor: clean(anchor), source: source, hint: hint || '' });
  };
  document.querySelectorAll('a[href]').forEach((el) => {
    const anchor = el.innerText || el.textContent || el.getAttribute('aria-label')
      || el.title || el.getAttribute('name') || '';
    add(el.getAttribute('href'), anchor, 'a[href]', hintFor(el));
  });
  document.querySelectorAll('area[href]').forEach((el) =>
    add(el.getAttribute('href'), el.alt, 'area[href]', hintFor(el)));
  document.querySelectorAll('iframe[src],frame[src],embed[src],object[data],source[src]')
    .forEach((el) =>
      add(el.getAttribute('src') || el.getAttribute('data'), '',
          el.tagName.toLowerCase(), ''));
  const canonicalEl = document.querySelector('link[rel="canonical"]');
  if (canonicalEl) {
    try { out.canonical = new URL(canonicalEl.getAttribute('href'), baseURI).href; }
    catch (e) {}
  }
  const dataUrlRe = /url|href|link|file|document|download|pdf|datasheet|doc/i;
  document.querySelectorAll('*').forEach((el) => {
    const attrs = el.attributes;
    if (!attrs) return;
    for (let i = 0; i < attrs.length; i++) {
      const attr = attrs[i];
      const name = attr.name.toLowerCase();
      if (!name.startsWith('data-') || !dataUrlRe.test(name)) continue;
      const v = (attr.value || '').trim();
      if (v.length > 8 && v.length < 2000 &&
          (/^https?:\/\//i.test(v) || v.startsWith('/'))) {
        add(v, el.innerText || el.getAttribute('aria-label') || '',
            'data:' + name, hintFor(el));
      }
    }
  });
  document.querySelectorAll('[onclick],button,[role=button]').forEach((el) => {
    const oc = (el.getAttribute('onclick') || '') + ' ' +
               (el.getAttribute('data-onclick') || '');
    const m = oc.match(/https?:\/\/[^"'\s)<>]+|\/[A-Za-z0-9_\-\/.%]+\.(?:pdf|aspx|ashx|html?)/g);
    if (m) m.forEach((u) => add(u, el.innerText || '', 'onclick', hintFor(el)));
  });
  out.text = document.body ? document.body.innerText : '';
  return out;
}
"""

SCROLL_JS = r"""
async () => {
  await new Promise((resolve) => {
    let y = 0;
    const step = () => {
      y += 900;
      window.scrollTo(0, y);
      const max = (document.body ? document.body.scrollHeight : y) + 900;
      if (y < max) { setTimeout(step, 250); }
      else { window.scrollTo(0, 0); setTimeout(resolve, 400); }
    };
    step();
  });
}
"""

DOC_PANEL_JS = r"""
(cfg) => {
  const out = { xpath: cfg.xpath, xpath_hit: false, panels: [], rows: [], log: [] };
  const baseURI = document.baseURI || location.href;
  const abs = (u) => { try { return new URL(u, baseURI).href; } catch (e) { return null; } };
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const byXp = (x) => { try { return document.evaluate(x, document, null, 9, null).singleNodeValue; } catch (e) { return null; } };
  const HEAD_TAGS = /^(H[1-6]|DT|LEGEND|STRONG|B|EM|I|TH|CAPTION)$/;
  const SKIP_TEXT = /^(filter document:?|choose a document type|documents?\s*\(\d+\))$/i;
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'OPTION', 'SELECT', 'NOSCRIPT', 'SVG', 'PATH', 'svg', 'path']);
  const ALL_TITLES = Array.from(new Set([...(cfg.titles || []), 'Documents', 'More Information']));

  const headingRe = (t) => new RegExp('^' + esc(t) + '(\\s*\\(\\d+\\))?$', 'i');
  const findHeading = (title) => {
    const re = headingRe(title);
    let best = null;
    document.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,legend,summary,label,p').forEach((el) => {
      if (!re.test(clean(el.textContent))) return;
      if (Array.from(el.children).some((c) => re.test(clean(c.textContent)))) return; // deepest match only
      best = best || el;
    });
    return best;
  };
  const headingsInside = (node) => ALL_TITLES.filter((t) => {
    const re = headingRe(t);
    return Array.from(node.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,legend,summary,label,p'))
      .some((el) => re.test(clean(el.textContent)) && !Array.from(el.children).some((c) => re.test(clean(c.textContent))));
  }).length;

  const walk = (container, panelName) => {
    let section = '';
    const seen = new Set();
    let n = 0;
    container.querySelectorAll('*').forEach((el) => {
      if (SKIP_TAGS.has(el.tagName) || el.closest('select')) return;
      if (el.tagName === 'A') {
        let raw = el.getAttribute('href') || '';
        if (!raw || /^(javascript:|#|mailto:|tel:)/i.test(raw.trim())) {
          raw = el.getAttribute('data-href') || el.getAttribute('data-url') || '';
        }
        const url = raw ? abs(raw) : null;
        if (!url || !/^https?:/i.test(url)) return;
        const name = clean(el.innerText || el.textContent) || clean(el.getAttribute('aria-label')) || clean(el.getAttribute('title'));
        const key = panelName + '|' + section + '|' + url;
        if (seen.has(key)) return;
        seen.add(key);
        out.rows.push({ panel: panelName, section: section, name: name, url: url,
                        opens_new_tab: (el.getAttribute('target') || '') === '_blank' });
        n++;
        return;
      }
      if (el.closest('a') || el.querySelector('a')) return;
      const text = clean(el.textContent);
      if (!text || text.length > 80 || SKIP_TEXT.test(text)) return;
      let italic = false;
      try { italic = getComputedStyle(el).fontStyle === 'italic'; } catch (e) {}
      if (italic || HEAD_TAGS.test(el.tagName)) section = text;
    });
    return n;
  };

  const usable = (node) => node && node !== document.body && node.tagName !== 'MAIN' &&
                           node.tagName !== 'HTML' && node.querySelectorAll('a[href]').length > 0 &&
                           node.querySelectorAll('a[href]').length < 150;

  // 1) Documents panel via the configured XPath (with 2 parent levels of tolerance)
  let docsDone = false;
  const xnode = cfg.xpath ? byXp(cfg.xpath) : null;
  if (xnode) {
    out.xpath_hit = true;
    let cand = xnode;
    for (let i = 0; i < 3 && cand; i++, cand = cand.parentElement) {
      if (usable(cand) && headingsInside(cand) <= 1) {
        const n = walk(cand, 'Documents');
        out.panels.push({ panel: 'Documents', via: 'xpath' + (i ? '+parent' + i : ''), links: n });
        docsDone = true;
        break;
      }
    }
    if (!docsDone) out.log.push('xpath node found but no usable link container');
  } else if (cfg.xpath) {
    out.log.push('xpath not found on this page');
  }

  // 2) heading-based fallback for every requested panel
  (cfg.titles || []).forEach((title) => {
    if (title.toLowerCase() === 'documents' && docsDone) return;
    const h = findHeading(title);
    if (!h) { out.log.push('heading not found: ' + title); return; }
    let node = h.parentElement, hops = 0;
    while (node && hops < 8) {
      if (usable(node) && headingsInside(node) <= 1) {
        const n = walk(node, title);
        out.panels.push({ panel: title, via: 'heading', links: n });
        return;
      }
      node = node.parentElement; hops++;
    }
    out.log.push('no link container found for: ' + title);
  });
  return out;
}
"""

EXPAND_JS = r"""
(titles) => {
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const clicked = [];
  (titles || []).forEach((t) => {
    if (/^documents$/i.test(t)) return;                    // already open by default
    const re = new RegExp('^' + esc(t) + '(\\s*\\(\\d+\\))?$', 'i');
    let best = null;
    document.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,summary,legend').forEach((el) => {
      if (!re.test(clean(el.textContent))) return;
      if (Array.from(el.children).some((c) => re.test(clean(c.textContent)))) return;
      best = best || el;
    });
    if (!best) return;
    const trg = best.closest('button,[role="button"],[aria-expanded],[data-toggle],[data-bs-toggle],summary') || best;
    if (trg.getAttribute('aria-expanded') === 'true') return;
    try { trg.click(); clicked.push(t); } catch (e) {}
  });
  return clicked;
}
"""

print("Extraction JS ready (state probe / full extractor / lazy-load scroller).")


# [5/10] Camoufox renderer — recipe validated against Mouser's Akamai + DataDome --
import time

from playwright.sync_api import TimeoutError as PWTimeoutError
from camoufox.sync_api import Camoufox

try:
    from camoufox.addons import DefaultAddons
    EXCLUDE_ADDONS = [DefaultAddons.UBO]   # uBlock Origin filtering breaks the sensor
except Exception:
    EXCLUDE_ADDONS = []

HEADLESS_MODE = os.environ.get("HEADLESS", "1") != "0"  # set HEADLESS=0 to watch the browser                        # validated: plain headless works

WARMUP_URL = "https://www.mouser.com/"

BLOCK_MARKERS = [
    "access denied", "access to this page has been denied", "attention required",
    "captcha", "are you a human", "please verify", "verify you are",
    "unusual traffic", "request unsuccessful", "incapsula", "datadome",
    "perimeterx", "px-captcha", "cloudflare", "just a moment", "cf-chl",
    "request blocked", "security check", "bot detection", "you have been blocked",
]


def _render_body(browser, url, nav_timeout_ms, warmup, result):
    """Everything that happens once the browser is up."""
    page = browser.new_page()
    if warmup and "mouser.com" in (url or "").lower():
        try:
            page.goto(WARMUP_URL, wait_until="domcontentloaded", timeout=60000,
                      referer="https://www.google.com/")
            t0 = time.time()
            while time.time() - t0 < 30:
                time.sleep(2.5)
                s = page.evaluate(STATE_JS)
                if s["len"] > 2000 and not s["hasAkam"] and not s["hasDD"]:
                    break
        except Exception as exc:
            result["errors"].append(f"warmup skipped: {type(exc).__name__}: {str(exc)[:300]}")
    resp = page.goto(url, wait_until="domcontentloaded", timeout=nav_timeout_ms,
                     referer=WARMUP_URL)
    result["http_status"] = getattr(resp, "status", None) if resp else None
    t0 = time.time()
    s = {"len": -1, "hasAkam": False, "hasDD": False}
    while time.time() - t0 < POLL_WINDOW_S:
        time.sleep(2.5)
        try:
            s = page.evaluate(STATE_JS)
        except Exception:
            continue
        if _page_ready(s):
            break
    result["challenge_flags"] = {k: s[k] for k in ("hasAkam", "hasDD") if k in s}
    try:
        page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        result["errors"].append("networkidle not reached (continuing with settled DOM)")
    page.wait_for_timeout(2500)
    try:
        page.evaluate(SCROLL_JS)
    except Exception as exc:
        result["errors"].append(f"scroll failed: {exc}")
    page.wait_for_timeout(2000)
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    try:
        clicked = page.evaluate(EXPAND_JS, DOC_PANEL_TITLES)
        if clicked:
            page.wait_for_timeout(2000)
        result["doc_panels"] = page.evaluate(
            DOC_PANEL_JS, {"xpath": DOC_PANEL_XPATH, "titles": DOC_PANEL_TITLES})
        result["doc_panels"]["expanded"] = clicked
    except Exception as exc:
        result["errors"].append(f"document panel extraction failed: {exc}")
    data = page.evaluate(EXTRACT_JS)
    result["page_text"] = data.get("text") or ""
    result["dom_links"] = data.get("links") or []
    result["canonical"] = data.get("canonical") or None
    result["final_url"] = page.url
    result["title"] = page.title()
    try:
        result["user_agent"] = page.evaluate("navigator.userAgent")
    except Exception:
        pass
    result["rendered_html"] = page.content()


def render_page(url, nav_timeout_ms=None, warmup=True):
    """Load `url` in Camoufox, render fully, return extraction dict.

    Adds `failure_kind` so callers can tell WHY nothing came back:
      launch_error  - the browser itself never started (setup problem, not a block)
      timeout       - navigation timed out, no response
      no_response   - navigation failed at network level (reset/refused/DNS)
      challenge     - page loaded but shows a bot-challenge / block page
      None          - rendered fine
    """
    if nav_timeout_ms is None:
        nav_timeout_ms = NAV_TIMEOUT_MS
    result = {
        "requested_url": url, "final_url": None, "http_status": None,
        "title": None, "user_agent": None, "canonical": None,
        "page_text": None, "dom_links": [], "rendered_html": None,
        "blocked": False, "block_evidence": [], "errors": [],
        "challenge_flags": {}, "failure_kind": None, "doc_panels": None,
    }
    launched = False
    # geoip=True needs an extra lookup + DB download; if the browser fails to
    # START with it, retry once without it instead of silently returning nothing.
    for use_geoip in (True, False):
        try:
            with Camoufox(headless=HEADLESS_MODE, humanize=True, locale=["en-US"],
                          geoip=use_geoip, exclude_addons=EXCLUDE_ADDONS) as browser:
                launched = True
                _render_body(browser, url, nav_timeout_ms, warmup, result)
            break
        except PWTimeoutError as exc:
            result["errors"].append(f"navigation timeout: {str(exc)[:300]}")
            break
        except Exception as exc:
            result["errors"].append(
                f"{'render' if launched else 'launch'} failure "
                f"(geoip={use_geoip}): {type(exc).__name__}: {str(exc)[:400]}")
            if launched:
                break

    errs = " ".join(result["errors"]).lower()
    if not launched:
        result["failure_kind"] = "launch_error"
    elif result["http_status"] is None and not (result["page_text"] or "").strip():
        result["failure_kind"] = "timeout" if "timeout" in errs else "no_response"

    text_now = (result.get("page_text") or "")
    has_product = bool(re.search(r"Mouser No\s*:|Mfr\. No\s*:", text_now))   # real content present
    hay = (text_now[:4000] + " " + (result.get("title") or "")).lower()
    if len(text_now) < 5000 and not has_product:            # avoid false positives on full product pages
        for marker in BLOCK_MARKERS:
            if marker in hay:
                result["blocked"] = True
                result["block_evidence"].append(f"text marker: {marker!r}")
    flags = result.get("challenge_flags") or {}
    if flags.get("hasAkam") and not has_product:
        result["blocked"] = True
        result["block_evidence"].append("Akamai challenge still present after poll window")
    if flags.get("hasDD") and not has_product:
        result["blocked"] = True
        result["block_evidence"].append(
            "DataDome captcha-delivery assets still present after poll window")
    if result["http_status"] in (401, 403, 429, 503):
        result["blocked"] = True
        result["block_evidence"].append(f"http status {result['http_status']}")
    text_len = len(text_now.strip())
    if text_len < 300:
        result["blocked"] = True
        result["block_evidence"].append(f"rendered text too short ({text_len} chars)")
    if result["blocked"] and not result["failure_kind"]:
        result["failure_kind"] = "challenge"
    return result


print("Renderer ready — Camoufox", "(UBO excluded)" if EXCLUDE_ADDONS else "(default addons)",
      "| headless:", HEADLESS_MODE)


# [6/10] Verification — HEAD + 4 KB ranged GET, then browser re-check -------------
# Mouser's edge masks content-type on HEAD probes (uniform text/html), so any
# ambiguous result is re-checked by direct navigation inside the Camoufox
# context (clearance cookies + real TLS fingerprint). Never full downloads.
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

VERIFY_UA = ("Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0")


def verify_url(session, url, ua, referer):
    """HEAD first, then 4 KB ranged GET. Never downloads full documents."""
    headers = {
        "User-Agent": ua or VERIFY_UA,
        "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9",
    }
    if referer:
        headers["Referer"] = referer
    rec = {"url": url, "method": None, "status": None, "ok": False,
           "content_type": None, "length_hint": None, "final_url": None, "error": None}
    for method in ("head", "get_range"):
        try:
            if method == "head":
                r = session.head(url, headers=headers, timeout=VERIFY_TIMEOUT_S,
                                 allow_redirects=True)
            else:
                h2 = dict(headers)
                h2["Range"] = f"bytes=0-{RANGE_BYTES - 1}"
                r = session.get(url, headers=h2, timeout=VERIFY_TIMEOUT_S,
                                allow_redirects=True, stream=True)
                r.close()
            rec["method"] = method
            rec["status"] = r.status_code
            rec["final_url"] = str(r.url)
            rec["content_type"] = r.headers.get("Content-Type")
            rec["length_hint"] = r.headers.get("Content-Range") or r.headers.get("Content-Length")
            if r.status_code < 400:
                rec["ok"] = True
                break
        except Exception as exc:
            rec["error"] = f"{type(exc).__name__}: {exc}"
    return rec


def verify_all(targets, ua, referer, workers=4):
    """Verify a list of URLs concurrently. Returns {url: record}."""
    out = {}
    with requests.Session() as s:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(verify_url, s, u, ua, referer): u for u in targets}
            for f in as_completed(futs):
                rec = f.result()
                out[futs[f]] = rec
    return out


def ambiguous(rec):
    """Needs a real browser re-check? (not OK, or content-type edge-masked)"""
    if not rec or not rec.get("ok"):
        return True
    ct = (rec.get("content_type") or "").lower()
    return ct.startswith("text/html")


def browser_verify(urls, referer, cap=None):
    """Navigate each URL in the Camoufox context and record true status/type.

    This mirrors the validated finding: direct navigation to Mouser-hosted
    PDF/image URLs returns real 200 + application/pdf responses even when
    HEAD probes are content-type masked by the edge.
    """
    if cap is None:
        cap = BROWSER_VERIFY_CAP
    results = {}
    todo = list(dict.fromkeys(urls))[:cap]
    if not todo:
        return results
    kw = dict(headless=HEADLESS_MODE, humanize=True, locale=["en-US"], geoip=True)
    if EXCLUDE_ADDONS:
        kw["exclude_addons"] = EXCLUDE_ADDONS
    with Camoufox(**kw) as browser:
        ctx = browser.new_context()
        page = ctx.new_page()
        for i, u in enumerate(todo, 1):
            rec = {"url": u, "method": "browser-navigation", "status": None,
                   "content_type": None, "ok": False, "error": None}
            try:
                resp = page.goto(u, wait_until="domcontentloaded", timeout=45000,
                                 referer=referer)
                rec["status"] = resp.status if resp else None
                if resp:
                    rec["content_type"] = resp.headers.get("content-type")
                rec["ok"] = bool(rec["status"] and rec["status"] < 400)
            except Exception as exc:
                rec["error"] = f"{type(exc).__name__}: {exc}"[:200]
            results[u] = rec
            print(f"   [{i}/{len(todo)}] HTTP {rec['status']} {rec['content_type']} {u[:90]}")
        ctx.close()
    return results


print("Verification ready (HEAD + 4KB ranged GET -> browser navigation re-check).")


# [7/10] Fallback routes — robots.txt/sitemap.xml + Mouser-only web discovery -----
import re
import time
import urllib.parse as up

import requests


def sitemap_locate(part_number, session, max_sitemaps=6, max_children=12,
                   cap_bytes=30_000_000):
    """Best-effort: robots.txt -> declared sitemaps -> locate canonical part URLs.

    Note: Mouser has been observed serving an HTML block page instead of
    robots.txt. This route is attempted per spec but may be unusable; the
    attempt itself is recorded as evidence either way.
    """
    findings = {"robots_status": None, "sitemaps_declared": [], "checked": [],
                "candidate_urls": [], "notes": []}
    ua = {"User-Agent": VERIFY_UA}
    try:
        r = session.get("https://www.mouser.com/robots.txt", headers=ua, timeout=20)
        findings["robots_status"] = r.status_code
        ct = (r.headers.get("Content-Type") or "").lower()
        if r.status_code == 200 and "html" not in ct:
            findings["sitemaps_declared"] = re.findall(
                r"(?im)^sitemap:\s*(\S+)", r.text)[:10]
        elif r.status_code == 200:
            findings["notes"].append(
                "robots.txt returned an HTML page (block page) - route unusable")
    except Exception as exc:
        findings["notes"].append(f"robots.txt fetch failed: {exc}")
        return findings
    queue = list(findings["sitemaps_declared"])[:max_sitemaps]
    seen = set()
    pat = re.compile(re.escape(part_number or "___"), re.I)
    while queue and len(findings["checked"]) < max_sitemaps + max_children:
        sm = queue.pop(0)
        if sm in seen:
            continue
        seen.add(sm)
        try:
            r = session.get(sm, headers=ua, timeout=30, stream=True)
            data = b""
            for chunk in r.iter_content(65536):
                data += chunk
                if len(data) > cap_bytes:
                    findings["notes"].append(f"{sm}: truncated at {cap_bytes}B")
                    break
            r.close()
            findings["checked"].append({"url": sm, "status": r.status_code,
                                        "bytes": len(data)})
            text = data.decode("utf-8", "ignore")
            if "<sitemapindex" in text.lower():
                children = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", text)
                queue.extend(children[:max_children])
            else:
                for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", text):
                    if pat.search(loc) and "productdetail" in loc.lower():
                        findings["candidate_urls"].append(loc)
                        if len(findings["candidate_urls"]) >= 10:
                            return findings
        except Exception as exc:
            findings["notes"].append(f"{sm}: {exc}")
    return findings


DDG_ENDPOINT = "https://html.duckduckgo.com/html/"


def web_discover_mouser(part, max_results=30):
    """Public web-search discovery, keeping Mouser-hosted URLs only (scope policy).

    Finds canonical signed product URLs, regional mirrors (eu.mouser.com), and
    Mouser CDN document URLs (mouser.com/datasheet/..., /PCN/..., /catalog/...).
    """
    found = []
    queries = [f'"{part}" site:mouser.com', f'"{part}" mouser.com datasheet pdf']
    for q in queries:
        print("   Q:", q)
        try:
            r = requests.get(DDG_ENDPOINT, params={"q": q},
                             headers={"User-Agent": VERIFY_UA,
                                      "Referer": "https://duckduckgo.com/"},
                             timeout=30)
        except Exception as exc:
            print("     search error:", exc)
            continue
        for m in re.finditer(r'uddg=([^&"\']+)', r.text):
            nu = normalize_url(up.unquote(m.group(1)), None)
            if nu and is_mouser(nu):
                found.append(nu)
        for m in LITERAL.finditer(r.text):
            nu = normalize_url(m.group(0), None)
            if nu and is_mouser(nu):
                found.append(nu)
        time.sleep(2)
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out[:max_results]


def _norm_pn(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def mouser_api_lookup(part_number, api_key, timeout=30):
    """Official Mouser Search API lookup (no web-page scraping, no bot wall).

    Returns {"ok", "matched_part", "links", "errors", "raw_count"}.
    `links` are dicts shaped like DOM links so merge_links() can take them.
    """
    out = {"ok": False, "matched_part": None, "links": [], "errors": [], "raw_count": 0}
    if not api_key:
        out["errors"].append("no MOUSER_API_KEY configured")
        return out
    base = "https://api.mouser.com/api/v1/search"
    attempts = [
        (f"{base}/partnumber", {"SearchByPartRequest": {
            "mouserPartNumber": part_number, "partSearchOptions": "Exact"}}),
        (f"{base}/keyword", {"SearchByKeywordRequest": {
            "keyword": part_number, "records": 10, "startingRecord": 0,
            "searchOptions": "None", "searchWithYourSignUpLanguage": "false"}}),
    ]
    want = _norm_pn(part_number)
    for endpoint, body in attempts:
        try:
            r = requests.post(endpoint, params={"apiKey": api_key}, json=body,
                              headers={"Content-Type": "application/json",
                                       "Accept": "application/json"}, timeout=timeout)
            if r.status_code != 200:
                out["errors"].append(f"{endpoint.rsplit('/',1)[-1]}: HTTP {r.status_code}")
                continue
            data = r.json()
        except Exception as exc:
            out["errors"].append(f"{endpoint.rsplit('/',1)[-1]}: {type(exc).__name__}: {exc}")
            continue
        for e in (data.get("Errors") or []):
            out["errors"].append(f"API: {e.get('Message') or e}")
        parts = ((data.get("SearchResults") or {}).get("Parts")) or []
        out["raw_count"] = len(parts)
        exact = [p for p in parts if want and _norm_pn(p.get("ManufacturerPartNumber")) == want]
        if not exact:
            continue
        p = exact[0]
        out["ok"] = True
        out["matched_part"] = {k: p.get(k) for k in (
            "Manufacturer", "ManufacturerPartNumber", "MouserPartNumber", "Description",
            "LifecycleStatus", "ROHSStatus", "Category", "ProductDetailUrl",
            "DataSheetUrl", "ImagePath")}
        if p.get("DataSheetUrl"):
            out["links"].append({"url": p["DataSheetUrl"], "anchor": "Datasheet",
                                 "source": "mouser-api", "hint": "Datasheet (Mouser API)"})
        if p.get("ProductDetailUrl"):
            out["links"].append({"url": p["ProductDetailUrl"], "anchor": "",
                                 "source": "mouser-api", "hint": "Product page (Mouser API)"})
        break
    return out


print("Fallback routes ready (robots/sitemap + Mouser-only web discovery + Mouser API).")




# ==== Document table mapper: Manufacturer | Doc Type | Doc Link | Part Number ====
import csv as _dm_csv
import json as _dm_json
import re as _dm_re
from urllib.parse import urlparse as _dm_urlparse, urldefrag as _dm_urldefrag

# True  = also list documents hosted by the manufacturer (e.g. vishay.com datasheet PDF
#         that Mouser hot-links from its "Documents" section)
# False = keep only mouser.com-hosted documents
INCLUDE_EXTERNAL_DOCS = True

# How many links to keep per (part, Doc Type) on the main sheet.
#   1    = one best link per document type (default)
#   None = keep every distinct link
# Everything found is always kept on the "All Links" sheet.
DOC_LINKS_PER_TYPE = None      # None = give ALL links found (no per-type limit); 1 = best link per type
DEDUPE_SAME_FILE = True        # True = same file name on another host/locale counts once; False = every distinct URL
HYPERLINK_MAX_ROWS = 20000     # above this many rows, skip per-cell hyperlinks (huge xlsx = very slow)

# Output is DOCUMENTS ONLY by default. Turn these on for extra sheets/files:
WRITE_ALTERNATES_SHEET = False    # every distinct document link, ranked
WRITE_EVERY_LINK_SHEET = False    # every link on the page (nav, images, trackers...) + name

_DM_DOC_EXT = (".pdf", ".zip", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".stp", ".step")
_DM_NON_DOC_EXT = (".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff",
                   ".woff2", ".ttf", ".map", ".json", ".xml", ".txt", ".php")
_DM_DOC_PATHS = ("/datasheet/", "/datasheets/", "/pcn/", "/pdn/", "/eol/", "/documents/",
                 "/document/", "/docs/", "/pdf/", "/technical-documents/")
_DM_TYPE_RULES = [
    ("Datasheet", r"datasheet|data[-\s_]sheet"),
    ("PCN", r"\bpcn\b|product[-\s]change[-\s]notif"),
    ("PDN / EOL", r"\bpdn\b|\beol\b|end[-\s]of[-\s]life|discontinu|last[-\s]time[-\s]buy"),
    ("FAQ", r"\bfaqs?\b|frequently[-\s]asked"),
    ("Environmental / Compliance", r"rohs|\breach\b|conflict[-\s]minerals?|material[-\s]declaration|"
                                   r"environmental|\bsvhc\b|proposition[-\s]65|\bmsds\b|\bsds\b|compliance"),
    ("Reliability / Qualification", r"reliabilit|qualific|\bmtbf\b"),
    ("Application / Technical Note", r"application[-\s]note|\bapp[-\s]note|technical[-\s](?:document|brief|paper|note)|"
                                     r"white[-\s]paper|user[-\s](?:manual|guide)|reference[-\s]manual"),
    ("Safety / Regulatory", r"safety|regulatory|certificat"),
    ("CAD / Model", r"\bstep\b|\bstp\b|ecad|footprint|3d[-\s]model|symbol"),
]
_DM_TRACKER_HINTS = ("doubleclick", "googletagmanager", "google-analytics", "facebook", "licdn",
                     "fullstory", "cookielaw", "anteriad", "adentifi", "niceincontact",
                     "lucidworks", "schema.org", "trustguard")
_DM_MOUSER_RE = _dm_re.compile(r"^(?:[a-z0-9-]+\.)*mouser\.[a-z]{2,3}(?:\.[a-z]{2,3})?$")


def _dm_clean(u):
    """Strip regex-sweep debris (e.g. url + '","event_product_category":...')."""
    u = str(u or "").strip().replace("\\/", "/")
    u = _dm_re.split(r'["\'<>\s\\]', u, maxsplit=1)[0]
    return _dm_urldefrag(u)[0].rstrip(".,;:)")


def _dm_type(url, anchors, hints):
    path = _dm_urlparse(url).path.lower()
    hay = " | ".join([*(anchors or []), *(hints or []), path]).lower()
    for label, pat in _DM_TYPE_RULES:
        if _dm_re.search(pat, hay):
            return label
    return "Other Document"


def _dm_is_doc(url):
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    if p.scheme not in ("http", "https") or not host:
        return False
    if any(t in host for t in _DM_TRACKER_HINTS):
        return False
    if path.endswith(_DM_NON_DOC_EXT) or "/productdetail/" in path:
        return False
    if not (path.endswith(_DM_DOC_EXT) or any(x in path for x in _DM_DOC_PATHS)):
        return False
    if not INCLUDE_EXTERNAL_DOCS and not _DM_MOUSER_RE.match(host):
        return False
    return True


def _dm_norm(x):
    return _dm_re.sub(r"[^a-z0-9]", "", str(x or "").lower())


def _dm_name(l, url):
    """Human-readable name for a link: anchor text > nearby heading > file/path name."""
    for cand in list(l.get("anchors") or []) + list(l.get("hints") or []):
        c = _dm_re.sub(r"\s+", " ", str(cand or "")).strip()
        if c:
            return c[:150]
    p = _dm_urlparse(url)
    last = _dm_re.sub(r"\.[A-Za-z0-9]{2,5}$", "", (p.path or "").rstrip("/").rsplit("/", 1)[-1])
    try:
        from urllib.parse import unquote
        last = unquote(last)
    except Exception:
        pass
    return (last.replace("-", " ").replace("_", " ").strip() or p.netloc)[:150]


def _dm_kind(url):
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    if any(t in host for t in _DM_TRACKER_HINTS):
        return "Tracker / third-party"
    if path.endswith(_DM_NON_DOC_EXT):
        return "Asset (image/script/style)"
    if "/productdetail/" in path:
        return "Product page (mirror/locale)" if _DM_MOUSER_RE.match(host) else "Product page"
    if _dm_is_doc(url) or path.endswith(_DM_DOC_EXT) or any(x in path for x in _DM_DOC_PATHS):
        return "Document"
    return "Mouser page" if _DM_MOUSER_RE.match(host) else "External page"


def _dm_score(url, anchors, hints, mpn):
    """Higher = better link to represent the document."""
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    anchor = " ".join(anchors or [])
    sc = 0
    if anchor.strip():
        sc += 2                                   # the page itself labels this link
    if mpn and _dm_norm(mpn) in _dm_norm(anchor + path):
        sc += 3                                   # names this exact part
    if _DM_MOUSER_RE.match(host):
        sc += 2                                   # Mouser-hosted
    if path.endswith(".pdf"):
        sc += 1
    if p.query:
        sc -= 1
    return sc


def _dm_panel_rows(doc, mfr, mpn):
    """Rows straight from the page's own Documents panel (real section names)."""
    ds = doc.get("document_sections") or {}
    rows, seen = [], set()
    for r in ds.get("rows") or []:
        url = _dm_clean(r.get("url"))
        if not url:
            continue
        key = (r.get("panel"), r.get("section"), url)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"Manufacturer": mfr, "Panel": r.get("panel") or "",
                     "Section": r.get("section") or "",
                     "Name": r.get("name") or _dm_name({}, url),
                     "Doc Link": url, "Part Number": mpn})
    return rows


def build_doc_rows(doc, per_type=None):
    """Return (main_rows, alt_rows).

    If the page's Documents panel was captured (doc["document_sections"]), main_rows
    is EVERY link in that panel, in page order, with Mouser's own section name
    (Datasheet / Models / Specification Sheets / Technical Resources / ...).
    Otherwise falls back to inferring document links (best `per_type` per type).
    """
    per_type = DOC_LINKS_PER_TYPE if per_type is None else per_type
    ident = doc.get("part_identification") or {}
    mfr, mpn = ident.get("manufacturer") or "", ident.get("mpn") or ""
    panel = _dm_panel_rows(doc, mfr, mpn)
    if panel:
        return panel, [{**r, "Rank": "", "Score": "", "On Main Sheet": "Yes"} for r in panel]
    groups = {}                                   # same file on another host/locale = 1 doc
    for l in (doc.get("link_inventory") or {}).get("links", []):
        url = _dm_clean(l.get("url"))
        if not url or not _dm_is_doc(url):
            continue
        fname = (_dm_urlparse(url).path.rsplit("/", 1)[-1].lower() or url.lower()) if DEDUPE_SAME_FILE \
            else url.lower()
        groups.setdefault(fname, []).append((
            _dm_score(url, l.get("anchors"), l.get("hints"), mpn), url,
            _dm_type(url, l.get("anchors"), l.get("hints")), _dm_name(l, url)))
    by_type = {}
    for fname, cands in groups.items():
        sc, url, _t, name = max(cands, key=lambda c: (c[0], -len(c[1])))
        specific = [c[2] for c in cands if c[2] != "Other Document"]
        dtype = specific[0] if specific else "Other Document"   # most specific label wins
        by_type.setdefault(dtype, []).append((sc, url, name))
    order = {"Datasheet": 0, "PCN": 1, "PDN / EOL": 2}
    main, allr = [], []
    for dtype in sorted(by_type, key=lambda t: (order.get(t, 9), t)):
        ranked = sorted(by_type[dtype], key=lambda x: (-x[0], len(x[1]), x[1]))
        for n, (sc, url, name) in enumerate(ranked):
            chosen = per_type is None or n < per_type
            base = {"Manufacturer": mfr, "Panel": "(inferred)", "Section": dtype, "Name": name,
                    "Doc Link": url, "Part Number": mpn}
            if chosen:
                main.append(base)
            allr.append({**base, "Rank": n + 1, "Score": sc,
                         "On Main Sheet": "Yes" if chosen else "No"})
    if not main:
        st = (doc.get("source") or {}).get("access_status") or ""
        label = ("NO DOCUMENTS FOUND" if st == "OK" else
                 "PAGE NOT FOUND (HTTP 404/410)" if st.startswith("PAGE NOT FOUND") else
                 "NOT RETRIEVED (ACCESS FAILED)")
        ph = {"Manufacturer": mfr, "Panel": "", "Section": label, "Name": "", "Doc Link": "", "Part Number": mpn}
        main.append(ph)
        allr.append({**ph, "Rank": "", "Score": "", "On Main Sheet": "Yes"})
    return main, allr


def build_all_links(doc):
    """EVERY unique link found on the page (no filtering), each with a name."""
    ident = doc.get("part_identification") or {}
    mfr, mpn = ident.get("manufacturer") or "", ident.get("mpn") or ""
    rows, seen = [], set()
    for l in (doc.get("link_inventory") or {}).get("links", []):
        url = _dm_clean(l.get("url"))
        if not url or url in seen:
            continue
        seen.add(url)
        kind = _dm_kind(url)
        rows.append({"Manufacturer": mfr, "Part Number": mpn, "Name": _dm_name(l, url),
                     "Link": url, "Link Kind": kind,
                     "Doc Type": _dm_type(url, l.get("anchors"), l.get("hints")) if kind == "Document" else "",
                     "Found Via": ", ".join(l.get("sources") or [])})
    return rows


def write_document_table(docs, out_dir, extra_rows=None, stem="mouser_documents"):
    """Write <stem>.xlsx (sheets: Documents, Doc Alternates, Every Link Found),
    <stem>.csv (Documents) and <stem>_every_link.csv."""
    import os
    import pandas as pd
    cols = ["Manufacturer", "Panel", "Section", "Name", "Doc Link", "Part Number"]
    alt_cols = cols + ["Rank", "Score", "On Main Sheet"]
    link_cols = ["Manufacturer", "Part Number", "Name", "Link", "Link Kind", "Doc Type", "Found Via"]
    rows, allrows, linkrows = [], [], []
    for d in docs:
        m, a = build_doc_rows(d)
        rows += m
        allrows += a
        linkrows += build_all_links(d)
    for r in (extra_rows or []):
        rows.append(r)
        allrows.append({**r, "Rank": "", "Score": "", "On Main Sheet": "Yes"})
    frames = {"Documents": pd.DataFrame(rows, columns=cols).fillna("")}
    if WRITE_ALTERNATES_SHEET:
        frames["Doc Alternates"] = pd.DataFrame(allrows, columns=alt_cols).fillna("")
    if WRITE_EVERY_LINK_SHEET:
        frames["Every Link Found"] = pd.DataFrame(linkrows, columns=link_cols).fillna("")
    os.makedirs(out_dir, exist_ok=True)
    xlsx, csvp = os.path.join(out_dir, stem + ".xlsx"), os.path.join(out_dir, stem + ".csv")
    frames["Documents"].to_csv(csvp, index=False, encoding="utf-8-sig")
    if WRITE_EVERY_LINK_SHEET:
        frames["Every Link Found"].to_csv(os.path.join(out_dir, stem + "_every_link.csv"),
                                          index=False, encoding="utf-8-sig")
    widths = {"Manufacturer": 22, "Panel": 24, "Section": 28, "Part Number": 24, "Doc Type": 28, "Name": 48, "Doc Link": 90,
              "Link": 90, "Link Kind": 26, "Found Via": 22, "Rank": 7, "Score": 7, "On Main Sheet": 14}
    with pd.ExcelWriter(xlsx, engine="openpyxl") as xw:
        for name, frame in frames.items():
            frame.to_excel(xw, index=False, sheet_name=name)
            ws = xw.sheets[name]
            for idx, col in enumerate(frame.columns, 1):
                ws.column_dimensions[ws.cell(row=1, column=idx).column_letter].width = widths.get(col, 20)
                if col in ("Doc Link", "Link") and len(frame) <= HYPERLINK_MAX_ROWS:
                    for r in range(2, ws.max_row + 1):
                        c = ws.cell(row=r, column=idx)
                        if c.value and str(c.value).startswith("http") and len(str(c.value)) < 2000:
                            c.hyperlink = c.value
                            c.style = "Hyperlink"
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
    print(f"Documents written: {xlsx}  ({len(frames['Documents'])} row(s))  + {os.path.basename(csvp)}")
    return frames["Documents"]

# ---- input: spreadsheet in the same folder as this script ---------------------
import glob

def find_input_file():
    if LOCAL_URL_FILE and os.path.exists(LOCAL_URL_FILE):
        return LOCAL_URL_FILE
    for pat in ("urls.xlsx", "urls.xls", "urls.csv", "U.xlsx", "mo.xlsx"):
        p = os.path.join(BASE_DIR, pat)
        if os.path.exists(p):
            return p
    others = [f for f in sorted(glob.glob(os.path.join(BASE_DIR, "*.xlsx"))
                                + glob.glob(os.path.join(BASE_DIR, "*.xls"))
                                + glob.glob(os.path.join(BASE_DIR, "*.csv")))
              if "mouser_harvest" not in f and not os.path.basename(f).startswith("~$")]
    return others[0] if others else None

URL_LIST = []
_fname = find_input_file()
if _fname:
    print("Reading URL list from:", _fname)
    _df = (pd.read_csv(_fname) if _fname.lower().endswith(".csv") else pd.read_excel(_fname))
    _df = _df.dropna(how="all")
    url_col = _pick_col(_df, ["url", "urls", "part_url", "part url", "mouser_url",
                               "mouser url", "link"]) or _df.columns[0]
    hint_col = _pick_col(_df, ["part_hint", "part hint", "part", "mpn", "part_number", "part number"])
    mfr_col = _pick_col(_df, ["manufacturer_hint", "manufacturer hint", "manufacturer", "mfr", "brand"])
    seen_urls = set()
    for _, row in _df.iterrows():
        u_raw = _cell(row, url_col)
        if not u_raw or not u_raw.lower().startswith("http"):
            continue
        u = _fix_double_encoded_qs(u_raw)
        if u != u_raw:
            print(f"  [qs fix] double-encoded token corrected: {u_raw[:90]}")
        if u in seen_urls:
            continue
        seen_urls.add(u)
        _sh, _mh = _slug_hints(u)
        URL_LIST.append({"url": u, "part_hint": _cell(row, hint_col) or _sh,
                         "manufacturer_hint": _cell(row, mfr_col) or _mh})
    print(f"Loaded {len(URL_LIST)} unique URL(s) (URL column: '{url_col}').")
else:
    print("No .xlsx/.csv found in", BASE_DIR, "- using the demo PART_URL.")
    URL_LIST = [{"url": _fix_double_encoded_qs(PART_URL), "part_hint": PART_HINT,
                 "manufacturer_hint": MANUFACTURER_HINT}]
for _i, _item in enumerate(URL_LIST[:15], 1):
    print(f"  {_i}. {_item['url']}")
if len(URL_LIST) > 15:
    print(f"  ... and {len(URL_LIST) - 15} more")




# ==== Internet connectivity watchdog: if the connection drops, WAIT and continue ======
import socket as _socket
import threading as _threading
import time as _time

NET_CHECK_HOSTS = [("1.1.1.1", 443), ("8.8.8.8", 443), ("9.9.9.9", 443), ("www.google.com", 443)]
NET_POLL_S = 5            # first re-check delay while offline
NET_POLL_MAX_S = 30       # re-check delay grows to this
NET_STATUS_EVERY_S = 60   # "still offline" reminder interval
_net_cache = {"t": 0.0, "ok": True}
_net_state = {"since": None, "last_msg": 0.0}
_net_lock = _threading.Lock()


_daily_lock = _threading.Lock()
_daily = {"date": None, "count": 0, "cap": 0}


def _today():
    return datetime.now().strftime("%Y-%m-%d")


def daily_ok():
    """True while under today's DAILY_BUDGET. Resets automatically at local midnight."""
    if not DAILY_BUDGET:
        return True
    with _daily_lock:
        if _daily["date"] != _today():
            _daily["date"] = _today()
            _daily["count"] = 0
            _daily["cap"] = max(1, int(DAILY_BUDGET * random.uniform(1 - DAILY_JITTER, 1 + DAILY_JITTER)))
        return _daily["count"] < _daily["cap"]


def daily_note():
    with _daily_lock:
        _daily["count"] += 1


def wait_for_daily_budget(stop_event=None):
    """Sleep until local midnight (when the daily budget resets), unattended."""
    with _daily_lock:
        cap, used = _daily["cap"], _daily["count"]
    _p(f"\n   daily budget reached ({used}/{cap} pages today) - pausing until tomorrow "
       f"(no action needed; this window can stay open for weeks).")
    last = 0.0
    while not (stop_event is not None and stop_event.is_set()):
        now = datetime.now()
        if now.strftime("%Y-%m-%d") != _daily["date"]:
            break
        secs_left = (24 * 3600) - (now.hour * 3600 + now.minute * 60 + now.second)
        _time.sleep(min(120, max(5, secs_left)))
        if _time.time() - last > 3600:
            last = _time.time()
            _p(f"   ... waiting for tomorrow's budget ({(secs_left) / 3600:.1f} h left today)")
    if not (stop_event is not None and stop_event.is_set()):
        _p(f"   new day - budget reset, resuming.\n")


def internet_ok(force=False, cache_s=8):
    """True if we can reach the internet (checks public DNS/web hosts, NOT Mouser)."""
    now = _time.time()
    if not force and now - _net_cache["t"] < cache_s:
        return _net_cache["ok"]
    ok = False
    for host, port in NET_CHECK_HOSTS:
        try:
            with _socket.create_connection((host, port), timeout=3):
                ok = True
                break
        except OSError:
            continue
    _net_cache["t"], _net_cache["ok"] = _time.time(), ok
    return ok


def wait_for_internet(stop_event=None):
    """Block until the internet is back. Returns seconds waited (0.0 if it was online)."""
    if internet_ok(force=True):
        return 0.0
    t0 = _time.time()
    with _net_lock:
        first = _net_state["since"] is None
        if first:
            _net_state["since"], _net_state["last_msg"] = t0, t0
    if first:
        print(f"\n!! INTERNET LOST ({datetime.now().strftime('%H:%M:%S')}) - paused, "
              f"waiting for the connection to return ...", flush=True)
    delay = NET_POLL_S
    while not (stop_event is not None and stop_event.is_set()):
        if internet_ok(force=True):
            break
        _time.sleep(delay)
        delay = min(delay * 1.5, NET_POLL_MAX_S)
        with _net_lock:
            if (_net_state["since"] is not None and
                    _time.time() - _net_state["last_msg"] >= NET_STATUS_EVERY_S):
                _net_state["last_msg"] = _time.time()
                print(f"   ... still offline ({(_time.time() - _net_state['since']) / 60:.1f} min)",
                      flush=True)
    waited = _time.time() - t0
    with _net_lock:
        if _net_state["since"] is not None and internet_ok():
            print(f"** INTERNET BACK after {(_time.time() - _net_state['since']):.0f}s "
                  f"({datetime.now().strftime('%H:%M:%S')}) - resuming.\n", flush=True)
            _net_state["since"] = None
    return waited


# ==== FAST BATCH ENGINE (session reuse + pacing + adaptive cool-down + resume) ========
import json
import math
import os
import queue
import random
import re
import threading
import time
import traceback
from collections import Counter, deque
from datetime import datetime, timezone

# ---- speed / politeness knobs (env vars override) --------------------------------------
SAFE = os.environ.get("SAFE", "0") == "1"                # SAFE=1: 1 browser, 8 pages/min
WORKERS = int(os.environ.get("WORKERS", "1" if SAFE else "3"))              # parallel browsers (RAM ~0.4 GB each)
TARGET_RPM = float(os.environ.get("TARGET_RPM", "8" if SAFE else "30"))   # CEILING; real pace is learned     # page loads per minute, ALL workers combined
MAX_WORKERS = int(os.environ.get("MAX_WORKERS", "1" if SAFE else "6"))   # thread/browser cap (~0.4 GB RAM each)
AUTOSCALE = os.environ.get("AUTOSCALE", "1") != "0"        # add threads automatically when pace needs them
SCALE_CHECK_S = float(os.environ.get("SCALE_CHECK_S", "20"))
BLOCK_WINDOW = int(os.environ.get("BLOCK_WINDOW", "20"))            # look at the last N page results
BLOCK_RATE_LIMIT = float(os.environ.get("BLOCK_RATE_LIMIT", "0.35"))  # slow down globally only above this block rate
DAILY_BUDGET = int(os.environ.get("DAILY_BUDGET", "0"))    # 0 = unlimited; else pages/day, resets at local midnight
DAILY_JITTER = float(os.environ.get("DAILY_JITTER", "0.15"))  # +/- randomize the daily budget (0.15 = +/-15%)
RETRY_DELAY_S = tuple(float(x) for x in os.environ.get("RETRY_DELAY_S", "15-35").split("-"))  # isolated block: retry THAT url after
START_RPM = float(os.environ.get("START_RPM", "8"))        # first pace of a fresh run
RAMP_EVERY = int(os.environ.get("RAMP_EVERY", "20"))       # +RAMP_STEP rpm after this many clean pages
RAMP_STEP = float(os.environ.get("RAMP_STEP", "1"))
PROBE_EVERY = int(os.environ.get("PROBE_EVERY", "200"))    # clean pages AT the learned ceiling before trying +1
RETRY_PASSES = int(os.environ.get("RETRY_PASSES", "2"))    # extra passes over still-failed URLs
DEFER_WAIT_S = float(os.environ.get("DEFER_WAIT_S", "900"))  # wait before each retry pass (15 min)
ACTIVE_HOURS = os.environ.get("ACTIVE_HOURS", "")          # e.g. "20-8" = only crawl 20:00-08:00 local time
MIN_RPM = 6                     # adaptive floor after blocks
READY_TIMEOUT_S = 25            # max wait for the real page to replace any challenge shell
NAV_TIMEOUT_MS_FAST = 45_000
MAX_ATTEMPTS = 3                # per URL, across cool-downs
RECYCLE_AFTER = 120             # restart each browser after N pages (fresh session, frees RAM)
COOLDOWN_BASE_S = float(os.environ.get("COOLDOWN_BASE_S", "60"))   # 1st block -> 60 s, then x2 ...
COOLDOWN_MAX_S = float(os.environ.get("COOLDOWN_MAX_S", "900"))
MAX_CONSEC_BLOCKS = 4           # this many blocks in a row -> stop cleanly and save (resume later)
RETRY_FAILED_ON_RESUME = True   # re-try previously failed URLs when you run again
WRITE_PER_PART_FILES = False    # per-part JSON files (3,000 files!) - off; results.jsonl has all
BLOCK_HEAVY_RESOURCES = os.environ.get("BLOCK_HEAVY", "0") == "1"  # skip images/fonts/media (faster)
# ---- 50K-scale controls -------------------------------------------------------------
SHARD = os.environ.get("SHARD", "")                          # "2/4" = this machine does slice 2 of 4
MAX_PAGES_PER_RUN = int(os.environ.get("MAX_PAGES", "0"))    # 0 = unlimited (e.g. 6000 per day)
RUN_HOURS = float(os.environ.get("RUN_HOURS", "0"))          # 0 = unlimited (stop after N hours)
LONG_PAUSE_S = float(os.environ.get("LONG_PAUSE_S", "1800")) # after repeated blocks: 30 min, doubling to 4 h
MAX_LONG_PAUSES = 5             # still blocked after this many long pauses -> save and stop
USE_API_FALLBACK = True         # Mouser Search API (needs MOUSER_API_KEY) for URLs that stay blocked
if os.environ.get("FAST_ALL_PANELS", "0") != "1":
    DOC_PANEL_TITLES = ["Documents"]     # FAST_ALL_PANELS=1 also expands Environmental/Compliance

RESULTS_JSONL = os.path.join(OUT_DIR, "results.jsonl")
BLOCK_STATE = os.path.join(OUT_DIR, "block_state.json")   # remembers a hard ban so a re-run doesn't hammer it
COOLOFF_HOURS = [float(x) for x in os.environ.get("COOLOFF_HOURS", "2,6,24").split(",")]
COOLOFF_MODE = os.environ.get("COOLOFF_MODE", "wait")     # wait = sleep until cool-off ends; exit = quit now
_DENIED = []                                               # timestamps of HTTP 403 "Access Denied" pages
PACE_STATE = os.path.join(OUT_DIR, "pace_state.json")     # learned safe pace, reused next run
VERIFY_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0"
_print_lock = threading.Lock()
_stop = threading.Event()
_FETCH_EMA = [8.0]     # smoothed seconds per page (drives thread auto-scaling)
_READY_AT = {}        # url -> earliest time it may be retried after an isolated block
_RUN_OK = [0]        # successful pages in THIS run (across all retry passes)


def _p(*a):
    with _print_lock:
        print(*a, flush=True)


def _in_window():
    """True if the current local hour is inside ACTIVE_HOURS (or no window is set)."""
    if not ACTIVE_HOURS:
        return True
    try:
        s, e = [int(x) for x in ACTIVE_HOURS.split("-")]
    except Exception:
        return True
    h = datetime.now().hour
    return (s <= h < e) if s < e else (h >= s or h < e)


class Throttle:
    """Global pacing: AIMD (additive increase / multiplicative decrease) with a LEARNED ceiling.

    - starts at START_RPM and adds RAMP_STEP rpm every RAMP_EVERY clean pages, up to the ceiling
    - on a block: rpm halves, the ceiling drops to 80% of the pace that got challenged,
      cool-down (and long pause after repeated blocks)
    - after PROBE_EVERY clean pages at the ceiling it probes 1 rpm higher (up to TARGET_RPM)
    - the learned ceiling is saved to pace_state.json so the next run starts near it
    """

    def __init__(self):
        self.lock = threading.Lock()
        self.next_slot = 0.0
        self.pause_until = 0.0
        self.ceiling = float(TARGET_RPM)
        st = self._load()
        if st:
            self.ceiling = max(MIN_RPM, min(float(TARGET_RPM), float(st.get("ceiling", TARGET_RPM))))
        self.rpm = min(self.ceiling, max(MIN_RPM, START_RPM))
        self.consec_blocks = 0
        self.total_blocks = 0
        self.ok_run = 0
        self.ok_at_ceiling = 0
        self.long_pauses = 0
        self.recent = deque(maxlen=BLOCK_WINDOW)     # 1 = blocked, 0 = ok (sliding window)
        self._last_save = 0.0
        self._window_msg = False
        self._last_hold_msg = 0.0

    def _load(self):
        try:
            with open(PACE_STATE, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return None

    def _save(self):
        try:
            os.makedirs(OUT_DIR, exist_ok=True)
            with open(PACE_STATE, "w", encoding="utf-8") as fh:
                json.dump({"ceiling": round(self.ceiling, 1), "rpm": round(self.rpm, 1),
                           "total_blocks": self.total_blocks,
                           "updated": datetime.now(timezone.utc).isoformat()}, fh)
            self._last_save = time.time()
        except Exception:
            pass

    def wait_turn(self):
        while not _stop.is_set():
            if not _in_window():
                if not self._window_msg:
                    self._window_msg = True
                    _p(f"   outside ACTIVE_HOURS {ACTIVE_HOURS} - sleeping until the window opens "
                       f"(Ctrl+C to stop)")
                time.sleep(30)
                continue
            self._window_msg = False
            with self.lock:
                now = time.time()
                if now < self.pause_until:
                    slot, wait = None, self.pause_until - now
                else:
                    slot = max(now, self.next_slot)
                    self.next_slot = slot + (60.0 / self.rpm) * random.uniform(0.7, 1.3)
                    wait = slot - now
            if slot is None:
                if wait > 60:
                    self._refresh_pause_from_file()
                    with self.lock:
                        if time.time() - self._last_hold_msg > 900:   # every 15 min, not every 5 s
                            self._last_hold_msg = time.time()
                            resume_at = datetime.fromtimestamp(self.pause_until).strftime("%H:%M")
                            _p(f"   ... on hold, resuming automatically in ~{wait / 60:.0f} min "
                               f"(around {resume_at}). No requests are being sent to Mouser meanwhile.")
                time.sleep(min(wait, 5))
                continue
            if wait > 0:
                time.sleep(wait)
            return True
        return False

    def on_success(self):
        with self.lock:
            self.consec_blocks = 0
            self.recent.append(0)
            self.ok_run += 1
            if self.ok_run >= 10:
                self.long_pauses = 0
            if self.ok_run % RAMP_EVERY == 0 and self.rpm < self.ceiling:
                self.rpm = min(self.ceiling, self.rpm + RAMP_STEP)
            if self.rpm >= self.ceiling:
                self.ok_at_ceiling += 1
                if self.ok_at_ceiling >= PROBE_EVERY and self.ceiling < TARGET_RPM:
                    self.ceiling = min(float(TARGET_RPM), self.ceiling + 1.0)
                    self.ok_at_ceiling = 0
            else:
                self.ok_at_ceiling = 0
            if time.time() - self._last_save > 60:
                self._save()

    def on_block(self):
        with self.lock:
            self.consec_blocks += 1
            self.total_blocks += 1
            self.recent.append(1)
            rate = sum(self.recent) / len(self.recent)
            sustained = self.consec_blocks >= 3 or (len(self.recent) >= 8 and rate >= BLOCK_RATE_LIMIT)
            if not sustained:                    # isolated challenge: retry that URL only, no global change
                return self.consec_blocks, 0.0, self.rpm, False
            self.recent.clear()
            self.ok_run = 0
            self.ok_at_ceiling = 0
            self.ceiling = max(float(MIN_RPM), min(self.ceiling, round(self.rpm * 0.8, 1)))
            self.rpm = max(float(MIN_RPM), min(self.rpm * 0.5, self.ceiling))
            cool = min(COOLDOWN_BASE_S * (2 ** (self.consec_blocks - 1)), COOLDOWN_MAX_S)
            long_pause = False
            if self.consec_blocks >= MAX_CONSEC_BLOCKS:         # repeated blocks -> long pause
                long_pause = True
                cool = min(LONG_PAUSE_S * (2 ** min(self.long_pauses, 3)), 4 * 3600)
                self.long_pauses += 1
                self.consec_blocks = 0
            self.pause_until = max(self.pause_until, time.time() + cool)
            self.next_slot = max(self.next_slot, self.pause_until)
            self._save()
            return self.consec_blocks, cool, self.rpm, long_pause

    def hold(self, seconds):
        """Freeze ALL workers for `seconds` (used on a hard 403 so nobody keeps hitting a denied IP)."""
        with self.lock:
            self.pause_until = max(self.pause_until, time.time() + seconds)
            self.next_slot = max(self.next_slot, self.pause_until)

    def _refresh_pause_from_file(self):
        """If a cool-off is active, adopt block_state.json's cooloff_until as the source of truth,
        so `python set_cooloff.py HOURS` (run in another window) can shorten/clear a mid-run pause
        without restarting."""
        raw = (_bs_load()).get("cooloff_until", None)
        if raw is None:
            return                            # file missing/unreadable -> keep current pause
        until = float(raw or 0)
        with self.lock:
            if self.pause_until <= time.time():
                return                        # not on hold -> nothing to adjust
            if until == 0:
                self.pause_until = 0.0        # explicit clear (set_cooloff.py 0) -> retry now
                self.next_slot = 0.0
            elif until != self.pause_until:
                self.pause_until = until
                self.next_slot = until       # sync fully (not max()) so a SHORTER wait actually shrinks it

    def report(self):
        with self.lock:
            self._save()
            return (f"pace: now {self.rpm:.0f}/min, learned safe ceiling ~{self.ceiling:.0f}/min "
                    f"(saved to pace_state.json), blocks this run: {self.total_blocks}")


THROTTLE = Throttle()
_api_lock = threading.Lock()
_api_last = [0.0]


def evaluate_block(res):
    """Same block criteria as the slow renderer (no CAPTCHA solving, just detection)."""
    if res.get("http_status") in (404, 410):              # removed/discontinued page: not a block
        res["not_found"] = True
        res["failure_kind"] = "not_found"
        return res
    text = res.get("page_text") or ""
    hay = (text[:4000] + " " + (res.get("title") or "")).lower()
    has_product = bool(re.search(r"Mouser No\s*:|Mfr\. No\s*:", text))   # real content present
    if len(text) < 5000 and not has_product:
        for m in BLOCK_MARKERS:
            if m in hay:
                res["blocked"] = True
                res["block_evidence"].append(f"text marker: {m!r}")
    fl = res.get("challenge_flags") or {}
    if fl.get("hasAkam") and not has_product:
        res["blocked"] = True
        res["block_evidence"].append("Akamai challenge present after wait")
    if fl.get("hasDD") and not has_product:
        res["blocked"] = True
        res["block_evidence"].append("DataDome challenge present after wait")
    if res.get("http_status") in (401, 403, 429, 503):
        res["blocked"] = True
        res["block_evidence"].append(f"http status {res['http_status']}")
    if len(text.strip()) < 300:
        res["blocked"] = True
        res["block_evidence"].append(f"rendered text too short ({len(text.strip())} chars)")
    if res["blocked"] and not res.get("failure_kind"):
        res["failure_kind"] = "challenge"
    if res.get("http_status") == 403 and re.search(r"access denied|reference #", text[:1500], re.I):
        res["blocked"] = True                       # Akamai edge refusal of this connection (not a CAPTCHA)
        res["failure_kind"] = "access_denied"
    return res


class BrowserSession:
    """One long-lived Camoufox browser: warm-up ONCE, then many pages."""

    def __init__(self, wid):
        self.wid, self.cm, self.browser, self.page = wid, None, None, None
        self.pages_done = 0
        self.broken = False
        self.blocks_in_row = 0

    def start(self):
        last = None
        for use_geoip in (True, False):
            try:
                self.cm = Camoufox(headless=HEADLESS_MODE, humanize=True, locale=["en-US"],
                                   geoip=use_geoip, exclude_addons=EXCLUDE_ADDONS)
                self.browser = self.cm.__enter__()
                break
            except Exception as exc:
                last = exc
                self.cm = None
        if self.browser is None:
            raise RuntimeError(f"browser failed to start: {type(last).__name__}: {last}")
        self.page = self.browser.new_page()
        if BLOCK_HEAVY_RESOURCES:
            try:
                self.page.route("**/*", lambda route: route.abort()
                                if route.request.resource_type in ("image", "media", "font")
                                else route.continue_())
            except Exception:
                pass
        try:  # one homepage warm-up per browser session
            self.page.goto(WARMUP_URL, wait_until="domcontentloaded", timeout=60000,
                           referer="https://www.google.com/")
            t0 = time.time()
            while time.time() - t0 < 25:
                time.sleep(1.5)
                s = self.page.evaluate(STATE_JS)
                if s["len"] > 2000 and not s["hasAkam"] and not s["hasDD"]:
                    break
        except Exception:
            pass
        self.pages_done, self.broken = 0, False

    def stop(self):
        try:
            if self.cm is not None:
                self.cm.__exit__(None, None, None)
        except Exception:
            pass
        self.cm = self.browser = self.page = None

    def restart(self):
        self.stop()
        self.start()

    def ensure(self):
        if self.page is None or self.broken or self.pages_done >= RECYCLE_AFTER:
            self.restart() if self.page is not None else self.start()

    def fetch(self, url):
        res = {"requested_url": url, "final_url": None, "http_status": None, "title": None,
               "page_text": "", "doc_panels": None, "dom_links": [], "canonical": None,
               "blocked": False, "block_evidence": [], "errors": [], "challenge_flags": {},
               "failure_kind": None}
        try:
            self.ensure()
        except Exception as exc:
            res.update(blocked=True, failure_kind="launch_error")
            res["errors"].append(str(exc)[:300])
            return res
        page = self.page
        try:
            resp = page.goto(url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS_FAST,
                             referer=WARMUP_URL)
            res["http_status"] = getattr(resp, "status", None) if resp else None
            if res["http_status"] in (404, 410):               # gone - don't wait for a product page
                res["final_url"], res["title"] = page.url, page.title()
                self.pages_done += 1
                return evaluate_block(res)
            t0, s = time.time(), {"len": -1, "hasAkam": False, "hasDD": False}
            while time.time() - t0 < READY_TIMEOUT_S:
                time.sleep(0.4)
                try:
                    s = page.evaluate(STATE_JS)
                except Exception:
                    continue
                if _page_ready(s):
                    break
            res["challenge_flags"] = {k: s[k] for k in ("hasAkam", "hasDD") if k in s}
            res["product_seen"] = bool(s.get("product"))
            if _page_ready(s):
                page.wait_for_timeout(400)
                cfg = {"xpath": DOC_PANEL_XPATH, "titles": DOC_PANEL_TITLES}
                if len(DOC_PANEL_TITLES) > 1:
                    try:
                        if page.evaluate(EXPAND_JS, DOC_PANEL_TITLES):
                            page.wait_for_timeout(1200)
                    except Exception:
                        pass
                panels = page.evaluate(DOC_PANEL_JS, cfg)
                if not panels.get("rows"):            # panel may render a beat late
                    page.wait_for_timeout(1500)
                    panels = page.evaluate(DOC_PANEL_JS, cfg)
                res["doc_panels"] = panels
                data = page.evaluate(EXTRACT_JS) if not panels.get("rows") else \
                    {"text": page.evaluate("() => document.body ? document.body.innerText : ''"),
                     "links": [], "canonical": ""}
                res["page_text"] = data.get("text") or ""
                res["dom_links"] = data.get("links") or []
                res["canonical"] = data.get("canonical") or None
            else:
                try:
                    res["page_text"] = page.evaluate(
                        "() => document.body ? document.body.innerText : ''") or ""
                except Exception:
                    pass
            res["final_url"] = page.url
            res["title"] = page.title()
        except PWTimeoutError as exc:
            res["errors"].append(f"navigation timeout: {str(exc)[:200]}")
            res["failure_kind"] = "timeout"
        except Exception as exc:
            msg = f"{type(exc).__name__}: {str(exc)[:250]}"
            res["errors"].append(msg)
            res["failure_kind"] = "no_response"
            if any(k in msg.lower() for k in ("closed", "crash", "disconnected", "browser has been")):
                self.broken = True
        self.pages_done += 1
        return evaluate_block(res)


def build_doc(res, item, attempts, elapsed, api_result=None):
    url = item["url"]
    ident = identify_part(res.get("page_text"), res.get("final_url") or url)
    if item.get("part_hint") and not ident.get("mpn"):
        ident["mpn"] = item["part_hint"]
    ok = bool(res.get("page_text")) and not res["blocked"]
    links = []
    rows = ((res.get("doc_panels") or {}).get("rows")) or []
    if ok and not rows:                                   # fallback: doc-like links from DOM
        for l in res.get("dom_links") or []:
            u = _dm_clean(normalize_url(l.get("url"), res.get("final_url") or url) or "")
            if u and _dm_is_doc(u):
                links.append({"url": u, "anchors": [l.get("anchor") or ""],
                              "hints": [l.get("hint") or ""], "sources": [l.get("source") or ""]})
    status = "OK" if ok else "ACCESS FAILED - DOCUMENT DISCOVERY INCOMPLETE"
    if res.get("not_found"):
        status = f"PAGE NOT FOUND (HTTP {res.get('http_status')})"
    if not ok and not res.get("not_found") and api_result and api_result.get("ok"):
        mp = api_result.get("matched_part") or {}
        for l in api_result["links"]:
            links.append({"url": l["url"], "anchors": [l.get("anchor") or ""],
                          "hints": [l.get("hint") or ""], "sources": ["mouser-api"]})
        if mp.get("Manufacturer"):
            ident["manufacturer"] = mp["Manufacturer"]
        status = "PARTIAL - PAGE BLOCKED; DOCUMENT LINKS FROM OFFICIAL MOUSER API"
    return {
        "schema": "mouser-full-page-link-harvest/fast-v1",
        "source": {"requested_url": url, "final_url": res.get("final_url"),
                   "http_status": res.get("http_status"), "title": res.get("title"),
                   "access_status": status, "attempts": attempts,
                   "duration_seconds": round(elapsed, 1),
                   "harvested_at": datetime.now(timezone.utc).isoformat()},
        "part_identification": ident,
        "document_sections": res.get("doc_panels"),
        "link_inventory": {"total_unique": len(links), "links": links},
        "failures": {"failure_kind": res.get("failure_kind"),
                     "block_evidence": res.get("block_evidence"),
                     "render_errors": res.get("errors")},
    }


def api_fallback(item, res):
    if not (USE_API_FALLBACK and MOUSER_API_KEY):
        return None
    pn = (item.get("part_hint") or identify_part(None, item["url"]).get("mpn") or "")
    with _api_lock:                                        # API free tier: ~30 calls/min
        wait = 2.2 - (time.time() - _api_last[0])
        if wait > 0:
            time.sleep(wait)
        _api_last[0] = time.time()
    try:
        return mouser_api_lookup(pn, MOUSER_API_KEY)
    except Exception:
        return None


_res_lock = threading.Lock()


STREAM_CSV = os.path.join(OUT_DIR, "mouser_documents_stream.csv")   # live rows, safe to open anytime
_STREAM_COLS = ["Manufacturer", "Panel", "Section", "Name", "Doc Link", "Part Number"]


def save_record(rec):
    with _res_lock:
        with open(RESULTS_JSONL, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        try:                                       # append this part's rows to the live CSV
            main_rows, _alt = build_doc_rows(rec["doc"])
            new = not os.path.exists(STREAM_CSV)
            with open(STREAM_CSV, "a", newline="", encoding="utf-8-sig" if new else "utf-8") as fh:
                w = _dm_csv.writer(fh)
                if new:
                    w.writerow(_STREAM_COLS)
                for r in main_rows:
                    w.writerow([r.get(c, "") for c in _STREAM_COLS])
        except Exception:
            pass


def load_records():
    recs = {}
    if os.path.exists(RESULTS_JSONL):
        with open(RESULTS_JSONL, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    recs[r["url"]] = r          # last line per URL wins
                except Exception:
                    continue
    return recs


def _bs_load():
    try:
        with open(BLOCK_STATE, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def _bs_save(st):
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
        with open(BLOCK_STATE, "w", encoding="utf-8") as fh:
            json.dump(st, fh, indent=1)
    except Exception:
        pass


_cooloff_lock = threading.Lock()


def set_cooloff(reason):
    """Record a hard ban. Cool-off grows with each repeated ban: 2 h, 6 h, 24 h (recorded once per run)."""
    with _cooloff_lock:
        if _stop.is_set():                 # another worker already recorded it
            return None
        return _set_cooloff_locked(reason)


def _set_cooloff_locked(reason):
    st = _bs_load()
    n = int(st.get("ban_count", 0))
    hours = COOLOFF_HOURS[min(n, len(COOLOFF_HOURS) - 1)]
    st.update(ban_count=n + 1, cooloff_until=time.time() + hours * 3600, reason=reason,
              set_at=datetime.now().isoformat(timespec="seconds"))
    _bs_save(st)
    until = datetime.fromtimestamp(st["cooloff_until"]).strftime("%Y-%m-%d %H:%M")
    _p(f"   cool-off saved: no requests to Mouser until {until} ({hours:g} h). The next run waits "
       f"automatically - re-running sooner only prolongs the ban.")
    return st["cooloff_until"]


def enter_cooloff(reason):
    """Record + apply a cool-off WITHOUT stopping the run: pauses every worker via THROTTLE.hold()
    (they block silently in wait_turn(), sending nothing to Mouser) and resumes automatically once
    the wait passes - no restart needed. Only the worker that wins the race actually applies it."""
    until = set_cooloff(reason)
    if until is None:                      # another worker already handled this ban
        return
    THROTTLE.hold(max(0.0, until - time.time()))
    with THROTTLE.lock:
        THROTTLE.rpm = float(MIN_RPM)
        THROTTLE.consec_blocks = 0
        THROTTLE.recent.clear()
        THROTTLE.long_pauses = 0
    _DENIED.clear()
    _p("   Pausing in place - no restart needed, this run resumes on its own when the cool-off ends.")


def check_cooloff():
    """At start-up: if a hard ban was recorded recently, wait it out instead of hitting Mouser.

    Re-reads block_state.json every few seconds, so running `python set_cooloff.py HOURS` in
    another window shortens (or clears) an ALREADY-WAITING run without restarting it.
    """
    until = float((_bs_load()).get("cooloff_until", 0) or 0)
    if until <= time.time():
        return
    st = _bs_load()
    when = datetime.fromtimestamp(until).strftime("%Y-%m-%d %H:%M")
    _p(f"\n!! Mouser denied access recently ({st.get('reason')}). Cool-off until {when}.")
    if COOLOFF_MODE == "exit":
        _p("COOLOFF_MODE=exit - quitting. Run again after that time.")
        raise SystemExit(0)
    _p("Waiting it out (keep this window open; Ctrl+C to quit). To shorten this wait without "
       "restarting, run in another window:   python set_cooloff.py HOURS   (0 = try again now)")
    last = 0.0
    try:
        while True:
            st = _bs_load()
            until = float(st.get("cooloff_until", 0) or 0)
            if until <= time.time():
                break
            time.sleep(5)
            if time.time() - last > 600:
                last = time.time()
                _p(f"   ... {(until - time.time()) / 60:.0f} min of cool-off left")
    except KeyboardInterrupt:
        raise SystemExit(0)
    _p("Cool-off finished - resuming at a gentle pace.\n")
    with THROTTLE.lock:
        THROTTLE.rpm = float(MIN_RPM)


class Progress:
    def __init__(self, total):
        self.total, self.done, self.ok, self.failed = total, 0, 0, 0
        self.t0, self.lock = time.time(), threading.Lock()

    def tick(self, ok):
        with self.lock:
            self.done += 1
            self.ok += bool(ok)
            _RUN_OK[0] += bool(ok)
            if ok and _RUN_OK[0] == 20:
                st = _bs_load()
                if st.get("ban_count"):
                    st["ban_count"] = 0
                    _bs_save(st)
            self.failed += (not ok)
            el = time.time() - self.t0
            rate = self.done / el * 60 if el else 0
            eta = (self.total - self.done) / (self.done / el) / 60 if self.done and el else 0
            return (f"[{self.done}/{self.total}] ok={self.ok} failed={self.failed} "
                    f"rate={rate:.1f}/min eta={eta:.0f} min (pace {THROTTLE.rpm:.0f} rpm)")


def worker(wid, q, state, prog):
    try:
        _worker(wid, q, state, prog)
    except Exception:
        _p(f"!! worker {wid} crashed - stopping run (progress is saved):\n" + traceback.format_exc())
        _stop.set()


def _worker(wid, q, state, prog):
    session = BrowserSession(wid)
    try:
        while not _stop.is_set():
            if (MAX_PAGES_PER_RUN and prog.done >= MAX_PAGES_PER_RUN) or \
                    (RUN_HOURS and time.time() - prog.t0 > RUN_HOURS * 3600):
                if not _stop.is_set():
                    _p("Run limit reached (MAX_PAGES / RUN_HOURS) - saving. Run again later to continue.")
                _stop.set()
                return
            with state["lock"]:
                if state["pending"] <= 0:
                    return
            try:
                idx, item, attempt = q.get(timeout=1)
            except queue.Empty:
                continue
            ra = _READY_AT.get(item["url"], 0.0)
            if ra > time.time():                     # this URL is serving its own short back-off
                q.put((idx, item, attempt))
                time.sleep(min(2.0, max(0.2, ra - time.time())))
                continue
            if not daily_ok():
                q.put((idx, item, attempt))
                wait_for_daily_budget(_stop)
                if _stop.is_set():
                    return
                continue
            if not THROTTLE.wait_turn():
                q.put((idx, item, attempt))
                return
            if not internet_ok():                     # connection down -> pause everything
                wait_for_internet(_stop)
                if _stop.is_set():
                    q.put((idx, item, attempt))
                    return
            t0 = time.time()
            res = session.fetch(item["url"])
            elapsed = time.time() - t0
            daily_note()
            _FETCH_EMA[0] = 0.9 * _FETCH_EMA[0] + 0.1 * min(elapsed, 30.0)
            name = item.get("part_hint") or item["url"][-40:]
            if (res["failure_kind"] in ("timeout", "no_response", "launch_error")
                    or (res["http_status"] is None and len(res["page_text"]) < 300)) \
                    and not internet_ok(force=True):
                _p(f"   network error on {name} - internet is down; pausing (not counted as a block)")
                wait_for_internet(_stop)
                if _stop.is_set():
                    q.put((idx, item, attempt))
                    return
                try:
                    session.restart()                    # fresh browser after the outage
                except Exception:
                    session.broken = True
                q.put((idx, item, attempt))              # same attempt number - outage != block
                continue
            if res["failure_kind"] == "launch_error":
                _p(f"!! browser cannot start ({res['errors']}). Re-run the .bat to reinstall. Stopping.")
                q.put((idx, item, attempt))
                _stop.set()
                return
            if res["blocked"]:
                consec, cool, rpm, long_p = THROTTLE.on_block()
                session.blocks_in_row += 1
                if res.get("failure_kind") == "access_denied":
                    now = time.time()
                    _DENIED.append(now)
                    THROTTLE.hold(300)
                    _p(f"   ACCESS DENIED (HTTP 403) on {name}: Mouser's edge refused this connection. "
                       f"All workers held 5 min.")
                    if len([x for x in _DENIED if now - x < 180]) >= 2:
                        _p("!! Repeated 'Access Denied'. PAUSING to avoid extending the ban (not stopping - "
                           "it will retry automatically once the cool-off ends). Do not switch IPs to get "
                           "around it; for 57K links, Mouser API / bulk-data access is the reliable option.")
                        enter_cooloff("HTTP 403 Access Denied on repeated pages")
                        q.put((idx, item, attempt))
                        continue
                if cool > 0:                               # sustained block rate -> global slow-down
                    _p(f"   BLOCKED  {name}  kind={res['failure_kind']} attempt {attempt}/{MAX_ATTEMPTS}"
                       f" -> SUSTAINED blocks: cooling down {cool:.0f}s, pace now {rpm:.0f} rpm "
                       f"(consecutive blocks: {consec}/{MAX_CONSEC_BLOCKS})")
                elif res.get("failure_kind") != "access_denied":   # isolated: back off this URL only
                    delay = random.uniform(*RETRY_DELAY_S)
                    _READY_AT[item["url"]] = time.time() + delay
                    _p(f"   blocked (isolated) {name}  kind={res['failure_kind']} attempt "
                       f"{attempt}/{MAX_ATTEMPTS} -> retry this URL in {delay:.0f}s; pace stays {rpm:.0f} rpm")
                _p(f"      why: status={res['http_status']} text={len(res['page_text'])} chars "
                   f"evidence={res['block_evidence'][:3]} errors={[e[:120] for e in res['errors'][:2]]}")
                if cool > 0 or session.blocks_in_row >= 2:  # new session only after repeated blocks
                    try:
                        session.restart()
                    except Exception:
                        session.broken = True
                    session.blocks_in_row = 0
                if _RUN_OK[0] == 0 and consec >= 2:
                    _p("!! Blocked from the very first pages (0 successes). This network/IP is being "
                       "challenged, so more speed or workers will not help. PAUSING and retrying "
                       "automatically after a cool-off.")
                    enter_cooloff("blocked from the very first pages")
                    q.put((idx, item, attempt))
                    continue
                if long_p:
                    if THROTTLE.long_pauses > MAX_LONG_PAUSES:
                        _p(f"!! Still blocked after {MAX_LONG_PAUSES} long pauses - your IP is being "
                           "challenged. PAUSING for a longer cool-off; will retry automatically.")
                        enter_cooloff("still blocked after repeated long pauses")
                        q.put((idx, item, attempt))
                        continue
                    _p(f"!! {MAX_CONSEC_BLOCKS} blocks in a row - LONG PAUSE {cool / 60:.0f} min "
                       f"(auto-resumes; long pause {THROTTLE.long_pauses}/{MAX_LONG_PAUSES})")
                if attempt < MAX_ATTEMPTS:
                    q.put((idx, item, attempt + 1))        # retried after the cool-down
                    continue
                api = api_fallback(item, res)
                doc = build_doc(res, item, attempt, elapsed, api)
                ok = False
            else:
                THROTTLE.on_success()
                session.blocks_in_row = 0
                doc = build_doc(res, item, attempt, elapsed)
                ok = True
            rec = {"url": item["url"], "idx": idx, "status": "ok" if ok else "failed", "doc": doc}
            save_record(rec)
            with state["lock"]:
                state["pending"] -= 1
            n = len((doc.get("document_sections") or {}).get("rows") or []) or \
                doc["link_inventory"]["total_unique"]
            _p(f"{prog.tick(ok)}  {'OK ' if ok else 'FAIL'} {name}  docs={n}  {elapsed:.1f}s")
    finally:
        session.stop()


def _run_pass(todo):
    q = queue.Queue()
    for i, it in todo:
        q.put((i, it, 1))
    state = {"pending": len(todo), "lock": threading.Lock()}
    prog = Progress(len(todo))
    threads = []
    def spawn(w):
        th = threading.Thread(target=worker, args=(w, q, state, prog), daemon=True)
        th.start()
        threads.append(th)

    for w in range(min(WORKERS, len(todo))):
        spawn(w)
        time.sleep(6)                                   # stagger browser start-up
    last_scale = time.time()
    try:
        while any(th.is_alive() for th in threads):
            time.sleep(1)
            if not AUTOSCALE or _stop.is_set() or time.time() - last_scale < SCALE_CHECK_S:
                continue
            last_scale = time.time()
            alive = sum(th.is_alive() for th in threads)
            with state["lock"]:
                pending = state["pending"]
            need = math.ceil(THROTTLE.rpm * _FETCH_EMA[0] / 60.0 * 1.3)      # threads to sustain the pace
            if (need > alive and alive < MAX_WORKERS and pending > alive
                    and time.time() >= THROTTLE.pause_until and internet_ok()):
                spawn(len(threads))
                _p(f"   + thread #{alive + 1}: pace {THROTTLE.rpm:.0f}/min at ~{_FETCH_EMA[0]:.1f}s/page "
                   f"needs ~{need} (max {MAX_WORKERS})")
    except KeyboardInterrupt:
        _p("Ctrl+C - finishing current pages and saving ...")
        _stop.set()
        for th in threads:
            th.join(timeout=90)


def run_batch():
    os.makedirs(OUT_DIR, exist_ok=True)
    done = load_records()
    todo = [(i, it) for i, it in enumerate(URL_LIST)
            if it["url"] not in done or
            (RETRY_FAILED_ON_RESUME and done[it["url"]].get("status") != "ok")]
    check_cooloff()                                            # honour a recorded ban before touching Mouser
    wait_for_internet(_stop)                                   # nothing starts while offline
    already = len(URL_LIST) - len(todo)
    if SHARD:
        k, n = [int(x) for x in SHARD.split("/")]
        todo = [(i, it) for i, it in todo if i % n == k - 1]
        _p(f"SHARD {k}/{n}: this machine handles every {n}th URL starting at #{k}")
    try:                                                       # keep Windows awake for long runs
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    except Exception:
        pass
    _p(f"{len(URL_LIST)} URL(s) in list | {already} already done (resume) | "
       f"{len(todo)} to fetch | workers={WORKERS} pace={TARGET_RPM:.0f}/min")
    if todo:
        est = len(todo) / TARGET_RPM
        span = f"{est / 60 / 24:.1f} days" if est > 24 * 60 else f"{est / 60:.1f} h"
        _p(f"estimated time at full pace (ignoring the daily budget): ~{span}.")
        if DAILY_BUDGET:
            days = len(todo) / DAILY_BUDGET
            _p(f"DAILY_BUDGET={DAILY_BUDGET}/day -> ~{days:.0f} days (~{days / 7:.1f} weeks) to finish. "
               f"Leave this window open; it paces itself and resumes each day automatically.")
        _p("Ctrl+C = save & stop; run again to resume.")
        try:
            _run_pass(todo)
            for n in range(1, RETRY_PASSES + 1):
                if _stop.is_set():
                    break
                recs = load_records()
                failed = [(i, it) for i, it in todo if recs.get(it["url"], {}).get("status") != "ok"]
                if not failed:
                    break
                _p(f"\n{len(failed)} URL(s) failed/blocked. Waiting {DEFER_WAIT_S / 60:.0f} min, then "
                   f"retry pass {n}/{RETRY_PASSES} at a slower pace ...")
                t_end = time.time() + DEFER_WAIT_S
                while time.time() < t_end and not _stop.is_set():
                    time.sleep(2)
                if _stop.is_set():
                    break
                wait_for_internet(_stop)
                with THROTTLE.lock:
                    THROTTLE.rpm = max(float(MIN_RPM), min(THROTTLE.rpm, THROTTLE.ceiling) * 0.6)
                    THROTTLE.pause_until = 0.0
                _run_pass(failed)
        except KeyboardInterrupt:
            _p("Ctrl+C - saving ...")
            _stop.set()
    write_outputs()


def write_outputs():
    recs = load_records()
    ordered = [recs[it["url"]] for it in URL_LIST if it["url"] in recs]
    docs = [r["doc"] for r in ordered]
    write_document_table(docs, OUT_DIR)
    rows = []
    for r in ordered:
        d = r["doc"]
        n = len((d.get("document_sections") or {}).get("rows") or []) or \
            d["link_inventory"]["total_unique"]
        rows.append({"part_url": r["url"], "mpn": d["part_identification"].get("mpn"),
                     "manufacturer": d["part_identification"].get("manufacturer"),
                     "status": r["status"], "access_status": d["source"]["access_status"],
                     "document_links": n, "attempts": d["source"].get("attempts"),
                     "seconds": d["source"].get("duration_seconds"),
                     "failure_kind": d["failures"].get("failure_kind")})
    import pandas as pd
    sdf = pd.DataFrame(rows)
    sdf.to_excel(os.path.join(OUT_DIR, "mouser_harvest_summary.xlsx"), index=False)
    missing = len(URL_LIST) - len(ordered)
    _p(f"\nSummary: {sum(r['status'] == 'ok' for r in ordered)} ok, "
       f"{sum(r['status'] != 'ok' for r in ordered)} failed, {missing} not yet fetched.")
    if WRITE_PER_PART_FILES:
        for r in ordered:
            safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(r["doc"]["part_identification"].get("mpn") or r["idx"]))
            with open(os.path.join(OUT_DIR, f"mouser_docs_{safe}.json"), "w", encoding="utf-8") as fh:
                json.dump(r["doc"], fh, ensure_ascii=False, indent=1)
    _p(THROTTLE.report())
    _p("Results folder:", OUT_DIR)


if __name__ == "__main__":
    run_batch()
