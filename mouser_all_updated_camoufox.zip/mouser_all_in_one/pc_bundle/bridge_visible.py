#!/usr/bin/env python3
"""
bridge_visible.py - same harvest as bridge_all.py, but drives a real, VISIBLE
Camoufox window (stealth Firefox build, via Playwright) per worker instead of
invisible HTTP requests, so you can watch it browse.

Why Camoufox: plain Selenium/geckodriver Firefox announces itself as automated
(navigator.webdriver, remote-control marker) and Mouser's bot protection
reacts to that. Camoufox hides those signs and spoofs a consistent browser
fingerprint.

Requires (menu option 1 does this for you):
    pip install camoufox playwright
    python -m camoufox fetch          (one-time download of the browser)

PROFILE + BROWSER CYCLE
  * The browser is opened fresh for EVERY part and CLOSED as soon as that part
    is finished:  part 1 -> close -> reopen -> part 2 -> ...
  * --profile-mode persistent (default): permanent profile per window in
    camoufox_profile_N/ . Run --setup-login once, solve Mouser's slider by
    hand, and the trust cookie is kept for all later runs.
  * --profile-mode fresh: blank temporary profile (slider every time).
  (Old modes "copy"/"direct" are accepted but behave like persistent: a
  profile from another browser build does not carry over to Camoufox.)
"""
import argparse
import os
import random
import re
import subprocess
import sys
import threading
import time
import concurrent.futures as cf
from urllib.parse import urlparse, quote_plus

import bridge_all as ba  # reuse parsing, CSV writers, queue reader, constants

try:
    from camoufox.sync_api import Camoufox
    from playwright.sync_api import Error as PWError
except ImportError:
    print("Camoufox / Playwright is not installed. Run menu option 1 "
          "(Install dependencies), or:")
    print("    pip install camoufox playwright")
    print("    python -m camoufox fetch")
    sys.exit(1)


HERE = os.path.dirname(os.path.abspath(__file__))
WINDOW_SIZE = (1280, 800)   # --window WxH
TLS_COMPAT = True           # --no-tls-compat to switch off


def automation_dir(widx):
    """Permanent profile folder for window N. Created once, kept forever -
    your Mouser trust cookie lives here and is NEVER deleted by the script."""
    return os.path.join(HERE, f"camoufox_profile_{widx}")


# ------------------------------------------------------------------ browser
def _prefs():
    prefs = {"security.enterprise_roots.enabled": True}
    if TLS_COMPAT:
        # Some ISPs/routers/filters corrupt Firefox's larger TLS handshake
        # (post-quantum key exchange) or QUIC; keep it conventional.
        prefs.update({
            "security.tls.enable_kyber": False,
            "security.tls.enable_mlkem": False,
            "network.http.http3.enable": False,
        })
    return prefs


class Session:
    """One open Camoufox window: .page is the Playwright page."""

    def __init__(self, cm, ctx, page):
        self.cm, self.ctx, self.page = cm, ctx, page

    def close(self):
        try:
            self.cm.__exit__(None, None, None)
        except Exception:
            pass


def make_session(profile_path=None):
    kw = dict(headless=False, humanize=True, os="windows", locale="en-US",
              window=WINDOW_SIZE, firefox_user_prefs=_prefs(),
              i_know_what_im_doing=True)
    if profile_path:
        os.makedirs(profile_path, exist_ok=True)
        kw.update(persistent_context=True, user_data_dir=profile_path)
    optional = ["i_know_what_im_doing", "window", "locale", "firefox_user_prefs"]
    while True:
        cm = Camoufox(**kw)
        try:
            ctx = cm.__enter__()
            break
        except TypeError as exc:
            # older Camoufox versions: drop an option they do not know
            bad = next((k for k in optional if k in str(exc) and k in kw), None)
            if not bad:
                raise
            ba.log(f"this Camoufox version does not accept '{bad}' - "
                   f"continuing without it")
            kw.pop(bad)
    try:
        if profile_path:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            for extra in list(ctx.pages)[1:]:
                try:
                    extra.close()
                except Exception:
                    pass
        else:
            page = ctx.new_page()
    except Exception:
        try:
            cm.__exit__(None, None, None)
        except Exception:
            pass
        raise
    return Session(cm, ctx, page)


def kill_stale_camoufox(profile_dir):
    """Kill leftover camoufox processes that still hold this profile folder
    (they make a new launch fail), then remove stale lock files. Only touches
    processes whose command line mentions the folder name."""
    if sys.platform.startswith("win"):
        needle = os.path.basename(profile_dir.rstrip("\\/"))
        ps = ("Get-CimInstance Win32_Process | "
              "Where-Object { ($_.Name -like 'camoufox*' -or "
              "$_.Name -like 'firefox*') -and "
              f"$_.CommandLine -like '*{needle}*' }} | "
              "ForEach-Object { Stop-Process -Id $_.ProcessId -Force "
              "-ErrorAction SilentlyContinue }")
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, timeout=30)
        except Exception:
            pass
        time.sleep(1.5)
    for name in ("parent.lock", ".parentlock", "lock"):
        try:
            os.remove(os.path.join(profile_dir, name))
        except OSError:
            pass


def setup_login(n_windows):
    """One-time: open Camoufox on each persistent profile, load mouser.com,
    let you pass Mouser's slider / log in by hand, then close it with Enter.
    Cookies are saved in camoufox_profile_N/ ."""
    for i in range(n_windows):
        d = automation_dir(i)
        kill_stale_camoufox(d)
        ba.log(f"profile {i}: opening Camoufox on {d}")
        sess = None
        try:
            sess = make_session(d)
            try:
                sess.page.goto("https://www.mouser.com/", wait_until="commit",
                               timeout=60000)
            except PWError as exc:
                ba.log(f"profile {i}: first page error: "
                       f"{(str(exc).splitlines() or ['?'])[0]}")
            print("\n  1) In the Camoufox window: solve the Mouser slider/"
                  "check and browse until the page loads normally "
                  "(log in too if you need to)."
                  "\n  2) Come back here and press Enter - the window is "
                  "then closed and the cookies are saved.\n")
            input(f"Press Enter when profile {i} is ready... ")
        except Exception as exc:
            ba.log(f"profile {i}: could not start Camoufox: {exc}")
            ba.log("If the browser is missing run:  python -m camoufox fetch")
            return
        finally:
            if sess:
                sess.close()
        kill_stale_camoufox(d)
    ba.log("login setup finished - now run normally (without --setup-login)")


# --------------------------------------------------------------- page logic
def wait_for_page(page, timeout=45.0, human_wait=0.0):
    """Poll a loading page until it is a real Mouser page.
    Returns ("ok"|"blocked"|"timeout", html). A page that is merely still
    loading is NOT a block - only a Google 'sorry' page, a DataDome
    challenge or Mouser's 'Verification Required' page is."""
    end = time.time() + timeout
    t0 = time.time()
    html = ""
    asked = False
    while time.time() < end:
        try:
            url = page.url or ""
            html = page.content() or ""
            ready = page.evaluate("document.readyState")
        except Exception:      # page is mid-navigation - just poll again
            time.sleep(1)
            continue
        low = html.lower()
        # A real Mouser page is large and may mention DataDome/captcha words
        # inside its scripts without being blocked - so text markers only
        # count on SMALL pages (a challenge page is tiny).
        small = len(html) < 60000
        reason = None
        if "google.com/sorry" in url:
            reason = "url contains google.com/sorry"
        elif small and "unusual traffic from your computer" in low:
            reason = "text: unusual traffic from your computer"
        elif small and "captcha-delivery" in low:
            reason = "text: captcha-delivery (DataDome)"
        elif small and "verification required" in low:
            reason = "text: verification required (slider check)"
        elif small and "access to this page has been denied" in low:
            reason = "text: access to this page has been denied"
        if reason:
            wait_for_page.reason = f"{reason}; html_len={len(html)}"
            if human_wait > 0 and ("captcha-delivery" in reason
                                   or "verification required" in reason):
                # Mouser's own check: leave the window open so a human can
                # solve it, then carry on automatically.
                if not asked:
                    asked = True
                    end = max(end, time.time() + human_wait)
                    ba.log(f"Mouser is showing a check/slider - solve it in "
                           f"the Camoufox window (waiting up to "
                           f"{human_wait:.0f}s)")
                time.sleep(2)
                continue
            return "blocked", html
        if ba.looks_real(html) and (ready == "complete"
                                    or time.time() - t0 > 12):
            return "ok", html
        time.sleep(1)
    return ("blocked" if asked else "timeout"), html


wait_for_page.reason = ""

DEBUG_DIR = os.path.join(HERE, "debug")


def describe(page):
    try:
        return f"url={page.url!r} title={page.title()!r}"
    except Exception as exc:
        return f"(browser not reachable: {type(exc).__name__}: " \
               f"{(str(exc).splitlines() or ['?'])[0]})"


def save_debug(page, tag):
    """Save a screenshot + page source so we can see what the browser showed."""
    try:
        os.makedirs(DEBUG_DIR, exist_ok=True)
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in tag)
        stamp = time.strftime("%H%M%S")
        base = os.path.join(DEBUG_DIR, f"{stamp}_{safe}")
        try:
            page.screenshot(path=base + ".png")
        except Exception:
            pass
        try:
            with open(base + ".html", "w", encoding="utf-8") as f:
                f.write(page.content() or "")
        except Exception:
            pass
        ba.log(f"saved debug files: {base}.png / .html")
    except Exception:
        pass


BRIDGE_MODE = "direct"     # "direct" = mouser.com itself, "translate" = Google bridge
CAPTCHA_WAIT = 120.0       # seconds a human gets to solve a Mouser check
NAV_MODE = "human"


def search_url(mpn):
    if BRIDGE_MODE == "direct":
        return f"https://www.mouser.com/c/?q={quote_plus(mpn)}"
    return ba.search_url(mpn)


def product_url(mouser_url):
    if BRIDGE_MODE == "direct":
        return mouser_url
    return bridged_product_url(mouser_url)


def bridged_product_url(mouser_url):
    """Rewrite a real mouser.com product URL onto the translate.goog bridge,
    the same way bridge_all.py's lane1 does."""
    p = urlparse(mouser_url)
    return (f"https://www-mouser-com.translate.goog{p.path}"
            f"?_x_tr_sl=en&_x_tr_tl=es&_x_tr_hl=en")


_REL_HREF = re.compile(r"""(href\s*=\s*["'])(/(?!/)|//)""", re.I)


def absolutize(html):
    """Direct mouser.com pages use relative links (/datasheet/..); the shared
    parsers only keep absolute http links, so make them absolute first."""
    if BRIDGE_MODE != "direct":
        return html
    return _REL_HREF.sub(
        lambda m: m.group(1) + ("https://www.mouser.com/" if m.group(2) == "/"
                                 else "https://"), html)


def _goto(page, url):
    page.goto(url, wait_until="commit", timeout=60000)


def open_url(page, url):
    """Navigate the way a person does. human mode: land on mouser.com first,
    pause, then move inside the site with a page-initiated navigation (real
    Referer, same-origin headers). Returns "ok", or "blocked"/"timeout" if
    the warm-up page itself failed. Raises playwright Error on network
    errors (caller treats those as retry)."""
    if BRIDGE_MODE != "direct" or NAV_MODE != "human":
        _goto(page, url)
        return "ok"
    try:
        cur = page.url or ""
    except Exception:
        cur = ""
    if "mouser.com" not in cur:
        _goto(page, "https://www.mouser.com/")
        st, _ = wait_for_page(page, timeout=30, human_wait=CAPTCHA_WAIT)
        if st != "ok":
            return st
        time.sleep(random.uniform(1.5, 3.5))
        # the slider check can appear a moment AFTER the page first looks ok
        st2, _ = wait_for_page(page, timeout=20, human_wait=CAPTCHA_WAIT)
        if st2 == "blocked":
            return st2
        try:
            cur = page.url or ""
        except Exception:
            cur = ""
    # Mouser geo-redirects (e.g. www.mouser.com -> eu.mouser.com). Stay on
    # the host the browser is actually on: another mouser host may fail TLS.
    try:
        cur_host = urlparse(cur).netloc
        u = urlparse(url)
        if (cur_host.endswith("mouser.com") and u.netloc.endswith("mouser.com")
                and u.netloc != cur_host):
            url = u._replace(netloc=cur_host).geturl()
    except Exception:
        pass
    try:
        page.evaluate("u => { window.location.assign(u); }", url)
    except PWError:
        pass          # the navigation can tear down the evaluate context
    for _ in range(40):                      # wait for the URL to change
        time.sleep(0.5)
        try:
            if (page.url or "") != cur:
                break
        except Exception:
            pass
    return "ok"


def _err1(exc):
    return (str(exc).splitlines() or ["?"])[0]


# --------------------------------------------------------------------- main
def main():
    global BRIDGE_MODE, CAPTCHA_WAIT, NAV_MODE, WINDOW_SIZE, TLS_COMPAT

    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default=ba._default_input())
    ap.add_argument("--mode", choices=["search", "all"], default="all")
    ap.add_argument("--rpm", type=float, default=6.0)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--heartbeat", type=int, default=60)
    ap.add_argument("--profile-mode",
                    choices=["persistent", "fresh", "copy", "direct"],
                    default="persistent",
                    help="persistent = permanent Camoufox profile you pass "
                         "Mouser's check in once with --setup-login "
                         "(default); fresh = blank temporary profile; "
                         "copy/direct = old modes, treated as persistent")
    ap.add_argument("--bridge", choices=["direct", "translate"],
                    default="direct",
                    help="direct = load mouser.com itself (no Google, "
                         "default); translate = old Google translate.goog "
                         "bridge")
    ap.add_argument("--nav", choices=["human", "plain"], default="human",
                    help="human = visit mouser.com first, then move inside "
                         "the site like a person (default); plain = direct "
                         "goto() for every page")
    ap.add_argument("--captcha-wait", type=float, default=120.0,
                    help="direct mode: seconds to leave the window open so "
                         "you can solve a Mouser check by hand")
    ap.add_argument("--window", default="1280x800",
                    help="browser window size WxH (default 1280x800)")
    ap.add_argument("--no-tls-compat", action="store_true",
                    help="do not disable post-quantum TLS / HTTP3 in the "
                         "browser (only needed if your network handles "
                         "them fine)")
    ap.add_argument("--setup-login", action="store_true",
                    help="one-time: open Camoufox so you can pass Mouser's "
                         "check by hand; cookies are saved in the profile")
    ap.add_argument("--fetch", action="store_true",
                    help="download/update the Camoufox browser, then exit")
    # accepted for backwards compatibility with the Chrome/Firefox versions
    ap.add_argument("--refresh-profile", action="store_true",
                    help=argparse.SUPPRESS)
    ap.add_argument("--close-firefox", action="store_true",
                    help=argparse.SUPPRESS)
    ap.add_argument("--close-chrome", action="store_true",
                    help=argparse.SUPPRESS)
    ap.add_argument("--firefox-profile", default=None, help=argparse.SUPPRESS)
    ap.add_argument("--chrome-user-data", default=None, help=argparse.SUPPRESS)
    ap.add_argument("--chrome-profile", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()

    if args.fetch:
        subprocess.run([sys.executable, "-m", "camoufox", "fetch"])
        return

    BRIDGE_MODE = args.bridge
    NAV_MODE = args.nav
    CAPTCHA_WAIT = args.captcha_wait
    TLS_COMPAT = not args.no_tls_compat
    try:
        w, h = (int(v) for v in args.window.lower().split("x"))
        WINDOW_SIZE = (w, h)
    except Exception:
        print(f"bad --window {args.window!r}, using 1280x800")

    if args.profile_mode in ("copy", "direct"):
        ba.log(f"--profile-mode {args.profile_mode} is not available with "
               f"Camoufox - using persistent")
        args.profile_mode = "persistent"

    if args.setup_login:
        setup_login(args.workers)
        return

    queue = ba.read_mpn_queue(args.file)
    done = ba.load_done()
    todo = [m for m in queue if f"{args.mode}:{m}" not in done]
    if args.limit:
        todo = todo[: args.limit]
    ba.log(f"mode={args.mode} VISIBLE-Camoufox bridge={args.bridge} "
           f"queue={len(queue)} "
           f"done_total={len(done)} todo={len(todo)} rpm={args.rpm} "
           f"workers={args.workers}")
    if not todo:
        ba.log("nothing to do")
        return

    lock = threading.Lock()
    stats = {"ok": 0, "fail": 0}

    q_lock = threading.Lock()
    idx_iter = iter(range(len(todo)))

    retry_parts = []
    attempts = {}

    def next_part():
        with q_lock:
            if retry_parts:
                return retry_parts.pop()
            i = next(idx_iter, None)
            return None if i is None else todo[i]

    # ---- global block gate: pause every window and let one of them
    # re-probe on a cooldown ----
    gate = {"blocked": False}
    glock = threading.Lock()

    def wait_gate():
        while gate["blocked"]:
            time.sleep(3)

    def bridge_blocked(reason, probe):
        """All windows pause. Browsers are CLOSED while waiting; every
        re-probe opens a fresh Camoufox and closes it again."""
        with glock:
            if gate["blocked"]:
                return
            gate["blocked"] = True
        wait = 300.0
        ba.log(f"BLOCKED ({reason}): all windows paused, browsers closed; "
               f"re-probing in {wait / 60:.0f} min")
        try:
            while True:
                time.sleep(wait * random.uniform(0.9, 1.1))
                if probe():
                    ba.log("bridge healthy again - resuming windows")
                    return
                wait = min(wait * 1.5, 1800.0)
                ba.log(f"still blocked; next probe in {wait / 60:.0f} min")
        finally:
            gate["blocked"] = False

    def profile_for(widx):
        if args.profile_mode == "fresh":
            return None
        return automation_dir(widx)

    if args.profile_mode == "persistent":
        for i in range(args.workers):
            if not os.path.isdir(automation_dir(i)):
                ba.log(f"profile {i} has no saved Mouser cookies yet. Run "
                       f"once:  python bridge_visible.py --setup-login "
                       f"--workers {args.workers}")
        ba.log("persistent Camoufox profile in use (cookies are kept; the "
               "browser is still closed/reopened for every part)")
    else:
        ba.log("fresh profile mode: blank profile every part (expect the "
               "Mouser slider often)")

    def handle_part(page, widx, mpn):
        """Do ONE part in an already-open browser.
        Returns "ok", "retry" (slow/failed load - try again later) or
        "blocked" (DataDome/Mouser block - pause everything)."""
        hw = CAPTCHA_WAIT if BRIDGE_MODE == "direct" else 0
        try:
            st0 = open_url(page, search_url(mpn))
            if st0 != "ok":
                ba.log(f"window {widx}: mouser.com home page itself was "
                       f"{st0}: reason=[{wait_for_page.reason}] "
                       f"{describe(page)}")
                save_debug(page, f"{mpn}_home_{st0}")
                return "blocked" if st0 == "blocked" else "retry"
        except PWError as exc:
            ba.log(f"window {widx} nav error {mpn}: {type(exc).__name__}: "
                   f"{_err1(exc)} | {describe(page)}")
            return "retry"
        st, html = wait_for_page(page, human_wait=hw)
        if st == "blocked":
            ba.log(f"window {widx}: BLOCK page for {mpn}: "
                   f"reason=[{wait_for_page.reason}] {describe(page)}")
            save_debug(page, f"{mpn}_search_blocked")
            return "blocked"
        if st == "timeout":
            ba.log(f"window {widx}: page for {mpn} did not finish loading: "
                   f"{describe(page)}")
            save_debug(page, f"{mpn}_search_timeout")
            return "retry"

        html = absolutize(html)
        for row in ba.extract_pcn_rows(html):
            ba.append_pcn({**row, "MPN": mpn, "DocumentType": "PCN",
                           "Source": "search"})

        if args.mode == "search":
            ba.mark_done(f"search:{mpn}")
            with lock:
                stats["ok"] += 1
            ba.log(f"OK(search) {mpn}")
            return "ok"

        # An exact part number often redirects the search straight to the
        # product page - then there is nothing more to open.
        try:
            on_product = "/productdetail/" in (page.url or "").lower()
        except Exception:
            on_product = False

        if on_product:
            phtml = html
        else:
            purl = ba.extract_product_url(html)
            if not purl:
                with lock:
                    stats["fail"] += 1
                ba.append_result({"part": mpn, "status": "fail",
                                  "reason": "no_product_url"})
                ba.mark_done(f"all:{mpn}")
                ba.log(f"FAIL {mpn}: no product url")
                return "ok"
            try:
                open_url(page, product_url(purl))
            except PWError as exc:
                ba.log(f"window {widx} nav error {mpn} product: "
                       f"{_err1(exc)}")
                return "retry"
            st, phtml = wait_for_page(page, human_wait=hw)
            if st == "blocked":
                ba.log(f"window {widx}: BLOCK page (product) for {mpn}: "
                       f"reason=[{wait_for_page.reason}] {describe(page)}")
                save_debug(page, f"{mpn}_product_blocked")
                return "blocked"
            if st == "timeout":
                ba.log(f"window {widx}: product page for {mpn} did not "
                       f"finish loading: {describe(page)}")
                save_debug(page, f"{mpn}_product_timeout")
                return "retry"

        meta, docs = ba.extract_docs(absolutize(phtml))
        rec = {"part": mpn, "status": "ok",
               "part_number": meta.get("part_number", mpn),
               "manufacturer": meta.get("manufacturer", ""),
               "documents": docs}
        ba.append_result(rec)
        ba.mark_done(f"all:{mpn}")
        with lock:
            stats["ok"] += 1
        ba.log(f"OK {mpn} ({sum(len(v) for v in docs.values())} docs)")
        return "ok"

    def worker(widx):
        udir = profile_for(widx)
        delay = 60.0 / max(0.5, args.rpm)
        launch_fails = 0
        while True:
            mpn = next_part()
            if mpn is None:
                return
            wait_gate()

            # ---- OPEN a fresh browser for this part ----
            sess = None
            try:
                ba.log(f"window {widx}: opening Camoufox for {mpn}")
                if udir:
                    kill_stale_camoufox(udir)   # free the folder first
                sess = make_session(udir)
                launch_fails = 0
            except Exception as exc:
                launch_fails += 1
                msg = _err1(exc)
                ba.log(f"window {widx}: could not start Camoufox ({mpn}): "
                       f"{type(exc).__name__}: {msg}")
                if any(k in str(exc).lower() for k in
                       ("fetch", "not installed", "executable", "not found",
                        "version")):
                    ba.log("the browser may be missing - run:  "
                           "python bridge_visible.py --fetch")
                with q_lock:
                    retry_parts.append(mpn)   # put the part back
                if launch_fails >= 3:
                    ba.log(f"window {widx}: giving up after 3 failed "
                           f"launches. Send me the lines above.")
                    return
                if udir:
                    kill_stale_camoufox(udir)
                time.sleep(3)
                continue

            # ---- do the part, then ALWAYS close the browser ----
            result = "retry"
            try:
                result = handle_part(sess.page, widx, mpn)
            except Exception as exc:
                import traceback
                ba.log(f"window {widx} error on {mpn}: "
                       f"{type(exc).__name__}: {exc}\n"
                       f"{traceback.format_exc()}")
                save_debug(sess.page, f"{mpn}_exception")
            finally:
                sess.close()
                ba.log(f"window {widx}: Camoufox closed after {mpn} "
                       f"(result={result})")

            if result == "blocked":
                with q_lock:
                    retry_parts.append(mpn)

                def probe():
                    s2 = None
                    try:
                        if udir:
                            kill_stale_camoufox(udir)
                        s2 = make_session(udir)
                        _goto(s2.page, search_url("GRM1555C1E2R2CA01D"))
                        return wait_for_page(s2.page,
                                             human_wait=0)[0] == "ok"
                    except Exception:
                        return False
                    finally:
                        if s2:
                            s2.close()
                bridge_blocked(f"search {mpn}", probe)
            elif result == "retry":
                attempts[mpn] = attempts.get(mpn, 0) + 1
                if attempts[mpn] < 3:
                    with q_lock:
                        retry_parts.append(mpn)
                else:
                    ba.log(f"SKIP {mpn}: failed 3 times (left un-done, "
                           f"a later run will retry it)")
                time.sleep(5)
            else:
                # browser is closed during this pause, then loop -> reopen
                time.sleep(delay * random.uniform(0.8, 1.2))

    def _heartbeat():
        while True:
            time.sleep(args.heartbeat)
            ba.log(f"heartbeat: ok={stats['ok']} fail={stats['fail']} "
                   f"(still running)")
    if args.heartbeat > 0:
        threading.Thread(target=_heartbeat, daemon=True).start()

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = [pool.submit(worker, i) for i in range(args.workers)]
        for f in futs:
            try:
                f.result()
            except Exception as exc:
                import traceback
                ba.log("WORKER CRASH: " + type(exc).__name__ + ": " + str(exc))
                ba.log(traceback.format_exc())

    n = ba.write_final_csv()
    npcn = ba.write_pcn_csv()
    ba.log(f"DONE. final rows={n} pcn rows={npcn}")


if __name__ == "__main__":
    main()
