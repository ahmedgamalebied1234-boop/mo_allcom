#!/usr/bin/env python3
"""Offline selftest for bridge_all.py parsers."""
import sys
sys.path.insert(0, "/home/z/my-project/scripts")
import bridge_all as B

SEARCH_HTML = """
<html><body>
<a class="link" href="https://www-mouser-com.translate.goog/en/ProductDetail/Murata-Electronics/GRM1555C1E2R2CA01D?qs=QzBtWTOodeW76Svy%2Fgmong%3D%3D&_x_tr_sl=en">GRM1555C1E2R2CA01D</a>
<a href="/en/ProductDetail/Other/XX?qs=a%3D%3D">decoy relative</a>
</body></html>
"""

PRODUCT_HTML = """
<html><head><title>GRM1555C1E2R2CA01D Murata Electronics | Mouser</title></head>
<body>
<div class="pdp-product-datasheets">
 <a href="https://translate.google.com/website?sl=en&u=https%3A%2F%2Fpim.murata.com%2Fasset%2Fds.pdf">Datasheet</a>
</div>
<h2 class="card-header-title">PCN/EOL/Product Change Notices</h2>
<div>
 <a href="https://www-mouser-com.translate.goog/PCN/Murata_PCN_2026_001.pdf?_x_tr_sl=en">Product Change Notification 3/2026 (PDF)</a>
</div>
<h2 class="card-header-title">Environmental Documents</h2>
<div><a href="https://www.mouser.com/envdocs/env.pdf">Env</a></div>
<h2 class="card-header-title">3D Models</h2>
<div><a href="https://www.mouser.com/assets/3dmodel/step.stp">STEP</a></div>
</body></html>
"""

# 1. product link extraction
purl = B.extract_product_url(SEARCH_HTML)
assert purl == ("https://www.mouser.com/en/ProductDetail/Murata-Electronics/"
                "GRM1555C1E2R2CA01D?qs=QzBtWTOodeW76Svy%2Fgmong%3D%3D"), purl
print("product link extraction PASSED:", purl[:80])

# 2. lane builders
l1 = B.lane1(purl)
assert "?qs=QzBtWTOodeW76Svy%2Fgmong%3D%3D&_x_tr_sl=en" in l1, l1
l2 = B.lane2(purl)
assert "?qs" not in l2 and "_x_tr_sl=en" in l2, l2
assert B.lane3(purl).startswith("https://translate.google.com/website?")
print("lane builders PASSED:", l1[:100])

# 3. full doc extraction from product page
meta, docs = B.extract_docs(PRODUCT_HTML)
assert meta.get("part_number") == "GRM1555C1E2R2CA01D"
assert meta.get("manufacturer") == "Murata Electronics"
assert any("pim.murata.com/asset/ds.pdf" in u for u in docs.get("Datasheets", []))
assert any("/PCN/Murata_PCN_2026_001.pdf" in u
           for u in docs.get("PCN/EOL/Product Change Notices", []))
assert any("/envdocs/env.pdf" in u or "envdocs" in u
           for sec in docs.values() for u in sec)
assert any("3dmodel" in u or "step" in u
           for sec in docs.values() for u in sec)
print("all-docs extraction PASSED:", {k: len(v) for k, v in docs.items()})

# 4. PCN rows from product page
pcn = B.extract_pcn_rows(PRODUCT_HTML)
assert len(pcn) == 1 and "Murata_PCN_2026_001.pdf" in pcn[0]["DocumentURL"]
assert pcn[0]["LastUpdated"] == "3/2026"
print("PCN extraction PASSED:", pcn[0]["DocumentID"])

# 5. challenge classifier
assert B.is_challenge("<html>datadome captcha-delivery</html>")
assert not B.is_challenge("<html>" + "x" * 40000 + " datadome </html>")
print("challenge classifier PASSED")
print("ALL SELFTESTS PASSED")
