#!/usr/bin/env python3
"""
bkeeper2.py — probe-gated supervisor for bridge_all.py (all-doc-types harvest)

- Polls /proc for a live bridge_all.py child every 15s
- Launches children as double-forked orphans (PPid=1) ONLY when the Google
  bridge probe returns 200 (no hammering during penalty phases)
- Degrades WORKERS 8->6->4 on rapid child deaths; restores after 30 stable min
- Exits when bridge_done.txt has >= TARGET "all:" tags
"""
import os
import sys
import time
from datetime import datetime

sys.path.insert(0, "/home/z/my-project/scripts")
import bridge_all  # noqa: E402  (reuse probe_ok + search_url)

_HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable   # portable: same interpreter running the keeper
SCRIPT = os.path.join(_HERE, "bridge_all.py")
_SANDBOX = os.path.isdir("/home/z/my-project/repo-mm")
REPO = os.environ.get("MM_REPO") or (
    "/home/z/my-project/repo-mm" if _SANDBOX
    else os.path.join(_HERE, "mm_data"))
DONEF = os.path.join(REPO, "bridge_done.txt")
LOG = os.path.join(REPO, "bkeeper2.log")
os.makedirs(REPO, exist_ok=True)   # PC: creates mm_data/ automatically
TARGET = int(os.environ.get("TARGET", "3890"))
WORKERS = int(os.environ.get("WORKERS", "8"))
RPM = os.environ.get("RPM", "6")

S = {"workers": max(4, WORKERS - 4), "deaths": 0, "last_death": 0.0,
     "last_launch": 0.0, "last_probe": 0.0, "last_probe_ok": False,
     "last_probe_logged": None, "stable_start": 0.0,
     "ok_streak": 0, "last_refresh": 0.0}   # gentle ramp: start low, +2/30min


def log(msg):
    with open(LOG, "a") as fh:
        fh.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")


def count_done():
    try:
        with open(DONEF) as fh:
            return sum(1 for l in fh if l.strip().startswith("all:"))
    except OSError:
        return 0


def find_child():
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as fh:
                cmd = fh.read().replace(b"\0", b" ").decode("utf-8", "ignore")
        except OSError:
            continue
        if "bridge_all.py" in cmd and "--mode" in cmd:
            return int(pid)
    return None


def child_state(pid):
    try:
        with open(f"/proc/{pid}/stat") as fh:
            return fh.read().split(") ", 1)[1].split(" ")[0]  # T=stopped
    except OSError:
        return "?"


def launch_orphan(limit):
    if os.name == "nt":
        # Windows: detached child (no fork available)
        import subprocess
        flags = 0x00000200 | 0x00000008   # CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS
        out = open(os.path.join(REPO, "bridge_boot3.log"), "a")
        subprocess.Popen([PY, "-u", SCRIPT, "--mode", "all",
                          "--rpm", RPM, "--workers", str(S["workers"]),
                          "--limit", str(limit)],
                         stdin=subprocess.DEVNULL, stdout=out,
                         stderr=subprocess.STDOUT, creationflags=flags)
        return
    pid = os.fork()
    if pid == 0:
        try:
            os.setsid()
            if os.fork() == 0:
                os.close(0)
                devnull = os.open(os.devnull, os.O_RDONLY)
                os.dup2(devnull, 0)
                out = os.open(os.path.join(REPO, "bridge_boot3.log"),
                              os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
                os.dup2(out, 1)
                os.dup2(out, 2)
                os.execv(PY, [PY, "-u", SCRIPT, "--mode", "all",
                              "--rpm", RPM, "--workers", str(S["workers"]),
                              "--limit", str(limit)])
        except Exception:
            pass
        os._exit(0)
    os.waitpid(pid, 0)


def main():
    log(f"keeper v2 start target={TARGET} workers={S['workers']} rpm={RPM} "
        f"pid={os.getpid()}")
    while True:
        try:
            done = count_done()
            if done >= TARGET:
                log(f"TARGET REACHED all-done={done} - exiting")
                return 0

            child = find_child()
            now = time.time()
            if child is not None:
                S["deaths"] = 0
                if now - S.get("stable_start", now) > 1800 and S["workers"] < WORKERS:
                    S["workers"] = min(WORKERS, S["workers"] + 2)
                    log(f"stable 30min - workers back to {S['workers']}")
                    S["stable_start"] = now
                # revive a manually-frozen child when bridge is healthy
                if child_state(child) == "T":
                    if not S["last_probe_ok"] or now - S["last_probe"] > 60:
                        S["last_probe_ok"] = bridge_all.probe_ok(
                            _mk_session())
                        S["last_probe"] = now
                    if S["last_probe_ok"]:
                        try:
                            os.kill(child, 18)  # SIGCONT (POSIX only)
                        except (OSError, AttributeError):
                            pass
                        log(f"child {child} was frozen; bridge OK -> SIGCONT")
                time.sleep(15)
                continue

            if now - S["last_launch"] < 30:
                time.sleep(5)
                continue
            if now - S["last_probe"] > 45:
                S["last_probe_ok"] = bridge_all.probe_ok(_mk_session())
                S["last_probe"] = now
                # require 2 consecutive healthy probes before launching:
                # a single lucky 200 must not burn the unblock window
                if S["last_probe_ok"]:
                    S["ok_streak"] = min(3, S["ok_streak"] + 1)
                else:
                    S["ok_streak"] = 0
                state = ("OK" if S["last_probe_ok"] else "BLOCKED")
                if (state, S["ok_streak"]) != S.get("last_probe_logged"):
                    log(f"probe {state} streak={S['ok_streak']}")
                    S["last_probe_logged"] = (state, S["ok_streak"])
            if not S["last_probe_ok"] or S["ok_streak"] < 2:
                # keep the user-facing CSV fresh even while throttled
                if now - S["last_refresh"] > 300:
                    try:
                        nfa = bridge_all.write_final_csv()
                        npc = bridge_all.write_pcn_csv()
                        log(f"csv refresh (idle): final={nfa} pcn={npc}")
                    except Exception as exc:
                        log(f"csv refresh error: {type(exc).__name__}")
                    S["last_refresh"] = now
                time.sleep(30)
                continue

            if (now - S["last_death"] < 600 and S["deaths"] >= 3
                    and S["workers"] > 4):
                S["workers"] = max(4, S["workers"] - 2)
                log(f"rapid child deaths ({S['deaths']}) - workers -> "
                    f"{S['workers']}")
                S["deaths"] = 0
            remain = TARGET - done
            log(f"probe OK x{S['ok_streak']}, no child (all-done={done}) - "
                f"launch workers={S['workers']} limit={remain + 20}")
            launch_orphan(remain + 20)
            S["last_launch"] = now
            S["last_death"] = now
            S["stable_start"] = now
            S["ok_streak"] = 0
            time.sleep(10)
        except KeyboardInterrupt:
            return 0
        except Exception as exc:
            log(f"loop error: {type(exc).__name__}: {str(exc)[:80]}")
            time.sleep(15)


def _mk_session():
    import requests
    s = requests.Session()
    s.headers.update(bridge_all.HDRS)
    return s


if __name__ == "__main__":
    sys.exit(main())
