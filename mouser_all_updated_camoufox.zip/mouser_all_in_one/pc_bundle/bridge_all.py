#!/usr/bin/env python3
"""
bridge_all.py — FULL document-type harvest THROUGH GOOGLE IPs
==============================================================

Per part (MPN):
  1. GET /en/c/?q={MPN} via translate.goog      -> PCN rows (user spec) + product URL
  2. GET product page via bridge (3-lane fallback):
       L1 host-rewrite with qs  L2 host-rewrite no-qs  L3 website-mode u=
  3. extract ALL doc sections (accordion h2 + datasheet panel) -> results.jsonl
  4. final_all.csv: Manufacturer, Doc Type, Doc Link, Part Number

Checkpoint-safe: bridge_done.txt ("search:MPN" / "all:MPN")
"""
import argparse
import html as htmlmod
import json
import os
import random
import re
import sys
import time
from datetime import datetime
from urllib.parse import quote_plus, quote, unquote, urlparse

import requests

_HERE = os.path.dirname(os.path.abspath(__file__))
# Portable paths: sandbox keeps legacy locations; on a user PC everything
# lives next to the script (override with MM_REPO / MM_FINAL env vars).
_SANDBOX = os.path.isdir("/home/z/my-project/repo-mm")
REPO = os.environ.get("MM_REPO") or (
    "/home/z/my-project/repo-mm" if _SANDBOX
    else os.path.join(_HERE, "mm_data"))
DONEF = os.path.join(REPO, "bridge_done.txt")
LOGF = os.path.join(REPO, "bridge_all.log")
RESULTS = os.path.join(REPO, "mouser_harvest", "results.jsonl")
PCN_JSONL = os.path.join(REPO, "pcn_docs.jsonl")
PCN_CSV = os.path.join(REPO, "pcn_docs.csv")
FINAL_CSV = os.environ.get("MM_FINAL") or (
    "/home/z/my-project/download/final_all.csv" if _SANDBOX
    else os.path.join(_HERE, "final_all.csv"))
os.makedirs(REPO, exist_ok=True)   # PC: creates mm_data/ automatically


def _default_input():
    if os.path.exists("/home/z/my-project/repo-5k/a4.xlsx"):
        return "/home/z/my-project/repo-5k/a4.xlsx"
    for cand in (os.path.join(_HERE, "a4.xlsx"),
                 os.path.join(_HERE, "inputs", "a4.xlsx")):
        if os.path.exists(cand):
            return cand
    return os.path.join(_HERE, "inputs", "a4.xlsx")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
HDRS = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}

# ---------- link de-translation ----------
UWRAP_RE = re.compile(r"translate\.google\.com/website\?[^\"']*&u=([^\"&]+)")
GOOG_RE = re.compile(r"https?://www-mouser-com\.translate\.goog(/[^\"']*)", re.I)
A_RE = re.compile(r"<a\b[^>]*?href\s*=\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
                  re.I | re.S)
TAG_RE = re.compile(r"<[^>]+>")
H2_RE = re.compile(r'<h2 class="card-header-title"[^>]*>(.*?)</h2>', re.I | re.S)
TITLE_RE = re.compile(r"<title>(.*?)</title>", re.I | re.S)
MOUSERPN_RE = re.compile(r'"event_mouserpn"\s*:\s*"([^"]+)"')
MFVPN_RE = re.compile(r'"event_manufacturerpn"\s*:\s*"([^"]+)"')
BRAND_RE = re.compile(r'"event_brand"\s*:\s*"([^"]+)"')

# PCN per user spec
A_PCN_RE = re.compile(
    r'<a\b[^>]*?href\s*=\s*["\']([^"\']*?/PCN/[^"\']+?\.pdf[^"\']*)["\'][^>]*>'
    r'(.*?)</a>', re.IGNORECASE | re.DOTALL)
PCN_TEXT_RE = re.compile(r"product\s*change\s*notification", re.IGNORECASE)
DATE_RE = re.compile(r"(\d{1,2}/\d{4}|\d{4}-\d{1,2}-\d{1,2}|\b(?:Jan|Feb|Mar|Apr|May|Jun"
                     r"|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}\b)", re.IGNORECASE)

PRODUCT_LINK_RE = re.compile(
    r'href\s*=\s*["\']([^"\']*?/ProductDetail/[^"\']+)["\']', re.I)

DOC_KEYS = ("/datasheet/", "/pcn/", "/pdf/", "/assets/", "pim.", "/documents/",
            ".pdf", "/env/", "environmental", "applicationnote", "/refdesign/",
            "/eol/", "/model", "3dmodel", "cad/", "/step/", "spec/")


def log(msg):
    line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOGF, "a") as fh:
        fh.write(line + "\n")


def de_translate(href):
    m = UWRAP_RE.search(href)
    if m:
        return unquote(m.group(1))
    m = GOOG_RE.match(href)
    if m:
        rest = m.group(1)
        if "_x_tr_" in rest:
            path, _, q = rest.partition("?")
            keep = [kv for kv in q.split("&")
                    if kv and not kv.lower().startswith("_x_tr_")]
            rest = path + ("?" + "&".join(keep) if keep else "")
        return "https://www.mouser.com" + rest
    return href


def clean(text):
    t = TAG_RE.sub(" ", text or "")
    t = htmlmod.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


def load_done():
    done = set()
    if os.path.exists(DONEF):
        with open(DONEF) as fh:
            done = {l.strip() for l in fh if l.strip()}
    return done


def mark_done(tag):
    with open(DONEF, "a") as fh:
        fh.write(tag.strip() + "\n")


def append_result(rec):
    os.makedirs(os.path.dirname(RESULTS), exist_ok=True)
    with open(RESULTS, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")


def extract_docs(page_html):
    meta, docs = {}, {}
    m = TITLE_RE.search(page_html)
    title = clean(m.group(1)) if m else ""
    if "|" in title:
        left = title.split("|")[0].strip()
        toks = left.split(" ", 1)
        if len(toks) == 2:
            meta["part_number"], meta["manufacturer"] = toks[0], toks[1]
        else:
            meta["part_number"] = left
    for rx, key in ((MOUSERPN_RE, "mouser_pn"), (MFVPN_RE, "mpn"),
                    (BRAND_RE, "manufacturer")):
        m = rx.search(page_html)
        if m:
            meta[key] = m.group(1) if key != "manufacturer" else m.group(1).title()
    SKIP = ("javascript:", "#", "javascript:void")

    def harvest_links(chunk, section):
        urls = []
        for href, _txt in A_RE.findall(chunk):
            h = htmlmod.unescape(href).strip()
            if h.lower().startswith(SKIP):
                continue
            u = de_translate(h)
            if not u.lower().startswith("http"):
                continue
            if any(k in u.lower() for k in DOC_KEYS):
                if u not in urls:
                    urls.append(u)
        if urls:
            docs.setdefault(section, [])
            for u in urls:
                if u not in docs[section]:
                    docs[section].append(u)

    heads = list(H2_RE.finditer(page_html))
    for i, h in enumerate(heads):
        section = clean(h.group(1))
        if not section:
            continue
        start = h.end()
        end = heads[i + 1].start() if i + 1 < len(heads) else len(page_html)
        harvest_links(page_html[start:end], section)
    i = page_html.find("pdp-product-datasheets")
    if i > -1:
        nxt = page_html.find("card-header", i)
        end = nxt if nxt > -1 else i + 6000
        harvest_links(page_html[i:end], "Datasheets")
    if not meta.get("part_number"):
        m = re.search(r'"mpn"\s*:\s*"([^"]+)"', page_html)
        if m:
            meta["part_number"] = m.group(1)
    return meta, docs


def extract_pcn_rows(page_html):
    rows = []
    for href, inner in A_PCN_RE.findall(page_html):
        text = clean(inner)
        if not PCN_TEXT_RE.search(text):
            continue
        url = de_translate(htmlmod.unescape(href))
        if url.startswith("/"):
            url = "https://www.mouser.com" + url
        doc_id = os.path.basename(url.split("?")[0].split("#")[0])
        m = DATE_RE.search(text)
        rows.append({"DocumentTitle": text, "DocumentURL": url,
                     "DocumentID": doc_id,
                     "LastUpdated": m.group(1) if m else ""})
    seen, uniq = set(), []
    for r in rows:
        if r["DocumentURL"] in seen:
            continue
        seen.add(r["DocumentURL"])
        uniq.append(r)
    return uniq


def append_pcn(rec):
    with open(PCN_JSONL, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")


def write_pcn_csv():
    import csv as _csv
    cols = ["MouserPartNumber", "Manufacturer", "MPN", "DocumentType",
            "DocumentTitle", "DocumentURL", "DocumentID", "Source", "LastUpdated"]
    rows, seen = [], set()
    if os.path.exists(PCN_JSONL):
        with open(PCN_JSONL, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                k = (r.get("MPN"), r.get("DocumentURL"))
                if k in seen:
                    continue
                seen.add(k)
                rows.append(r)
    with open(PCN_CSV, "w", newline="", encoding="utf-8-sig") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in cols})
    return len(rows)


def write_final_csv():
    import csv as _csv
    recs = []
    if os.path.exists(RESULTS):
        with open(RESULTS, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    if r.get("status") == "ok":
                        recs.append(r)
                except Exception:
                    pass
    seen, rows = set(), []
    for r in recs:
        pn = r.get("part_number") or r.get("part") or ""
        mfr = r.get("manufacturer") or ""
        for sec, links in (r.get("documents") or {}).items():
            if not sec or sec in ("Select Attribute", "FEATURED PRODUCTS"):
                continue
            if isinstance(links, str):
                links = [links]
            for u in links or []:
                k = (mfr, sec, u, pn)
                if k in seen:
                    continue
                seen.add(k)
                rows.append([mfr, sec, u, pn])
    os.makedirs(os.path.dirname(FINAL_CSV), exist_ok=True)
    with open(FINAL_CSV, "w", newline="", encoding="utf-8-sig") as fh:
        w = _csv.writer(fh)
        w.writerow(["Manufacturer", "Doc Type", "Doc Link", "Part Number"])
        w.writerows(rows)
    return len(rows)


def read_mpn_queue(path):
    # plain-text / CSV lists: one part per line (first column); '#' = comment
    if path.lower().endswith((".txt", ".csv")):
        import csv as _csv
        out, seen = [], set()
        with open(path, encoding="utf-8-sig", newline="") as fh:
            for row in _csv.reader(fh):
                v = (row[0] if row else "").strip()
                if not v or v.startswith("#"):
                    continue
                if v.lower() in ("part", "mpn", "part number", "partnumber"):
                    continue          # header row
                if v.upper() in seen:
                    continue
                seen.add(v.upper())
                out.append(v)
        return out
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    hdr = [str(c or "").strip().lower() for c in rows[0]]
    pi = hdr.index("part") if "part" in hdr else 0
    out = []
    for r in rows[1:]:
        v = str(r[pi] or "").strip()
        if v and " " not in v:
            out.append(v)
    return out


# ---------- bridge lanes ----------
def lane1(url):
    """host-rewrite with query (fixed: & separator when path already has ?)"""
    p = urlparse(url)
    path = p.path or "/"
    sep = "?"
    if p.query:
        path += "?" + p.query
        sep = "&"
    return (f"https://www-mouser-com.translate.goog{path}"
            f"{sep}_x_tr_sl=en&_x_tr_tl=es&_x_tr_hl=en")


def lane2(url):
    """host-rewrite without query (Mouser 301s to canonical)"""
    p = urlparse(url)
    return (f"https://www-mouser-com.translate.goog{p.path}"
            f"?_x_tr_sl=en&_x_tr_tl=es&_x_tr_hl=en")


def lane3(url):
    """website mode, fully encoded u param"""
    return ("https://translate.google.com/website?sl=en&tl=es&hl=en&u="
            + quote(url, safe=""))


GOOG_SORRY_MARKERS = ("google.com/sorry", "unusual traffic from your computer",
                      "g-recaptcha", "/recaptcha/", "not a robot")


def is_challenge(text):
    """DataDome challenge OR Google rate-limit sorry page (302->sorry->200)."""
    low = text.lower()
    if any(m in low for m in GOOG_SORRY_MARKERS):
        return True
    return ("captcha-delivery" in low or
            "access to this page has been denied" in low or
            ("datadome" in low and len(text) < 30000))


def looks_real(text):
    """True only for genuine Mouser pages (search or product).

    Guards against marking parts done on translated Google error pages,
    whose rewritten domain www-mouser-com contains the word 'mouser' -
    so we require spaced brand strings / dataLayer markers instead.
    """
    if not text or len(text) < 15000:
        return False
    low = text.lower()
    return ("mouser electronics" in low or '"event_brand"' in low
            or "event_mouserpn" in low or '"event_mouserpn"' in low)


def search_url(mpn):
    return (f"https://www-mouser-com.translate.goog/en/c/?q={quote_plus(mpn)}"
            f"&_x_tr_sl=en&_x_tr_tl=es&_x_tr_hl=en")


def probe_ok(session):
    """Healthy probe = HTTP 200, no challenge, AND a real Mouser page.

    A Google sorry page that arrives via 302->200 used to pass the old
    status-only check and made the keeper launch into a blocked bridge.
    """
    try:
        r = session.get(search_url("GRM1555C1E2R2CA01D"), timeout=30)
        return (r.status_code == 200 and not is_challenge(r.text)
                and looks_real(r.text))
    except Exception:
        return False


def extract_product_url(search_html):
    """Return the first real Mouser product URL from a category-search page."""
    cands = []
    for m in PRODUCT_LINK_RE.finditer(search_html):
        u = de_translate(htmlmod.unescape(m.group(1)))
        if u.startswith("/"):
            u = "https://www.mouser.com" + u
        if "mouser.com" in u and u not in cands:
            cands.append(u)
    return cands[0] if cands else None


# ---------- worker ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default=_default_input())
    ap.add_argument("--rpm", type=float, default=6.0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--mode", choices=["search", "all"], default="all")
    ap.add_argument("--heartbeat", type=int, default=60,
                    help="print a status line every N seconds (0 = off)")
    args = ap.parse_args()

    queue = read_mpn_queue(args.file)
    done = load_done()
    tagp = args.mode + ":"
    todo = [m for m in queue if tagp + m.upper() not in done]
    log(f"mode={args.mode} queue={len(queue)} done_total={len(done)} "
        f"todo={len(todo)} rpm={args.rpm} workers={args.workers}")

    import threading
    import concurrent.futures as cf
    lock = threading.Lock()
    stats = {"ok": 0, "docs": 0, "pcn": 0, "fail": 0, "429": 0}
    session = requests.Session()
    session.headers.update(HDRS)
    try:
        from requests.adapters import HTTPAdapter
        ad = HTTPAdapter(pool_connections=128, pool_maxsize=128)
        session.mount("https://", ad)
        session.mount("http://", ad)
    except Exception:
        pass
    log("startup probe: testing Google translate bridge ...")
    probe_healthy = False
    try:
        pr = session.get(search_url("GRM1555C1E2R2CA01D"), timeout=30)
        log(f"probe: HTTP {pr.status_code} len={len(pr.text)} "
            f"challenge={is_challenge(pr.text)} real={looks_real(pr.text)} "
            f"final_url={pr.url[:90]}")
        probe_healthy = (pr.status_code == 200 and looks_real(pr.text)
                         and not is_challenge(pr.text))
        if probe_healthy:
            log("probe: OK - bridge is working")
        else:
            log("probe: BRIDGE NOT HEALTHY (workers will back off and retry). "
                "Run 'diag_probe.py' for details. If it says google.com/sorry, "
                "wait 1-4 h; if DNS error, set DNS to 8.8.8.8.")
    except Exception as exc:
        probe_healthy = False
        log(f"probe: FAILED {type(exc).__name__}: {str(exc)[:150]}")
        log("probe: check internet / DNS (translate.goog must resolve) / VPN.")
    base_delay = 60.0 / max(0.5, args.rpm)
    lane_state = {"product": 1}   # sticky lane memory
    t0 = time.time()

    def fetch(session, url, timeout=45):
        return session.get(url, timeout=timeout)

    def product_page(session, purl, mpn):
        """3-lane fallback; returns (html, lane) or (None, None)."""
        lanes = [1, 2, 3]
        lanes.sort(key=lambda L: 0 if L == lane_state["product"] else 1)
        for L in lanes:
            try:
                u = {1: lane1, 2: lane2, 3: lane3}[L](purl)
                r = session.get(u, timeout=50, allow_redirects=True)
            except Exception as exc:
                log(f"LANE{L} ERR {mpn}: {type(exc).__name__}")
                continue
            if r.status_code == 200 and not is_challenge(r.text) \
                    and looks_real(r.text):
                lane_state["product"] = L
                return r.text, L
            if r.status_code == 429:
                with lock:
                    stats["429"] += 1
                return None, "429"
        return None, None

    # ---- global block gate: when Google blocks us, ALL workers pause and a
    # single prober re-tests with exponential cooldown (no hammering) ----
    gate = {"blocked": False}
    glock = threading.Lock()
    cool0 = float(os.environ.get("MM_COOLDOWN", "300"))

    def wait_gate():
        while gate["blocked"]:
            time.sleep(3)

    def bridge_blocked(reason=""):
        with glock:
            if gate["blocked"]:
                return            # someone else is already probing
            gate["blocked"] = True
        wait = cool0
        log(f"BLOCKED ({reason}): all workers paused; re-probing in "
            f"{wait / 60:.0f} min, then backing off further if needed")
        try:
            while True:
                time.sleep(wait * random.uniform(0.9, 1.1))
                try:
                    ok = probe_ok(session)
                except Exception:
                    ok = False
                if ok:
                    log("bridge healthy again - resuming workers")
                    return
                wait = min(wait * 1.5, 1800.0)
                log(f"still blocked; next probe in {wait / 60:.0f} min")
        finally:
            gate["blocked"] = False

    def worker(mpn):
        my_backoff = 0.0
        attempt = -1
        while attempt < 39:
            attempt += 1
            wait_gate()
            try:
                r = fetch(session, search_url(mpn))
            except Exception as exc:
                log(f"ERR {type(exc).__name__}: {str(exc)[:60]}")
                time.sleep(base_delay)
                continue
            if r.status_code == 429 or (r.status_code == 200
                                        and is_challenge(r.text)):
                with lock:
                    stats["429"] += 1
                attempt -= 1          # a block is not the part's fault
                bridge_blocked(f"HTTP {r.status_code} on {mpn}")
                continue
            if r.status_code != 200:
                log(f"HTTP {r.status_code} {mpn}: len={len(r.text)} "
                    f"final_url={r.url[:90]} (attempt {attempt + 1}/40)")
            if r.status_code != 200 or is_challenge(r.text) \
                    or not looks_real(r.text):
                # 200-but-not-Mouser = translated error / sorry page:
                # back off WITHOUT marking anything done (queue-burn guard)
                if r.status_code == 200:
                    with lock:
                        stats["429"] += 1   # count as throttle event
                    log(f"FAKE200 {mpn}: len={len(r.text)} "
                        f"title={TITLE_RE.search(r.text).group(1)[:60] if TITLE_RE.search(r.text) else '?'}")
                my_backoff = min(240.0, (my_backoff or 35.0) * 1.6)
                time.sleep(my_backoff * random.uniform(0.7, 1.3))
                continue
            my_backoff = 0.0
            meta, docs = extract_docs(r.text)
            pcn = extract_pcn_rows(r.text)
            mfr = meta.get("manufacturer", "")
            if pcn:
                base = {"MouserPartNumber": meta.get("mouser_pn", ""),
                        "Manufacturer": mfr, "MPN": mpn,
                        "DocumentType": "PCN", "Source": "MOUSER_EN_C_SEARCH"}
                for d in pcn:
                    rec = dict(base)
                    rec.update(d)
                    append_pcn(rec)
                with lock:
                    stats["pcn"] += len(pcn)

            if args.mode == "all":
                purl = extract_product_url(r.text)
                if purl:
                    time.sleep(base_delay * random.uniform(0.5, 1.0))
                    phtml, lane = product_page(session, purl, mpn)
                    if phtml:
                        pmeta, pdocs = extract_docs(phtml)
                        mfr = pmeta.get("manufacturer") or mfr
                        rec = {"status": "ok", "url": purl,
                               "part_number": pmeta.get("part_number", mpn),
                               "manufacturer": mfr,
                               "mouser_pn": pmeta.get("mouser_pn", ""),
                               "documents": pdocs, "lane": lane}
                        append_result(rec)
                        with lock:
                            stats["docs"] += sum(len(v) for v in pdocs.values())
                    elif lane == "429":
                        attempt -= 1
                        bridge_blocked(f"product page 429 on {mpn}")
                        continue   # retry whole part later

            mark_done(f"search:{mpn.upper()}")
            if args.mode == "all":
                mark_done(f"all:{mpn.upper()}")
            with lock:
                stats["ok"] += 1
                n = stats["ok"]
                if n % 10 == 0:
                    npc = write_pcn_csv()
                    nfa = write_final_csv()
                    rate = n / max(1.0, (time.time() - t0) / 60)
                    log(f"progress: ok={n} 429s={stats['429']} "
                        f"| {rate:.1f}/min | pcn_rows={npc} | final_rows={nfa}")
            log(f"OK {mpn}: pcn={len(pcn)} lane={lane_state['product']}")
            time.sleep(base_delay * random.uniform(0.8, 1.3))
            return
        with lock:
            stats["fail"] += 1
        log(f"GIVE-UP: {mpn}")

    if not probe_healthy:
        bridge_blocked("startup probe failed")

    def _heartbeat():
        while True:
            time.sleep(args.heartbeat)
            log(f"heartbeat: ok={stats['ok']} 429s={stats['429']} "
                f"fail={stats['fail']} (still running)")
    if args.heartbeat > 0:
        threading.Thread(target=_heartbeat, daemon=True).start()

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = []
        for u in todo:
            if args.limit and stats["ok"] >= args.limit:
                break
            futs.append(pool.submit(worker, u))
            time.sleep(1.2)
        for f in cf.as_completed(futs):
            try:
                f.result()
            except Exception as exc:
                import traceback
                log("WORKER CRASH: " + type(exc).__name__ + ": " + str(exc))
                log(traceback.format_exc())

    log(f"RUN END ok={stats['ok']} fail={stats['fail']} 429s={stats['429']} "
        f"pcn={stats['pcn']} docs={stats['docs']} | "
        f"pcn_csv={write_pcn_csv()} final_csv={write_final_csv()}")


if __name__ == "__main__":
    sys.exit(main())
