#!/usr/bin/env python3
"""
Mouser bulk part-data harvester using the OFFICIAL Mouser Search API.

Why this exists:
  The previous approach drove a headless browser (Camoufox/Chrome/Edge) through
  rotating proxies to scrape mouser.com product pages directly. Mouser's edge
  detected that as bot traffic and returned HTTP 403 "access denied", with a
  48-hour ban. Continuing to rotate IPs against a site that has already denied
  you access doesn't fix that -- it just risks a longer or permanent ban.

  Mouser publishes a free, rate-limited Search API specifically for bulk
  part lookups like this. This script uses that instead: no browser, no
  proxies, no scraping, no ban risk. It's also much faster and returns
  clean structured JSON instead of HTML you'd have to parse.

Setup:
  1. Register for a free API key: https://www.mouser.com/api-search/
     (Search API -> Get API Key)
  2. Put the key in a file named mouser_api_key.txt next to this script
     (just the raw key, nothing else).
  3. Put your input file (xlsx or csv) next to this script. It needs a
     column with part numbers OR product URLs (the script will extract
     the part number from a Mouser URL automatically).
  4. Run:  python mouser_api_harvest.py --input U.xlsx --column URLS

Output:
  A new xlsx file with one row per part: part number, manufacturer,
  description, datasheet URL, price breaks, stock, lifecycle status, etc.
  Progress is saved incrementally, so you can Ctrl+C and resume later
  (already-fetched part numbers are skipped on the next run).

Rate limits:
  Mouser's Search API allows a generous number of calls per day for
  registered keys (check your account dashboard for your exact limit --
  it's typically in the thousands/day, far more than the 1200/day the
  browser-scraping approach was throttled to). This script paces itself
  conservatively and respects 429 (rate limited) responses with backoff.
"""

import argparse
import json
import re
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

try:
    import openpyxl
except ImportError:
    sys.exit("Missing dependency. Run: pip install openpyxl --break-system-packages")

API_URL = "https://api.mouser.com/api/v1/search/partnumber"
API_KEY_FILE = "mouser_api_key.txt"
RESULTS_FILE = "mouser_api_results.jsonl"   # incremental raw results (resume support)
OUTPUT_XLSX = "mouser_api_output.xlsx"

# Conservative pacing: stay well under typical API daily/per-minute caps.
REQUEST_DELAY_SECONDS = 1.0
MAX_RETRIES = 4


def load_api_key() -> str:
    key_path = Path(API_KEY_FILE)
    if not key_path.exists():
        sys.exit(
            f"'{API_KEY_FILE}' not found.\n"
            f"Register for a free key at https://www.mouser.com/api-search/ "
            f"and save it into {API_KEY_FILE} (just the key, no quotes)."
        )
    key = key_path.read_text(encoding="utf-8").strip()
    if not key:
        sys.exit(f"'{API_KEY_FILE}' is empty. Put your Mouser API key in it.")
    return key


def extract_part_number(value: str) -> str:
    """Accepts either a raw part number or a Mouser product URL and returns
    the part number. Mouser URLs look like:
      https://www.mouser.com/ProductDetail/<Mfr>/<PartNumber>?qs=...
      https://www.mouser.com/en/ProductDetail/<Mfr>/<PartNumber>?qs=...
    """
    value = value.strip()
    if not value:
        return ""
    if value.lower().startswith("http"):
        m = re.search(r"/ProductDetail/[^/]+/([^/?]+)", value, re.IGNORECASE)
        if m:
            from urllib.parse import unquote
            return unquote(m.group(1))
        # Fallback: last path segment before query string
        path = value.split("?")[0].rstrip("/")
        return unquote_last_segment(path)
    return value


def unquote_last_segment(path: str) -> str:
    from urllib.parse import unquote
    return unquote(path.split("/")[-1])


def read_input_values(input_path: Path, column: str) -> list[str]:
    wb = openpyxl.load_workbook(input_path, read_only=True, data_only=True)
    ws = wb.active
    header = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    if column not in header:
        sys.exit(f"Column '{column}' not found. Available columns: {header}")
    col_idx = header.index(column)
    values = []
    for row in ws.iter_rows(min_row=2):
        cell = row[col_idx].value
        if cell:
            values.append(str(cell))
    wb.close()
    return values


def load_done_part_numbers() -> set[str]:
    done = set()
    p = Path(RESULTS_FILE)
    if p.exists():
        with p.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    pn = rec.get("_query_part_number")
                    if pn:
                        done.add(pn)
                except json.JSONDecodeError:
                    continue
    return done


def call_mouser_api(part_number: str, api_key: str) -> dict:
    payload = {
        "SearchByPartRequest": {
            "mouserPartNumber": part_number,
            "partSearchOptions": "None",
        }
    }
    body = json.dumps(payload).encode("utf-8")
    url = f"{API_URL}?apiKey={api_key}"
    req = urllib.request.Request(
        url, data=body, headers={"Content-Type": "application/json"}, method="POST"
    )

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return {"ok": True, "data": data}
        except urllib.error.HTTPError as e:
            if e.code == 429:
                wait = 5 * attempt
                print(f"    rate limited (429), waiting {wait}s...")
                time.sleep(wait)
                continue
            return {"ok": False, "error": f"HTTP {e.code}: {e.reason}"}
        except urllib.error.URLError as e:
            wait = 3 * attempt
            print(f"    network error ({e.reason}), retrying in {wait}s...")
            time.sleep(wait)
    return {"ok": False, "error": "max retries exceeded"}


def flatten_record(part_number: str, api_result: dict) -> dict:
    if not api_result.get("ok"):
        return {
            "PartNumber": part_number,
            "Status": "ERROR",
            "Error": api_result.get("error", "unknown"),
        }
    data = api_result["data"]
    errors = data.get("Errors") or []
    if errors:
        return {
            "PartNumber": part_number,
            "Status": "NOT_FOUND",
            "Error": "; ".join(e.get("Message", "") for e in errors),
        }
    parts = data.get("SearchResults", {}).get("Parts", [])
    if not parts:
        return {"PartNumber": part_number, "Status": "NOT_FOUND", "Error": "No parts returned"}

    p = parts[0]
    price_breaks = p.get("PriceBreaks", [])
    price_str = "; ".join(
        f"{pb.get('Quantity')}@{pb.get('Price')}" for pb in price_breaks
    )
    return {
        "PartNumber": p.get("MouserPartNumber", part_number),
        "Status": "OK",
        "Manufacturer": p.get("Manufacturer", ""),
        "ManufacturerPartNumber": p.get("ManufacturerPartNumber", ""),
        "Description": p.get("Description", ""),
        "Category": p.get("Category", ""),
        "Availability": p.get("Availability", ""),
        "InStock": p.get("AvailabilityInStock", ""),
        "LeadTime": p.get("LeadTime", ""),
        "LifecycleStatus": p.get("LifecycleStatus", ""),
        "DatasheetUrl": p.get("DataSheetUrl", ""),
        "ProductDetailUrl": p.get("ProductDetailUrl", ""),
        "PriceBreaks": price_str,
        "Min": p.get("Min", ""),
        "Mult": p.get("Mult", ""),
        "RoHS": p.get("ROHSStatus", ""),
    }


def main():
    ap = argparse.ArgumentParser(description="Bulk Mouser part lookup via official Search API.")
    ap.add_argument("--input", required=True, help="Input xlsx file (e.g. U.xlsx)")
    ap.add_argument("--column", required=True, help="Column name containing part numbers or URLs")
    args = ap.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        sys.exit(f"Input file not found: {input_path}")

    api_key = load_api_key()
    raw_values = read_input_values(input_path, args.column)
    part_numbers = []
    seen = set()
    for v in raw_values:
        pn = extract_part_number(v)
        if pn and pn not in seen:
            seen.add(pn)
            part_numbers.append(pn)

    done = load_done_part_numbers()
    todo = [pn for pn in part_numbers if pn not in done]

    print(f"Loaded {len(part_numbers)} unique part number(s) from '{args.column}'.")
    print(f"{len(done)} already done (resume) | {len(todo)} to fetch.")
    print(f"Pacing: ~{REQUEST_DELAY_SECONDS}s/request -> est. "
          f"{len(todo) * REQUEST_DELAY_SECONDS / 60:.1f} minutes.\n")

    results_f = open(RESULTS_FILE, "a", encoding="utf-8")
    try:
        for i, pn in enumerate(todo, 1):
            print(f"[{i}/{len(todo)}] {pn}")
            result = call_mouser_api(pn, api_key)
            record = flatten_record(pn, result)
            record["_query_part_number"] = pn
            results_f.write(json.dumps(record) + "\n")
            results_f.flush()
            time.sleep(REQUEST_DELAY_SECONDS)
    except KeyboardInterrupt:
        print("\nInterrupted -- progress saved. Re-run the same command to resume.")
    finally:
        results_f.close()

    write_output_xlsx()
    print(f"\nDone. Output written to {OUTPUT_XLSX}")


def write_output_xlsx():
    records = []
    p = Path(RESULTS_FILE)
    if not p.exists():
        return
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                rec.pop("_query_part_number", None)
                records.append(rec)
            except json.JSONDecodeError:
                continue

    if not records:
        return

    columns = []
    for rec in records:
        for k in rec.keys():
            if k not in columns:
                columns.append(k)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "MouserData"
    ws.append(columns)
    for rec in records:
        ws.append([rec.get(c, "") for c in columns])
    wb.save(OUTPUT_XLSX)


if __name__ == "__main__":
    main()
