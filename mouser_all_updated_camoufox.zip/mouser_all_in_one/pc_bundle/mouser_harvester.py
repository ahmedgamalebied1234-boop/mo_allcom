#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mouser Full-Page Link Harvester (Camoufox) - local version.

Reads Mouser product URLs from a spreadsheet that sits in the SAME FOLDER as this
script, and writes results to a "mouser_harvest" folder next to it.

Input file (first match wins): urls.xlsx / urls.xls / urls.csv / U.xlsx / mo.xlsx /
any other .xlsx or .csv in this folder. Column named url/urls/part_url/mouser_url/link
(else the first column). Optional columns: part / mpn, manufacturer / brand.

Optional Mouser API key (free) for a fallback if the page is blocked: put it in
a file "mouser_api_key.txt" in this folder, or set env var MOUSER_API_KEY.
"""
import os, sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)


# [2/10] Configuration — edit these for other parts ------------------------------
import os
from datetime import datetime, timezone

# Canonical signed product URL (?qs= token). For other parts, open the product
# page on mouser.com and copy the URL from the address bar.
PART_URL = ("https://www.mouser.com/ProductDetail/STMicroelectronics/"
            "STM32F103C8T6?qs=bhCVus9SdFtq6kqxsU5%2FDA%3D%3D")
PART_HINT = "STM32F103C8T6"            # filenames / sitemap search / fallback queries
MANUFACTURER_HINT = "STMicroelectronics"

RETRY_DELAYS_S = [0, 20, 45]           # backoff chain before declaring access failure
RETRY_JITTER_S = (0.0, 5.0)
NAV_TIMEOUT_MS = 90_000                # per-navigation timeout
POLL_WINDOW_S = 60                     # patient poll: wait out late challenge release
VERIFY_TIMEOUT_S = (10, 25)            # (connect, read) timeouts for HEAD/range probes
RANGE_BYTES = 4096                     # ranged-GET probe size (never full downloads)
BROWSER_VERIFY_CAP = 40                # max ambiguous URLs re-checked via navigation

DOC_PANEL_XPATH = "/html/body/main/div/div/div[2]/div/div[1]/div[2]"   # body of the "Documents (n)" panel
# Panels whose links (with section names) are extracted. Collapsed ones are expanded first.
# (Only "Documents" is needed for the datasheet/models/spec/technical-resources table.)
DOC_PANEL_TITLES = ["Documents", "Environmental Documents", "Product & Trade Compliance"]

SKIP_VERIFICATION = True               # True = collect & report ALL found document links as-is,
                                        # skip the HEAD/ranged-GET + browser re-check pass entirely
                                        # (faster, no "unreachable/unverified" filtering anywhere downstream)
MOUSER_ONLY = True                     # scope policy: keep Mouser-hosted documents only
IN_COLAB = False
OUT_DIR = os.path.join(BASE_DIR, "mouser_harvest")
LOCAL_URL_FILE = None   # local run: path to your .xlsx/.csv (default: auto-detect urls.xlsx / U.xlsx / mo.xlsx / urls.csv next to the notebook)
INTER_PART_DELAY_S = 5                 # polite pause between parts in batch mode

# Official Mouser Search API key (free: mouser.com > My Mouser > APIs). Returns
# datasheet URL, lifecycle, RoHS etc. WITHOUT touching the bot-protected web page,
# so it works from Colab/cloud IPs. Put it in Colab Secrets as MOUSER_API_KEY
# (key icon in the left sidebar) or paste it below.
def _get_secret(name):
    v = os.environ.get(name)
    if v:
        return v
    try:
        from google.colab import userdata
        return userdata.get(name)
    except Exception:
        return None

def _read_key_file():
    p = os.path.join(BASE_DIR, "mouser_api_key.txt")
    try:
        with open(p, encoding="utf-8") as fh:
            return fh.read().strip()
    except Exception:
        return ""

MOUSER_API_KEY = (os.environ.get("MOUSER_API_KEY") or _read_key_file() or "").strip()

RUNSTAMP = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print("Config ready.")
print("  target :", PART_URL)
print("  part   :", PART_HINT)
print("  scope  :", "Mouser-hosted resources only" if MOUSER_ONLY else "all hosts")
print("  verify :", "SKIPPED - all found links reported as-is" if SKIP_VERIFICATION else "HEAD/range + browser re-check enabled")
print("  mouser API key:", "set" if MOUSER_API_KEY else "NOT set (put it in mouser_api_key.txt for a fallback)")
print("  environment:", "Google Colab (datacenter IP - Mouser usually blocks it)" if IN_COLAB else "LOCAL (your own IP)")
print("  output dir :", OUT_DIR)


# [input helpers] Upload an Excel/CSV list of Mouser part URLs to crawl (optional) -------
# Upload a .xlsx / .xls / .csv file with a column of Mouser part URLs.
# Optional extra columns (matched case-insensitively, any of these names):
#   URL column            : "url", "urls", "part_url", "mouser_url", "link"
#   part-hint column      : "part_hint", "part", "mpn", "part_number"
#   manufacturer column   : "manufacturer_hint", "manufacturer", "mfr", "brand"
# If none of the URL-like column names match, the first column is used.
# If you skip/cancel the upload dialog, the notebook falls back to the single
# PART_URL / PART_HINT / MANUFACTURER_HINT set in the configuration cell above.
import re
import pandas as pd


def _pick_col(df, candidates):
    cols = {str(c).lower().strip(): c for c in df.columns}
    for cand in candidates:
        if cand in cols:
            return cols[cand]
    return None


def _cell(row, col):
    if not col:
        return None
    val = row.get(col)
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    val = str(val).strip()
    return val or None


def _fix_double_encoded_qs(u):
    """Collapse doubly percent-encoded qs tokens (%252B -> %2B).

    Some spreadsheets export Mouser links with the '+' inside the signed token
    encoded twice. Mouser never redirects away, so the wrong token silently
    reaches the edge; the corrected single-encoded form renders correctly.
    """
    m = re.search(r"((?:^|&)qs=)([^&]+)", u)
    if m and "%25" in m.group(2):
        return u[:m.start()] + m.group(1) + re.sub(r"%25([0-9A-Fa-f]{2})", r"%\1", m.group(2)) + u[m.end():]
    return u


def _slug_hints(u):
    """Derive (part_hint, manufacturer_hint) from a ProductDetail URL slug."""
    m = re.search(r"/ProductDetail/([^/]+)/([^/?#]+)", u or "")
    if not m:
        return None, None
    from urllib.parse import unquote
    return unquote(m.group(2)), unquote(m.group(1)).replace("-", " ")



# [3/10] Core helpers — URL normalization, dedupe, classification, part ID -------
import html as html_mod
import re
from collections import Counter, OrderedDict
from urllib.parse import parse_qsl, urldefrag, urljoin, urlencode, urlparse, urlunsplit

# --- regex sweep patterns (second-chance harvest outside plain anchors) --------
HREF_LIKE = re.compile(
    r'(?:href|src|action|poster|data-url|data-href|data-link|data-src|data-file'
    r'|data-document|data-download)\s*=\s*["\']([^"\']{4,2000})["\']', re.I)
JSON_URL = re.compile(r'"[^"]*(?:url|Url|URL)[^"]*"\s*:\s*"([^"\\]{4,2000})"')
LITERAL = re.compile(r'https?://[^\s"\'<>\\)\}\]]+', re.I)

LIKELY_DOC_PATH_PATTERNS = [
    ".pdf", "/pcn/", "/pcn", "/pdn/", "/eol/", "/documents/", "/document/",
    "/datasheet/", "/download/", "/downloads/", "/faq/", "/environmental/",
    "/compliance/", "/technical/", "/manufacturer/",
]

CATEGORY_RULES = OrderedDict([
    ("datasheet", [r"datasheet", r"data[-\s]sheet"]),
    ("pcn", [r"\bpcn\b", r"product[-\s]change[-\s]notifications?",
             r"product[-\s]change[-\s]notices?"]),
    ("pdn_eol", [r"\bpdn\b", r"\beol\b", r"end[-\s]of[-\s]life", r"discontinuation",
                 r"last[-\s]time[-\s]buy"]),
    ("faq", [r"\bfaqs?\b", r"frequently[-\s]asked"]),
    ("environmental_compliance", [
        r"rohs", r"\breach\b", r"conflict[-\s]minerals?", r"material[-\s]declaration",
        r"environmental", r"\bsvhc\b", r"proposition[-\s]65", r"\bmsds\b", r"\bsds\b",
        r"compliance", r"export[-\s]class"]),
    ("reliability_qualification", [r"reliabilit", r"qualific", r"\bmtbf\b", r"quality"]),
    ("application_technical", [
        r"application[-\s]notes?", r"\bapp[-\s]notes?\b",
        r"technical[-\s](?:document|brief|paper|note)", r"white[-\s]paper",
        r"user[-\s](?:manual|guide)", r"reference[-\s]manual",
        r"programming[-\s]manual", r"getting[-\s]started"]),
    ("safety_regulatory", [r"safety", r"regulatory", r"certificat"]),
])

SECTION_KEYWORDS = [
    "Datasheet", "PCN", "Product Change Notification", "PDN", "EOL", "End of Life",
    "FAQ", "Environmental", "RoHS", "REACH", "Conflict Minerals", "Material Declaration",
    "Compliance", "Application Note", "Reliability", "Qualification",
    "Manufacturer Part Details", "Manufacturer Details", "Manufacturer Resources",
    "Manufacturer Website", "Technical Resources", "Additional Documents",
    "Related Documents", "Resources", "Support",
]

# Tracking params dropped during normalization (signed tokens like ?qs= are kept)
TRACKING_PARAMS = {"srsltid", "spm", "gclid", "fbclid", "mc_cid", "mc_eid", "ref"}


def _strip_tracking(u):
    """Remove tracking params (utm_*, srsltid, ...) if present; else return u."""
    try:
        parts = urlparse(u)
        if not parts.query:
            return u
        pairs = parse_qsl(parts.query, keep_blank_values=True)
        kept = [(k, v) for k, v in pairs
                if k.lower() not in TRACKING_PARAMS
                and not k.lower().startswith("utm_")]
        if len(kept) == len(pairs):
            return u
        return urlunsplit((parts.scheme, parts.netloc, parts.path,
                           urlencode(kept), parts.fragment))
    except Exception:
        return u


def normalize_url(raw, base_url=None):
    """Normalize any discovered URL candidate to an absolute http(s) URL.

    Handles JSON-escaped forms (backslash-slash, u002F), HTML entities,
    protocol-relative URLs, relative paths, and trailing punctuation.
    """
    if raw is None:
        return None
    u = str(raw).strip()
    if not u or len(u) > 2000:
        return None
    u = u.replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/")
    u = u.replace("\\u0026", "&").replace("\\", "")
    u = html_mod.unescape(u)
    u = re.split(r'["<>\s]', u, maxsplit=1)[0]   # drop regex-sweep debris after a stray quote
    if u.startswith("//"):
        u = "https:" + u
    low = u.lower()
    if low.startswith(("mailto:", "tel:", "javascript:", "about:", "data:", "#")):
        return None
    if not low.startswith(("http://", "https://")):
        if not base_url:
            return None
        # reject obvious junk, allow query-bearing relative paths
        if re.search(r'[\s"\'<>\\^`{}|\[\]]', u):
            return None
        try:
            u = urljoin(base_url, u)
        except Exception:
            return None
    try:
        parts = urlparse(u)
    except Exception:
        return None
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return None
    u = _strip_tracking(u)
    u = u.rstrip('.,;:!\'"')
    while u.endswith(")") and u.count("(") < u.count(")"):
        u = u[:-1]
    return u


def regex_sweep(rendered_html, base_url):
    """Sweep rendered HTML for URL candidates outside plain anchors."""
    hits = []
    if not rendered_html:
        return hits
    for m in HREF_LIKE.finditer(rendered_html):
        hits.append((m.group(1), "html_attr"))
    for m in JSON_URL.finditer(rendered_html):
        hits.append((m.group(1), "json_key"))
    flat = (rendered_html.replace("\\/", "/").replace("\\u002F", "/")
            .replace("\\u002f", "/").replace('\\"', '"'))
    for m in LITERAL.finditer(flat):
        hits.append((m.group(0), "literal"))
    return hits


def merge_links(dom_links, regex_hits, base_url):
    """Normalize + deduplicate every candidate into one unique-URL inventory."""
    merged = {}

    def put(raw, source, anchor="", hint=""):
        nu = normalize_url(raw, base_url)
        if not nu:
            return
        # scheme-insensitive identity: http/https variants collapse to one record
        p0 = urlparse(urldefrag(nu)[0])
        identity = urlunsplit(("https", p0.netloc, p0.path, p0.query, ""))
        rec = merged.get(identity)
        if rec is None:
            rec = {"url": nu, "identity": identity, "anchors": [], "hints": [],
                   "sources": []}
            merged[identity] = rec
        else:
            cur = urlparse(rec["url"])
            new = urlparse(nu)
            if new.scheme == "https" and cur.scheme != "https":
                rec["url"] = nu
        if anchor and anchor not in rec["anchors"] and len(rec["anchors"]) < 5:
            rec["anchors"].append(anchor)
        if hint and hint not in rec["hints"] and len(rec["hints"]) < 3:
            rec["hints"].append(hint)
        if source and source not in rec["sources"]:
            rec["sources"].append(source)

    for item in dom_links or []:
        put(item.get("url"), item.get("source") or "dom",
            item.get("anchor") or "", item.get("hint") or "")
    for raw, source in regex_hits or []:
        put(raw, source)
    return list(merged.values())


def host_of(u):
    try:
        return (urlparse(u).netloc or "").lower()
    except Exception:
        return ""


# Mouser-owned country mirrors: mouser.de, mouser.co.uk, mouser.com.tr, ...
MOUSER_MIRROR_HOST_RE = re.compile(r"^(?:www\.)?mouser\.[a-z]{2,3}(?:\.[a-z]{2,3})?$")


def is_mouser(u):
    """Scope-policy test: hosted on a Mouser-owned domain.

    True for the mouser.com family (mouser.com, eu.mouser.com, ar.mouser.com,
    sub.info.mouser.com, ...) and for Mouser country mirrors (mouser.de,
    www.mouser.at, mouser.co.uk, ...). False for lookalikes (evil-mouser.com)
    and for everything non-Mouser (st.com, snapeda.com, ...).
    """
    h = host_of(u)
    if h == "mouser.com" or h.endswith(".mouser.com"):
        return True
    return bool(MOUSER_MIRROR_HOST_RE.match(h))


def same_part_product_url(u, part):
    """True if u is a product-detail page for the same part on any Mouser
    domain (canonical, locale variant, or country mirror) — i.e. a duplicate
    of the canonical page rather than a distinct document.

    The part must match a full path segment: STM32F103C8T6TR (tape-and-reel,
    a distinct product) is NOT matched when part is STM32F103C8T6.
    """
    seg = re.escape(str(part or "").lower())
    try:
        p = urlparse(u or "")
    except Exception:
        return False
    path = (p.path or "").lower()
    return bool(re.search(rf"/productdetail/[^/]+/{seg}(?:/|$)", path))


def classify(record, mfr_name=None):
    """Return (category, likely_document, is_manufacturer) for a link record."""
    p = urlparse(record["url"])
    path = (p.path or "").lower()
    host = (p.netloc or "").lower()
    anchor_str = " ".join(record.get("anchors") or []).lower()
    hint_str = " ".join(record.get("hints") or []).lower()
    hay = " | ".join(x for x in (anchor_str, hint_str, path) if x)
    cat = None
    for category, pats in CATEGORY_RULES.items():
        for pat in pats:
            if re.search(pat, hay):
                cat = category
                break
        if cat:
            break
    is_mfr = False
    if mfr_name:
        slug = mfr_name.lower()
        if slug in host or slug in hay:
            is_mfr = True
    if cat is None and is_mfr:
        cat = "manufacturer_resource"
    likely = any(pat in path for pat in LIKELY_DOC_PATH_PATTERNS) or path.endswith(".pdf")
    if cat is None and likely:
        cat = "other_document"
    return cat, likely, is_mfr


def identify_part(page_text, url):
    """Pull Manufacturer / MPN from page text, fall back to URL slug."""
    ident = {"manufacturer": None, "mpn": None, "description": None, "method": None}
    if page_text:
        m = re.search(r"Manufacturer\s*(?:Part\s*Details|Details)?\s*[:\r\n]+\s*"
                      r"([A-Za-z][A-Za-z0-9 .&/\-()']{1,60})", page_text)
        if m:
            ident["manufacturer"] = m.group(1).strip().rstrip(".")
        m = re.search(r"(?:Manufacturer\s*Product\s*Number|Manufacturer\s*Part\s*"
                      r"(?:Number|No\.?)|Mfr\.?\s*(?:Part\s*)?(?:Number|#))\s*[:#]?\s*"
                      r"([A-Z0-9][A-Z0-9._/\-]{2,40})", page_text)
        if m:
            ident["mpn"] = m.group(1).strip()
        m = re.search(r"(?:Product|Part)\s*(?:Description|Detail)\s*[:\r\n]+\s*"
                      r"([^\r\n]{5,120})", page_text)
        if m:
            ident["description"] = m.group(1).strip()
        if ident["manufacturer"] or ident["mpn"]:
            ident["method"] = "page_text"
    pm = re.search(r"/ProductDetail/([^/]+)/([^/?#]+)", url or "")
    if pm:
        if not ident["manufacturer"]:
            ident["manufacturer"] = pm.group(1)
            ident["method"] = "url_slug"
        if not ident["mpn"]:
            ident["mpn"] = pm.group(2)
            ident["method"] = "url_slug"
    return ident


def section_presence(page_text):
    """Which required sections/topics appear in the page text."""
    found = {}
    low = (page_text or "").lower()
    for kw in SECTION_KEYWORDS:
        found[kw] = kw.lower() in low
    return found


print("Core helpers ready "
      f"({len(CATEGORY_RULES)} document categories, mouser-only test active).")


# [4/10] In-page extraction JS (runs inside the rendered page) --------------------
# STATE_JS  : compact page-state probe (text length + challenge fingerprints)
# EXTRACT_JS: full-text + complete link inventory in one pass
# SCROLL_JS : progressive scroll to trigger lazy-loaded sections
STATE_JS = r"""
() => ({
    len: document.body ? document.body.innerText.length : -1,
    product: !!(document.body && /Mouser No\s*:|Mfr\. No\s*:/i.test(document.body.innerText)),
    hasAkam: !!(document.querySelector('script[src*="/akam/"]') ||
                (document.body && document.body.innerHTML.includes('bazadebezolkohpepadr'))),
    hasDD: !!(document.querySelector('script[src*="captcha-delivery.com"]') ||
              (document.body && document.body.innerHTML.includes('dd={')))
})
"""


def _page_ready(s):
    """Real product page = has 'Mouser No:' / 'Mfr. No:' (a full page is only ~2.4k chars,
    so a text-length threshold alone never fires). Otherwise fall back to length + no challenge."""
    return bool(s.get("product")) or (s.get("len", 0) > 3000 and not s.get("hasAkam") and not s.get("hasDD"))


EXTRACT_JS = r"""
() => {
  const out = { text: '', links: [], canonical: '' };
  const seen = new Set();
  const baseURI = document.baseURI || location.href;
  const abs = (u) => { try { return new URL(u, baseURI).href; } catch (e) { return null; } };
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  const hintFor = (el) => {
    let node = el;
    for (let i = 0; i < 5 && node; i++) {
      let sib = node.previousElementSibling;
      let depth = 0;
      while (sib && depth < 3) {
        if (/^H[1-4]$/i.test(sib.tagName)) return clean(sib.textContent);
        sib = sib.previousElementSibling; depth++;
      }
      node = node.parentElement;
    }
    return '';
  };
  const add = (raw, anchor, source, hint) => {
    if (!raw) return;
    const a = abs(raw);
    if (!a || !/^https?:/i.test(a)) return;
    const key = a.split('#')[0];
    if (seen.has(key)) return;
    seen.add(key);
    out.links.push({ url: a, anchor: clean(anchor), source: source, hint: hint || '' });
  };
  document.querySelectorAll('a[href]').forEach((el) => {
    const anchor = el.innerText || el.textContent || el.getAttribute('aria-label')
      || el.title || el.getAttribute('name') || '';
    add(el.getAttribute('href'), anchor, 'a[href]', hintFor(el));
  });
  document.querySelectorAll('area[href]').forEach((el) =>
    add(el.getAttribute('href'), el.alt, 'area[href]', hintFor(el)));
  document.querySelectorAll('iframe[src],frame[src],embed[src],object[data],source[src]')
    .forEach((el) =>
      add(el.getAttribute('src') || el.getAttribute('data'), '',
          el.tagName.toLowerCase(), ''));
  const canonicalEl = document.querySelector('link[rel="canonical"]');
  if (canonicalEl) {
    try { out.canonical = new URL(canonicalEl.getAttribute('href'), baseURI).href; }
    catch (e) {}
  }
  const dataUrlRe = /url|href|link|file|document|download|pdf|datasheet|doc/i;
  document.querySelectorAll('*').forEach((el) => {
    const attrs = el.attributes;
    if (!attrs) return;
    for (let i = 0; i < attrs.length; i++) {
      const attr = attrs[i];
      const name = attr.name.toLowerCase();
      if (!name.startsWith('data-') || !dataUrlRe.test(name)) continue;
      const v = (attr.value || '').trim();
      if (v.length > 8 && v.length < 2000 &&
          (/^https?:\/\//i.test(v) || v.startsWith('/'))) {
        add(v, el.innerText || el.getAttribute('aria-label') || '',
            'data:' + name, hintFor(el));
      }
    }
  });
  document.querySelectorAll('[onclick],button,[role=button]').forEach((el) => {
    const oc = (el.getAttribute('onclick') || '') + ' ' +
               (el.getAttribute('data-onclick') || '');
    const m = oc.match(/https?:\/\/[^"'\s)<>]+|\/[A-Za-z0-9_\-\/.%]+\.(?:pdf|aspx|ashx|html?)/g);
    if (m) m.forEach((u) => add(u, el.innerText || '', 'onclick', hintFor(el)));
  });
  out.text = document.body ? document.body.innerText : '';
  return out;
}
"""

SCROLL_JS = r"""
async () => {
  await new Promise((resolve) => {
    let y = 0;
    const step = () => {
      y += 900;
      window.scrollTo(0, y);
      const max = (document.body ? document.body.scrollHeight : y) + 900;
      if (y < max) { setTimeout(step, 250); }
      else { window.scrollTo(0, 0); setTimeout(resolve, 400); }
    };
    step();
  });
}
"""

DOC_PANEL_JS = r"""
(cfg) => {
  const out = { xpath: cfg.xpath, xpath_hit: false, panels: [], rows: [], log: [] };
  const baseURI = document.baseURI || location.href;
  const abs = (u) => { try { return new URL(u, baseURI).href; } catch (e) { return null; } };
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const byXp = (x) => { try { return document.evaluate(x, document, null, 9, null).singleNodeValue; } catch (e) { return null; } };
  const HEAD_TAGS = /^(H[1-6]|DT|LEGEND|STRONG|B|EM|I|TH|CAPTION)$/;
  const SKIP_TEXT = /^(filter document:?|choose a document type|documents?\s*\(\d+\))$/i;
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'OPTION', 'SELECT', 'NOSCRIPT', 'SVG', 'PATH', 'svg', 'path']);
  const ALL_TITLES = Array.from(new Set([...(cfg.titles || []), 'Documents', 'More Information']));

  const headingRe = (t) => new RegExp('^' + esc(t) + '(\\s*\\(\\d+\\))?$', 'i');
  const findHeading = (title) => {
    const re = headingRe(title);
    let best = null;
    document.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,legend,summary,label,p').forEach((el) => {
      if (!re.test(clean(el.textContent))) return;
      if (Array.from(el.children).some((c) => re.test(clean(c.textContent)))) return; // deepest match only
      best = best || el;
    });
    return best;
  };
  const headingsInside = (node) => ALL_TITLES.filter((t) => {
    const re = headingRe(t);
    return Array.from(node.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,legend,summary,label,p'))
      .some((el) => re.test(clean(el.textContent)) && !Array.from(el.children).some((c) => re.test(clean(c.textContent))));
  }).length;

  const walk = (container, panelName) => {
    let section = '';
    const seen = new Set();
    let n = 0;
    container.querySelectorAll('*').forEach((el) => {
      if (SKIP_TAGS.has(el.tagName) || el.closest('select')) return;
      if (el.tagName === 'A') {
        let raw = el.getAttribute('href') || '';
        if (!raw || /^(javascript:|#|mailto:|tel:)/i.test(raw.trim())) {
          raw = el.getAttribute('data-href') || el.getAttribute('data-url') || '';
        }
        const url = raw ? abs(raw) : null;
        if (!url || !/^https?:/i.test(url)) return;
        const name = clean(el.innerText || el.textContent) || clean(el.getAttribute('aria-label')) || clean(el.getAttribute('title'));
        const key = panelName + '|' + section + '|' + url;
        if (seen.has(key)) return;
        seen.add(key);
        out.rows.push({ panel: panelName, section: section, name: name, url: url,
                        opens_new_tab: (el.getAttribute('target') || '') === '_blank' });
        n++;
        return;
      }
      if (el.closest('a') || el.querySelector('a')) return;
      const text = clean(el.textContent);
      if (!text || text.length > 80 || SKIP_TEXT.test(text)) return;
      let italic = false;
      try { italic = getComputedStyle(el).fontStyle === 'italic'; } catch (e) {}
      if (italic || HEAD_TAGS.test(el.tagName)) section = text;
    });
    return n;
  };

  const usable = (node) => node && node !== document.body && node.tagName !== 'MAIN' &&
                           node.tagName !== 'HTML' && node.querySelectorAll('a[href]').length > 0 &&
                           node.querySelectorAll('a[href]').length < 150;

  // 1) Documents panel via the configured XPath (with 2 parent levels of tolerance)
  let docsDone = false;
  const xnode = cfg.xpath ? byXp(cfg.xpath) : null;
  if (xnode) {
    out.xpath_hit = true;
    let cand = xnode;
    for (let i = 0; i < 3 && cand; i++, cand = cand.parentElement) {
      if (usable(cand) && headingsInside(cand) <= 1) {
        const n = walk(cand, 'Documents');
        out.panels.push({ panel: 'Documents', via: 'xpath' + (i ? '+parent' + i : ''), links: n });
        docsDone = true;
        break;
      }
    }
    if (!docsDone) out.log.push('xpath node found but no usable link container');
  } else if (cfg.xpath) {
    out.log.push('xpath not found on this page');
  }

  // 2) heading-based fallback for every requested panel
  (cfg.titles || []).forEach((title) => {
    if (title.toLowerCase() === 'documents' && docsDone) return;
    const h = findHeading(title);
    if (!h) { out.log.push('heading not found: ' + title); return; }
    let node = h.parentElement, hops = 0;
    while (node && hops < 8) {
      if (usable(node) && headingsInside(node) <= 1) {
        const n = walk(node, title);
        out.panels.push({ panel: title, via: 'heading', links: n });
        return;
      }
      node = node.parentElement; hops++;
    }
    out.log.push('no link container found for: ' + title);
  });
  return out;
}
"""

EXPAND_JS = r"""
(titles) => {
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const clicked = [];
  (titles || []).forEach((t) => {
    if (/^documents$/i.test(t)) return;                    // already open by default
    const re = new RegExp('^' + esc(t) + '(\\s*\\(\\d+\\))?$', 'i');
    let best = null;
    document.querySelectorAll('h1,h2,h3,h4,h5,h6,button,a,div,span,summary,legend').forEach((el) => {
      if (!re.test(clean(el.textContent))) return;
      if (Array.from(el.children).some((c) => re.test(clean(c.textContent)))) return;
      best = best || el;
    });
    if (!best) return;
    const trg = best.closest('button,[role="button"],[aria-expanded],[data-toggle],[data-bs-toggle],summary') || best;
    if (trg.getAttribute('aria-expanded') === 'true') return;
    try { trg.click(); clicked.push(t); } catch (e) {}
  });
  return clicked;
}
"""

print("Extraction JS ready (state probe / full extractor / lazy-load scroller).")


# [5/10] Camoufox renderer — recipe validated against Mouser's Akamai + DataDome --
import time

from playwright.sync_api import TimeoutError as PWTimeoutError
from camoufox.sync_api import Camoufox

try:
    from camoufox.addons import DefaultAddons
    EXCLUDE_ADDONS = [DefaultAddons.UBO]   # uBlock Origin filtering breaks the sensor
except Exception:
    EXCLUDE_ADDONS = []

HEADLESS_MODE = os.environ.get("HEADLESS", "1") != "0"  # set HEADLESS=0 to watch the browser                        # validated: plain headless works

WARMUP_URL = "https://www.mouser.com/"

BLOCK_MARKERS = [
    "access denied", "access to this page has been denied", "attention required",
    "captcha", "are you a human", "please verify", "verify you are",
    "unusual traffic", "request unsuccessful", "incapsula", "datadome",
    "perimeterx", "px-captcha", "cloudflare", "just a moment", "cf-chl",
    "request blocked", "security check", "bot detection", "you have been blocked",
]


def _render_body(browser, url, nav_timeout_ms, warmup, result):
    """Everything that happens once the browser is up."""
    page = browser.new_page()
    if warmup and "mouser.com" in (url or "").lower():
        try:
            page.goto(WARMUP_URL, wait_until="domcontentloaded", timeout=60000,
                      referer="https://www.google.com/")
            t0 = time.time()
            while time.time() - t0 < 30:
                time.sleep(2.5)
                s = page.evaluate(STATE_JS)
                if s["len"] > 2000 and not s["hasAkam"] and not s["hasDD"]:
                    break
        except Exception as exc:
            result["errors"].append(f"warmup skipped: {type(exc).__name__}: {str(exc)[:300]}")
    resp = page.goto(url, wait_until="domcontentloaded", timeout=nav_timeout_ms,
                     referer=WARMUP_URL)
    result["http_status"] = getattr(resp, "status", None) if resp else None
    t0 = time.time()
    s = {"len": -1, "hasAkam": False, "hasDD": False}
    while time.time() - t0 < POLL_WINDOW_S:
        time.sleep(2.5)
        try:
            s = page.evaluate(STATE_JS)
        except Exception:
            continue
        if _page_ready(s):
            break
    result["challenge_flags"] = {k: s[k] for k in ("hasAkam", "hasDD") if k in s}
    try:
        page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        result["errors"].append("networkidle not reached (continuing with settled DOM)")
    page.wait_for_timeout(2500)
    try:
        page.evaluate(SCROLL_JS)
    except Exception as exc:
        result["errors"].append(f"scroll failed: {exc}")
    page.wait_for_timeout(2000)
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    try:
        clicked = page.evaluate(EXPAND_JS, DOC_PANEL_TITLES)
        if clicked:
            page.wait_for_timeout(2000)
        result["doc_panels"] = page.evaluate(
            DOC_PANEL_JS, {"xpath": DOC_PANEL_XPATH, "titles": DOC_PANEL_TITLES})
        result["doc_panels"]["expanded"] = clicked
    except Exception as exc:
        result["errors"].append(f"document panel extraction failed: {exc}")
    data = page.evaluate(EXTRACT_JS)
    result["page_text"] = data.get("text") or ""
    result["dom_links"] = data.get("links") or []
    result["canonical"] = data.get("canonical") or None
    result["final_url"] = page.url
    result["title"] = page.title()
    try:
        result["user_agent"] = page.evaluate("navigator.userAgent")
    except Exception:
        pass
    result["rendered_html"] = page.content()


def render_page(url, nav_timeout_ms=None, warmup=True):
    """Load `url` in Camoufox, render fully, return extraction dict.

    Adds `failure_kind` so callers can tell WHY nothing came back:
      launch_error  - the browser itself never started (setup problem, not a block)
      timeout       - navigation timed out, no response
      no_response   - navigation failed at network level (reset/refused/DNS)
      challenge     - page loaded but shows a bot-challenge / block page
      None          - rendered fine
    """
    if nav_timeout_ms is None:
        nav_timeout_ms = NAV_TIMEOUT_MS
    result = {
        "requested_url": url, "final_url": None, "http_status": None,
        "title": None, "user_agent": None, "canonical": None,
        "page_text": None, "dom_links": [], "rendered_html": None,
        "blocked": False, "block_evidence": [], "errors": [],
        "challenge_flags": {}, "failure_kind": None, "doc_panels": None,
    }
    launched = False
    # geoip=True needs an extra lookup + DB download; if the browser fails to
    # START with it, retry once without it instead of silently returning nothing.
    for use_geoip in (True, False):
        try:
            with Camoufox(headless=HEADLESS_MODE, humanize=True, locale=["en-US"],
                          geoip=use_geoip, exclude_addons=EXCLUDE_ADDONS) as browser:
                launched = True
                _render_body(browser, url, nav_timeout_ms, warmup, result)
            break
        except PWTimeoutError as exc:
            result["errors"].append(f"navigation timeout: {str(exc)[:300]}")
            break
        except Exception as exc:
            result["errors"].append(
                f"{'render' if launched else 'launch'} failure "
                f"(geoip={use_geoip}): {type(exc).__name__}: {str(exc)[:400]}")
            if launched:
                break

    errs = " ".join(result["errors"]).lower()
    if not launched:
        result["failure_kind"] = "launch_error"
    elif result["http_status"] is None and not (result["page_text"] or "").strip():
        result["failure_kind"] = "timeout" if "timeout" in errs else "no_response"

    text_now = (result.get("page_text") or "")
    has_product = bool(re.search(r"Mouser No\s*:|Mfr\. No\s*:", text_now))   # real content present
    hay = (text_now[:4000] + " " + (result.get("title") or "")).lower()
    if len(text_now) < 5000 and not has_product:            # avoid false positives on full product pages
        for marker in BLOCK_MARKERS:
            if marker in hay:
                result["blocked"] = True
                result["block_evidence"].append(f"text marker: {marker!r}")
    flags = result.get("challenge_flags") or {}
    if flags.get("hasAkam") and not has_product:
        result["blocked"] = True
        result["block_evidence"].append("Akamai challenge still present after poll window")
    if flags.get("hasDD") and not has_product:
        result["blocked"] = True
        result["block_evidence"].append(
            "DataDome captcha-delivery assets still present after poll window")
    if result["http_status"] in (401, 403, 429, 503):
        result["blocked"] = True
        result["block_evidence"].append(f"http status {result['http_status']}")
    text_len = len(text_now.strip())
    if text_len < 300:
        result["blocked"] = True
        result["block_evidence"].append(f"rendered text too short ({text_len} chars)")
    if result["blocked"] and not result["failure_kind"]:
        result["failure_kind"] = "challenge"
    return result


print("Renderer ready — Camoufox", "(UBO excluded)" if EXCLUDE_ADDONS else "(default addons)",
      "| headless:", HEADLESS_MODE)


# [6/10] Verification — HEAD + 4 KB ranged GET, then browser re-check -------------
# Mouser's edge masks content-type on HEAD probes (uniform text/html), so any
# ambiguous result is re-checked by direct navigation inside the Camoufox
# context (clearance cookies + real TLS fingerprint). Never full downloads.
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

VERIFY_UA = ("Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0")


def verify_url(session, url, ua, referer):
    """HEAD first, then 4 KB ranged GET. Never downloads full documents."""
    headers = {
        "User-Agent": ua or VERIFY_UA,
        "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9",
    }
    if referer:
        headers["Referer"] = referer
    rec = {"url": url, "method": None, "status": None, "ok": False,
           "content_type": None, "length_hint": None, "final_url": None, "error": None}
    for method in ("head", "get_range"):
        try:
            if method == "head":
                r = session.head(url, headers=headers, timeout=VERIFY_TIMEOUT_S,
                                 allow_redirects=True)
            else:
                h2 = dict(headers)
                h2["Range"] = f"bytes=0-{RANGE_BYTES - 1}"
                r = session.get(url, headers=h2, timeout=VERIFY_TIMEOUT_S,
                                allow_redirects=True, stream=True)
                r.close()
            rec["method"] = method
            rec["status"] = r.status_code
            rec["final_url"] = str(r.url)
            rec["content_type"] = r.headers.get("Content-Type")
            rec["length_hint"] = r.headers.get("Content-Range") or r.headers.get("Content-Length")
            if r.status_code < 400:
                rec["ok"] = True
                break
        except Exception as exc:
            rec["error"] = f"{type(exc).__name__}: {exc}"
    return rec


def verify_all(targets, ua, referer, workers=4):
    """Verify a list of URLs concurrently. Returns {url: record}."""
    out = {}
    with requests.Session() as s:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(verify_url, s, u, ua, referer): u for u in targets}
            for f in as_completed(futs):
                rec = f.result()
                out[futs[f]] = rec
    return out


def ambiguous(rec):
    """Needs a real browser re-check? (not OK, or content-type edge-masked)"""
    if not rec or not rec.get("ok"):
        return True
    ct = (rec.get("content_type") or "").lower()
    return ct.startswith("text/html")


def browser_verify(urls, referer, cap=None):
    """Navigate each URL in the Camoufox context and record true status/type.

    This mirrors the validated finding: direct navigation to Mouser-hosted
    PDF/image URLs returns real 200 + application/pdf responses even when
    HEAD probes are content-type masked by the edge.
    """
    if cap is None:
        cap = BROWSER_VERIFY_CAP
    results = {}
    todo = list(dict.fromkeys(urls))[:cap]
    if not todo:
        return results
    kw = dict(headless=HEADLESS_MODE, humanize=True, locale=["en-US"], geoip=True)
    if EXCLUDE_ADDONS:
        kw["exclude_addons"] = EXCLUDE_ADDONS
    with Camoufox(**kw) as browser:
        ctx = browser.new_context()
        page = ctx.new_page()
        for i, u in enumerate(todo, 1):
            rec = {"url": u, "method": "browser-navigation", "status": None,
                   "content_type": None, "ok": False, "error": None}
            try:
                resp = page.goto(u, wait_until="domcontentloaded", timeout=45000,
                                 referer=referer)
                rec["status"] = resp.status if resp else None
                if resp:
                    rec["content_type"] = resp.headers.get("content-type")
                rec["ok"] = bool(rec["status"] and rec["status"] < 400)
            except Exception as exc:
                rec["error"] = f"{type(exc).__name__}: {exc}"[:200]
            results[u] = rec
            print(f"   [{i}/{len(todo)}] HTTP {rec['status']} {rec['content_type']} {u[:90]}")
        ctx.close()
    return results


print("Verification ready (HEAD + 4KB ranged GET -> browser navigation re-check).")


# [7/10] Fallback routes — robots.txt/sitemap.xml + Mouser-only web discovery -----
import re
import time
import urllib.parse as up

import requests


def sitemap_locate(part_number, session, max_sitemaps=6, max_children=12,
                   cap_bytes=30_000_000):
    """Best-effort: robots.txt -> declared sitemaps -> locate canonical part URLs.

    Note: Mouser has been observed serving an HTML block page instead of
    robots.txt. This route is attempted per spec but may be unusable; the
    attempt itself is recorded as evidence either way.
    """
    findings = {"robots_status": None, "sitemaps_declared": [], "checked": [],
                "candidate_urls": [], "notes": []}
    ua = {"User-Agent": VERIFY_UA}
    try:
        r = session.get("https://www.mouser.com/robots.txt", headers=ua, timeout=20)
        findings["robots_status"] = r.status_code
        ct = (r.headers.get("Content-Type") or "").lower()
        if r.status_code == 200 and "html" not in ct:
            findings["sitemaps_declared"] = re.findall(
                r"(?im)^sitemap:\s*(\S+)", r.text)[:10]
        elif r.status_code == 200:
            findings["notes"].append(
                "robots.txt returned an HTML page (block page) - route unusable")
    except Exception as exc:
        findings["notes"].append(f"robots.txt fetch failed: {exc}")
        return findings
    queue = list(findings["sitemaps_declared"])[:max_sitemaps]
    seen = set()
    pat = re.compile(re.escape(part_number or "___"), re.I)
    while queue and len(findings["checked"]) < max_sitemaps + max_children:
        sm = queue.pop(0)
        if sm in seen:
            continue
        seen.add(sm)
        try:
            r = session.get(sm, headers=ua, timeout=30, stream=True)
            data = b""
            for chunk in r.iter_content(65536):
                data += chunk
                if len(data) > cap_bytes:
                    findings["notes"].append(f"{sm}: truncated at {cap_bytes}B")
                    break
            r.close()
            findings["checked"].append({"url": sm, "status": r.status_code,
                                        "bytes": len(data)})
            text = data.decode("utf-8", "ignore")
            if "<sitemapindex" in text.lower():
                children = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", text)
                queue.extend(children[:max_children])
            else:
                for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", text):
                    if pat.search(loc) and "productdetail" in loc.lower():
                        findings["candidate_urls"].append(loc)
                        if len(findings["candidate_urls"]) >= 10:
                            return findings
        except Exception as exc:
            findings["notes"].append(f"{sm}: {exc}")
    return findings


DDG_ENDPOINT = "https://html.duckduckgo.com/html/"


def web_discover_mouser(part, max_results=30):
    """Public web-search discovery, keeping Mouser-hosted URLs only (scope policy).

    Finds canonical signed product URLs, regional mirrors (eu.mouser.com), and
    Mouser CDN document URLs (mouser.com/datasheet/..., /PCN/..., /catalog/...).
    """
    found = []
    queries = [f'"{part}" site:mouser.com', f'"{part}" mouser.com datasheet pdf']
    for q in queries:
        print("   Q:", q)
        try:
            r = requests.get(DDG_ENDPOINT, params={"q": q},
                             headers={"User-Agent": VERIFY_UA,
                                      "Referer": "https://duckduckgo.com/"},
                             timeout=30)
        except Exception as exc:
            print("     search error:", exc)
            continue
        for m in re.finditer(r'uddg=([^&"\']+)', r.text):
            nu = normalize_url(up.unquote(m.group(1)), None)
            if nu and is_mouser(nu):
                found.append(nu)
        for m in LITERAL.finditer(r.text):
            nu = normalize_url(m.group(0), None)
            if nu and is_mouser(nu):
                found.append(nu)
        time.sleep(2)
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out[:max_results]


def _norm_pn(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def mouser_api_lookup(part_number, api_key, timeout=30):
    """Official Mouser Search API lookup (no web-page scraping, no bot wall).

    Returns {"ok", "matched_part", "links", "errors", "raw_count"}.
    `links` are dicts shaped like DOM links so merge_links() can take them.
    """
    out = {"ok": False, "matched_part": None, "links": [], "errors": [], "raw_count": 0}
    if not api_key:
        out["errors"].append("no MOUSER_API_KEY configured")
        return out
    base = "https://api.mouser.com/api/v1/search"
    attempts = [
        (f"{base}/partnumber", {"SearchByPartRequest": {
            "mouserPartNumber": part_number, "partSearchOptions": "Exact"}}),
        (f"{base}/keyword", {"SearchByKeywordRequest": {
            "keyword": part_number, "records": 10, "startingRecord": 0,
            "searchOptions": "None", "searchWithYourSignUpLanguage": "false"}}),
    ]
    want = _norm_pn(part_number)
    for endpoint, body in attempts:
        try:
            r = requests.post(endpoint, params={"apiKey": api_key}, json=body,
                              headers={"Content-Type": "application/json",
                                       "Accept": "application/json"}, timeout=timeout)
            if r.status_code != 200:
                out["errors"].append(f"{endpoint.rsplit('/',1)[-1]}: HTTP {r.status_code}")
                continue
            data = r.json()
        except Exception as exc:
            out["errors"].append(f"{endpoint.rsplit('/',1)[-1]}: {type(exc).__name__}: {exc}")
            continue
        for e in (data.get("Errors") or []):
            out["errors"].append(f"API: {e.get('Message') or e}")
        parts = ((data.get("SearchResults") or {}).get("Parts")) or []
        out["raw_count"] = len(parts)
        exact = [p for p in parts if want and _norm_pn(p.get("ManufacturerPartNumber")) == want]
        if not exact:
            continue
        p = exact[0]
        out["ok"] = True
        out["matched_part"] = {k: p.get(k) for k in (
            "Manufacturer", "ManufacturerPartNumber", "MouserPartNumber", "Description",
            "LifecycleStatus", "ROHSStatus", "Category", "ProductDetailUrl",
            "DataSheetUrl", "ImagePath")}
        if p.get("DataSheetUrl"):
            out["links"].append({"url": p["DataSheetUrl"], "anchor": "Datasheet",
                                 "source": "mouser-api", "hint": "Datasheet (Mouser API)"})
        if p.get("ProductDetailUrl"):
            out["links"].append({"url": p["ProductDetailUrl"], "anchor": "",
                                 "source": "mouser-api", "hint": "Product page (Mouser API)"})
        break
    return out


print("Fallback routes ready (robots/sitemap + Mouser-only web discovery + Mouser API).")


# ==== Internet connectivity watchdog: if the connection drops, WAIT and continue ======
import socket as _socket
import threading as _threading
import time as _time

NET_CHECK_HOSTS = [("1.1.1.1", 443), ("8.8.8.8", 443), ("9.9.9.9", 443), ("www.google.com", 443)]
NET_POLL_S = 5            # first re-check delay while offline
NET_POLL_MAX_S = 30       # re-check delay grows to this
NET_STATUS_EVERY_S = 60   # "still offline" reminder interval
_net_cache = {"t": 0.0, "ok": True}
_net_state = {"since": None, "last_msg": 0.0}
_net_lock = _threading.Lock()


def internet_ok(force=False, cache_s=8):
    """True if we can reach the internet (checks public DNS/web hosts, NOT Mouser)."""
    now = _time.time()
    if not force and now - _net_cache["t"] < cache_s:
        return _net_cache["ok"]
    ok = False
    for host, port in NET_CHECK_HOSTS:
        try:
            with _socket.create_connection((host, port), timeout=3):
                ok = True
                break
        except OSError:
            continue
    _net_cache["t"], _net_cache["ok"] = _time.time(), ok
    return ok


def wait_for_internet(stop_event=None):
    """Block until the internet is back. Returns seconds waited (0.0 if it was online)."""
    if internet_ok(force=True):
        return 0.0
    t0 = _time.time()
    with _net_lock:
        first = _net_state["since"] is None
        if first:
            _net_state["since"], _net_state["last_msg"] = t0, t0
    if first:
        print(f"\n!! INTERNET LOST ({datetime.now().strftime('%H:%M:%S')}) - paused, "
              f"waiting for the connection to return ...", flush=True)
    delay = NET_POLL_S
    while not (stop_event is not None and stop_event.is_set()):
        if internet_ok(force=True):
            break
        _time.sleep(delay)
        delay = min(delay * 1.5, NET_POLL_MAX_S)
        with _net_lock:
            if (_net_state["since"] is not None and
                    _time.time() - _net_state["last_msg"] >= NET_STATUS_EVERY_S):
                _net_state["last_msg"] = _time.time()
                print(f"   ... still offline ({(_time.time() - _net_state['since']) / 60:.1f} min)",
                      flush=True)
    waited = _time.time() - t0
    with _net_lock:
        if _net_state["since"] is not None and internet_ok():
            print(f"** INTERNET BACK after {(_time.time() - _net_state['since']):.0f}s "
                  f"({datetime.now().strftime('%H:%M:%S')}) - resuming.\n", flush=True)
            _net_state["since"] = None
    return waited


# [8/10] Harvest core — retry chain, extraction, classification, Mouser-only
#        filter, verification (requests + browser re-check). Wrapped as a
#        reusable function so it can run once per URL in a batch crawl.
import json
import os
import random
import re
import time
from collections import Counter, OrderedDict
from datetime import datetime, timezone
from urllib.parse import urldefrag, urlparse

import requests


def _log(*a):
    print(*a, flush=True)




_CLOUD_NOTE_SHOWN = {"v": False}


def _warn_cloud_ip_once():
    """One-time honest hint when renders keep getting blocked."""
    if _CLOUD_NOTE_SHOWN["v"]:
        return
    _CLOUD_NOTE_SHOWN["v"] = True
    _log("HINT: renders are being blocked. Mouser's bot protection aggressively "
         "blocks datacenter IPs (Google Colab / GCP / AWS / Azure); runs from a "
         "residential IP (local machine, Jupyter) succeed far more often, and the "
         "official Mouser Search API (set MOUSER_API_KEY) works from anywhere. "
         "This is an access limitation - failures are reported honestly "
         "(no CAPTCHA solving, no bypassing).")


def harvest_one(part_url, part_hint=None, manufacturer_hint=None):
    """Run the full harvest pipeline for a single Mouser part URL.

    Returns the report `doc` (dict). Never raises for blocked/unreachable
    pages — failures are recorded inside the returned document instead.
    """
    # Derive identification from the URL slug FIRST so batch rows never
    # inherit the single-URL demo hints (STM32F103C8T6).
    _ident0 = identify_part(None, part_url)
    part_hint = part_hint or _ident0.get("mpn") or PART_HINT
    manufacturer_hint = manufacturer_hint or _ident0.get("manufacturer") or MANUFACTURER_HINT

    _log("=== Mouser Full Page Link Harvester - Camoufox ===")
    _log("target:", part_url)

    t0 = time.time()

    # [A] Render with retry/backoff chain ----------------------------------
    render = None
    attempt_log = []
    for attempt, delay in enumerate(RETRY_DELAYS_S):
        if delay:
            pause = delay + random.uniform(*RETRY_JITTER_S)
            _log(f"[retry] waiting {pause:.0f}s before attempt {attempt + 1} ...")
            time.sleep(pause)
        _log(f"attempt {attempt + 1}/{len(RETRY_DELAYS_S)}: rendering (Camoufox) ...")
        wait_for_internet()                       # pause here if the connection is down
        render = render_page(part_url)
        if render.get("failure_kind") in ("timeout", "no_response", "launch_error") \
                and not internet_ok(force=True):
            _log("   internet lost during render - waiting for it to return ...")
            wait_for_internet()
            render = render_page(part_url)        # same attempt; an outage is not a block
        attempt_log.append({
            "attempt": attempt + 1,
            "http_status": render["http_status"],
            "final_url": render["final_url"],
            "page_text_chars": len(render.get("page_text") or ""),
            "dom_links": len(render.get("dom_links") or []),
            "blocked": render["blocked"],
            "block_evidence": render["block_evidence"],
            "errors": render["errors"],
            "failure_kind": render.get("failure_kind"),
        })
        _log(f"   status={render['http_status']} text={len(render.get('page_text') or '')} chars "
             f"links={len(render.get('dom_links') or [])} blocked={render['blocked']}")
        for _e in render["errors"][:4]:
            _log("   error:", _e[:300])
        if render.get("failure_kind"):
            _log("   failure kind:", render["failure_kind"])
        if render.get("page_text") and not render["blocked"]:
            break
        if render.get("failure_kind") == "launch_error":
            _log("   browser failed to START - retrying cannot help. Fix setup "
                 "(delete the .venv folder and re-run the .bat to reinstall).")
            break

    # [B] Fallback chain when blocked: sitemap route -> Mouser-only web discovery -
    sitemap = None
    web_discovered = []
    api_result = None
    if render["blocked"] or not render.get("page_text"):
        _log("BLOCKED -> fallback chain (spec: retry -> sitemap -> web discovery)")
        _warn_cloud_ip_once()
        ident0 = identify_part(None, part_url)
        pn = ident0.get("mpn") or part_hint
        with requests.Session() as s:
            sitemap = sitemap_locate(pn, s)
        _log(f"   sitemap: robots={sitemap.get('robots_status')} "
             f"candidates={len(sitemap.get('candidate_urls', []))} "
             f"notes={sitemap.get('notes')}")
        cands = [u for u in sitemap.get("candidate_urls", []) if u != part_url]
        if cands:
            alt = render_page(cands[0])
            if alt.get("page_text") and not alt["blocked"]:
                alt["requested_url"] = part_url
                alt["recovered_via"] = "sitemap canonical URL"
                render = alt
        if render["blocked"] or not render.get("page_text"):
            if MOUSER_API_KEY:
                api_result = mouser_api_lookup(pn or part_hint, MOUSER_API_KEY)
                _log(f"   Mouser API: ok={api_result['ok']} links={len(api_result['links'])} "
                     f"errors={api_result['errors']}")
            else:
                _log("   Mouser API skipped (no MOUSER_API_KEY set)")
            web_discovered = web_discover_mouser(pn or part_hint)
            _log(f"   web discovery (Mouser-hosted only): {len(web_discovered)} URL(s)")
    else:
        _log("page rendered cleanly; fallback chain not needed")

    access_ok = bool(render.get("page_text")) and not render["blocked"]
    access_status = "OK" if access_ok else "ACCESS FAILED - DOCUMENT DISCOVERY INCOMPLETE"
    if not access_ok and api_result and api_result.get("ok"):
        access_status = ("PARTIAL - PAGE BLOCKED; DOCUMENT LINKS FROM OFFICIAL MOUSER API "
                         "(page text / full link inventory unavailable)")
    _log(f"access status: {access_status}")

    # [C] Part identification + full link inventory -------------------------
    base = render.get("final_url") or part_url
    page_text = render.get("page_text") or ""
    ident = identify_part(page_text, base)
    mpn = ident.get("mpn") or part_hint or "part"
    mfr = ident.get("manufacturer") or manufacturer_hint
    _log(f"part identified: mfr={mfr} mpn={mpn} ({ident.get('method')})")

    regex_hits = regex_sweep(render.get("rendered_html"), base)
    web_recs = [{"url": u, "anchor": "", "source": "web-search",
                 "hint": "Mouser-hosted (web discovery)"} for u in web_discovered]
    if api_result and api_result.get("ok"):
        web_recs += api_result["links"]
        mp = api_result["matched_part"] or {}
        if not ident.get("description") and mp.get("Description"):
            ident["description"] = mp["Description"]
        if mp.get("Manufacturer"):
            ident["manufacturer"] = mp["Manufacturer"]
        ident["method"] = "mouser_api"
    records = merge_links((render.get("dom_links") or []) + web_recs, regex_hits, base)
    _log(f"unique links after normalize + dedupe: {len(records)}")

    # [D] Classification --------------------------------------------------------
    page_identity = urldefrag(base)[0].rstrip("/")
    classified = OrderedDict(
        (cat, []) for cat in list(CATEGORY_RULES)
        + ["other_document", "manufacturer_resource", "self_page"])
    uncategorized = []
    for rec in records:
        cat, likely, is_mfr = classify(rec, mfr)
        if rec["identity"].rstrip("/") == page_identity:
            cat = "self_page"
        rec["likely_document"] = likely
        if cat:
            classified[cat].append(rec)
        else:
            uncategorized.append(rec)

    # [E] Scope policy: keep Mouser-hosted documents only ------------------------
    mouser_filter_log = {
        "enabled": MOUSER_ONLY,
        "dropped_out_of_scope": [],
        "dropped_mirror_duplicates": [],
    }
    if MOUSER_ONLY:
        for cat, recs in classified.items():
            kept = []
            for r in recs:
                u = r["url"]
                if not is_mouser(u):
                    mouser_filter_log["dropped_out_of_scope"].append({
                        "category": cat, "url": u,
                        "note": "hosted outside Mouser-owned domains - excluded by "
                                "Mouser-only scope",
                    })
                elif cat != "self_page" and same_part_product_url(u, mpn):
                    mouser_filter_log["dropped_mirror_duplicates"].append({
                        "category": cat, "url": u,
                        "note": "regional mirror / locale variant of the same product "
                                "page (duplicate of the canonical URL)",
                    })
                else:
                    kept.append(r)
            classified[cat] = kept
        _log(f"mouser-only filter: dropped {len(mouser_filter_log['dropped_out_of_scope'])} "
             f"out-of-scope URL(s), {len(mouser_filter_log['dropped_mirror_duplicates'])} "
             f"mirror duplicate(s)")

    # [F] Verification: HEAD/range, then browser navigation for ambiguous cases --
    # (skipped entirely when SKIP_VERIFICATION=True - every classified/found link is
    #  reported as-is, with no reachability check and no "unreachable" filtering)
    verification = {}
    browser_checks = {}
    unreachable = []
    if not SKIP_VERIFICATION:
        verify_targets, seen_v = [], set()
        for cat, recs in classified.items():
            if cat == "self_page":
                continue
            for r in recs:
                if r["identity"] not in seen_v:
                    seen_v.add(r["identity"])
                    verify_targets.append(r["url"])
        verify_targets = verify_targets[:150]

        if verify_targets:
            _log(f"verifying {len(verify_targets)} document URLs (HEAD + 4KB ranged GET) ...")
            verification = verify_all(verify_targets, render.get("user_agent"), base)
            for r in classified.values():
                for rec in r:
                    if rec["url"] in verification:
                        rec["verification"] = verification[rec["url"]]
            amb = [u for u in verify_targets if ambiguous(verification.get(u))]
            _log(f"ambiguous/failed results: {len(amb)} -> browser-navigation re-check "
                 f"(cap {BROWSER_VERIFY_CAP})")
            if amb and not access_ok:
                _log("   skipping browser re-check (page is blocked; it would be blocked too)")
            elif amb:
                browser_checks = browser_verify(amb, referer=base)
                for r in classified.values():
                    for rec in r:
                        bv = browser_checks.get(rec["url"])
                        if bv:
                            rec["verification"]["browser_check"] = bv
                            if bv.get("ok"):
                                rec["verification"]["ok"] = True
                                rec["verification"]["status"] = bv.get("status")
                                rec["verification"]["content_type"] = bv.get("content_type")

        unreachable = [
            f"HTTP {rec['verification'].get('status') or rec['verification'].get('error')}: {rec['url']}"
            for recs in classified.values() for rec in recs
            if rec.get("verification") and not rec["verification"].get("ok")]
    else:
        _log("verification skipped (SKIP_VERIFICATION=True) - reporting all found links as-is")

    # [G] Build the report document -------------------------------------------
    by_source, by_host = Counter(), Counter()
    for rec in records:
        for s in rec["sources"]:
            by_source[s] += 1
        by_host[urlparse(rec["url"]).netloc.lower()] += 1

    cat_lookup = {r["identity"]: cat for cat, recs in classified.items() for r in recs}
    links_annotated = [{
        "url": rec["url"], "anchors": rec["anchors"], "hints": rec["hints"],
        "sources": rec["sources"], "mouser_hosted": is_mouser(rec["url"]),
        "category": cat_lookup.get(rec["identity"], "uncategorized"),
    } for rec in records]

    doc = {
        "schema": "mouser-full-page-link-harvest/v1",
        "scope": "Mouser-hosted resources only" if MOUSER_ONLY else "all hosts",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": {
            "requested_url": render["requested_url"],
            "final_url": render.get("final_url"),
            "canonical": render.get("canonical"),
            "http_status": render.get("http_status"),
            "title": render.get("title"),
            "user_agent": render.get("user_agent"),
            "render_engine": "camoufox+playwright (headless, humanized, geoip, UBO excluded)",
            "access_status": access_status,
            "recovered_via": render.get("recovered_via"),
            "harvested_at": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": round(time.time() - t0, 1),
        },
        "part_identification": ident,
        "page_text": page_text,
        "document_sections": render.get("doc_panels"),
        "page_text_stats": {"chars": len(page_text), "storage": "full"},
        "section_coverage": section_presence(page_text),
        "link_inventory": {
            "total_unique": len(records),
            "by_source": dict(by_source),
            "by_host": dict(by_host.most_common(25)),
            "links": links_annotated,
        },
        "classified_documents": classified,
        "mouser_only_filter": mouser_filter_log,
        "attempt_log": attempt_log,
        "fallback": {
            "sitemap": sitemap,
            "web_discovery_mouser_only": web_discovered,
            "mouser_api": api_result,
        },
        "failures": {
            "render_errors": render.get("errors", []),
            "block_evidence": render.get("block_evidence", []),
            "failure_kind": render.get("failure_kind"),
            "verification_unreachable": unreachable,
        },
    }

    for cat, recs in classified.items():
        if recs and cat != "self_page":
            if SKIP_VERIFICATION:
                _log(f"   {cat}: {len(recs)} doc(s)")
            else:
                ok = sum(1 for r in recs if (r.get("verification") or {}).get("ok"))
                _log(f"   {cat}: {len(recs)} doc(s), {ok} verified reachable")

    return doc


print("harvest_one(part_url, part_hint=None, manufacturer_hint=None) ready.")


# [9/10] Markdown report builder ------------------------------------------------
def build_markdown(doc):
    """Readable Markdown summary of the harvest (Mouser-only scope)."""
    src = doc["source"]
    ident = doc["part_identification"]
    lines = []
    lines.append(f"# Mouser Full Page Link Harvest — {ident.get('mpn') or 'Unknown Part'}")
    lines.append("")
    lines.append(f"- **Harvested at (UTC):** {src['harvested_at']}")
    lines.append(f"- **Requested URL:** {src['requested_url']}")
    lines.append(f"- **Final rendered URL:** {src['final_url']}")
    if src.get("canonical"):
        lines.append(f"- **Canonical URL:** {src['canonical']}")
    lines.append("- **Render engine:** Camoufox (anti-detect Firefox) + Playwright, "
                 "full JS render")
    lines.append(f"- **HTTP status:** {src.get('http_status')}")
    lines.append(f"- **Access status:** {src['access_status']}")
    lines.append(f"- **Scope:** {doc.get('scope')}")
    if src.get("recovered_via"):
        lines.append(f"- **Recovered via:** {src['recovered_via']}")
    lines.append(f"- **Page text captured:** {doc['page_text_stats']['chars']:,} characters")
    lines.append(f"- **Unique links collected:** {doc['link_inventory']['total_unique']}")
    lines.append("")
    lines.append("## Part Identification")
    lines.append("")
    lines.append(f"- **Manufacturer:** {ident.get('manufacturer') or 'not detected'}")
    lines.append(f"- **Manufacturer Part Number:** {ident.get('mpn') or 'not detected'}")
    if ident.get("description"):
        lines.append(f"- **Description:** {ident['description']}")
    lines.append(f"- **Identification method:** {ident.get('method') or 'none'}")
    lines.append("")
    lines.append("## Document Discovery Summary")
    lines.append("")
    lines.append("| Category | Documents | Verified reachable | Unreachable/unverified |")
    lines.append("|---|---|---|---|")
    for cat, recs in doc["classified_documents"].items():
        if cat == "self_page" or not recs:
            continue
        ok = sum(1 for r in recs if (r.get("verification") or {}).get("ok"))
        bad = len(recs) - ok
        lines.append(f"| {cat} | {len(recs)} | {ok} | {bad} |")
    zero_cats = [cat for cat, recs in doc["classified_documents"].items()
                 if cat != "self_page" and not recs]
    if zero_cats and src["access_status"] != "OK":
        lines.append("")
        lines.append("**Categories not checked (page was blocked, so absence of documents here is NOT "
                     "evidence that none exist):** " + ", ".join(zero_cats))
        lines.append("")
    elif zero_cats:
        lines.append("")
        lines.append(f"Categories with **no documents exposed on this page**: "
                     f"{', '.join(zero_cats)}. These document types are not published on "
                     "the Mouser part page for this part (e.g. no EOL/PDN exists for an "
                     "active part). Reported honestly — absence on the page is not an "
                     "access failure.")
    lines.append("")
    mfilter = doc.get("mouser_only_filter") or {}
    oos = mfilter.get("dropped_out_of_scope") or []
    mirrors = mfilter.get("dropped_mirror_duplicates") or []
    dropped_cats = {d["category"] for d in oos} | {d["category"] for d in mirrors}
    if oos or mirrors:
        lines.append("## Mouser-Only Scope Filter")
        lines.append("")
        if oos:
            lines.append("Discovered on the page but **not hosted on a Mouser-owned "
                         "domain**; excluded from the documents list by the Mouser-only "
                         "scope policy:")
            lines.append("")
            for d in oos:
                lines.append(f"- [{d['category']}] {d['url']} — {d['note']}")
            lines.append("")
        if mirrors:
            lines.append("Same-part product pages on Mouser country mirrors / locale "
                         "variants (Mouser-owned but duplicates of the canonical page) "
                         "were removed from the documents list:")
            lines.append("")
            for d in mirrors[:20]:
                lines.append(f"- [{d['category']}] {d['url']}")
            if len(mirrors) > 20:
                lines.append(f"- ... and {len(mirrors) - 20} more (see JSON filter log)")
            lines.append("")
    if zero_cats and src["access_status"] != "OK":
        lines.append("")
        lines.append("**Categories not checked (page was blocked, so absence of documents here is NOT "
                     "evidence that none exist):** " + ", ".join(zero_cats))
        lines.append("")
    elif zero_cats:
        lines.append("")
        lines.append(f"Categories with **no Mouser-hosted documents on this page**: "
                     f"{', '.join(c for c in zero_cats if c not in dropped_cats)}. "
                     "These document types are not published on the Mouser part page for "
                     "this part (e.g. no EOL/PDN exists for an active part). Reported "
                     "honestly — absence on the page is not an access failure. Categories "
                     "that only lost entries to the scope filter are listed above.")
        lines.append("")
    for cat, recs in doc["classified_documents"].items():
        if cat == "self_page" or not recs:
            continue
        lines.append(f"## {cat.replace('_', ' ').title()} ({len(recs)})")
        lines.append("")
        for i, r in enumerate(recs, 1):
            label = (r["anchors"][0] if r["anchors"]
                     else (r["hints"][0] if r["hints"] else "document"))[:80]
            v = r.get("verification") or {}
            status = v.get("status") if v.get("status") is not None else "n/a"
            ct = (v.get("content_type") or "")[:40]
            bmark = ""
            bc = v.get("browser_check") or {}
            if bc.get("ok"):
                bmark = f" (browser-verified: HTTP {bc.get('status')}, " \
                        f"{(bc.get('content_type') or '')[:30]})"
            lines.append(f"{i}. **{label}** — HTTP {status} — {ct}{bmark}")
            lines.append(f"   {r['url']}")
        lines.append("")
    lines.append("## Required Section Coverage (from PAGE_TEXT)")
    lines.append("")
    for kw, present in doc["section_coverage"].items():
        lines.append(f"- {'[x]' if present else '[ ]'} {kw}")
    lines.append("")
    lines.append("## Link Inventory Statistics")
    lines.append("")
    inv = doc["link_inventory"]
    mouser_n = sum(1 for l in inv["links"] if l.get("mouser_hosted"))
    lines.append(f"- Total unique URLs: **{inv['total_unique']}** "
                 f"({mouser_n} on mouser.com hosts)")
    lines.append(f"- By discovery source: {json.dumps(inv['by_source'])}")
    top_hosts = ", ".join(f"{h} ({n})" for h, n in list(inv["by_host"].items())[:10])
    lines.append(f"- Top hosts: {top_hosts}")
    lines.append("")
    fails = doc["failures"]
    lines.append("## Failures & Caveats")
    lines.append("")
    if fails.get("failure_kind"):
        lines.append(f"**Failure kind:** {fails['failure_kind']}")
    if fails["render_errors"]:
        lines.append("**Render errors:**")
        for e in fails["render_errors"]:
            lines.append(f"- {e}")
    if fails["block_evidence"]:
        lines.append("**Block/challenge evidence:**")
        for e in fails["block_evidence"]:
            lines.append(f"- {e}")
    if fails["verification_unreachable"]:
        lines.append("**Unreachable/unverified document URLs (may need a browser "
                     "session):**")
        for u in fails["verification_unreachable"][:30]:
            lines.append(f"- {u}")
    if not (fails["render_errors"] or fails["block_evidence"]
            or fails["verification_unreachable"]):
        lines.append("No failures recorded. Full page rendered and all classified "
                     "document URLs verified.")
    lines.append("")
    if doc.get("attempt_log"):
        lines.append("## Access Attempt Log")
        lines.append("")
        for a in doc["attempt_log"]:
            lines.append(f"- attempt {a['attempt']}: HTTP {a['http_status']}, "
                         f"{a['page_text_chars']} chars, blocked={a['blocked']}")
        lines.append("")
    fb = doc.get("fallback") or {}
    if fb.get("sitemap") or fb.get("web_discovery_mouser_only") or fb.get("mouser_api"):
        lines.append("## Fallback Route Record")
        lines.append("")
        sf = fb.get("sitemap")
        if sf:
            lines.append(f"- robots.txt HTTP status: {sf.get('robots_status')}")
            lines.append(f"- Sitemaps declared: {sf.get('sitemaps_declared')}")
            for n in sf.get("notes", []):
                lines.append(f"- note: {n}")
        ar = fb.get("mouser_api")
        if ar:
            lines.append(f"- Mouser Search API: ok={ar.get('ok')}, errors={ar.get('errors')}")
            mp = ar.get("matched_part") or {}
            for k in ("MouserPartNumber", "LifecycleStatus", "ROHSStatus", "DataSheetUrl"):
                if mp.get(k):
                    lines.append(f"  - {k}: {mp[k]}")
        wd = fb.get("web_discovery_mouser_only") or []
        if wd:
            lines.append(f"- Web discovery (Mouser-hosted only): {len(wd)} URL(s)")
            for u in wd[:10]:
                lines.append(f"  - {u}")
        lines.append("")
    lines.append("Full PAGE_TEXT (complete visible text of the rendered page) is stored "
                 "in the companion JSON file under `page_text`.")
    return "\n".join(lines)


print("build_markdown(doc) ready.")



# ==== Document table mapper: Manufacturer | Doc Type | Doc Link | Part Number ====
import csv as _dm_csv
import json as _dm_json
import re as _dm_re
from urllib.parse import urlparse as _dm_urlparse, urldefrag as _dm_urldefrag

# True  = also list documents hosted by the manufacturer (e.g. vishay.com datasheet PDF
#         that Mouser hot-links from its "Documents" section)
# False = keep only mouser.com-hosted documents
INCLUDE_EXTERNAL_DOCS = True

# How many links to keep per (part, Doc Type) on the main sheet.
#   1    = one best link per document type (default)
#   None = keep every distinct link
# Everything found is always kept on the "All Links" sheet.
DOC_LINKS_PER_TYPE = 1
HYPERLINK_MAX_ROWS = 20000     # above this many rows, skip per-cell hyperlinks (huge xlsx = very slow)

# Output is DOCUMENTS ONLY by default. Turn these on for extra sheets/files:
WRITE_ALTERNATES_SHEET = False    # every distinct document link, ranked
WRITE_EVERY_LINK_SHEET = False    # every link on the page (nav, images, trackers...) + name

_DM_DOC_EXT = (".pdf", ".zip", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".stp", ".step")
_DM_NON_DOC_EXT = (".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff",
                   ".woff2", ".ttf", ".map", ".json", ".xml", ".txt", ".php")
_DM_DOC_PATHS = ("/datasheet/", "/datasheets/", "/pcn/", "/pdn/", "/eol/", "/documents/",
                 "/document/", "/docs/", "/pdf/", "/technical-documents/")
_DM_TYPE_RULES = [
    ("Datasheet", r"datasheet|data[-\s_]sheet"),
    ("PCN", r"\bpcn\b|product[-\s]change[-\s]notif"),
    ("PDN / EOL", r"\bpdn\b|\beol\b|end[-\s]of[-\s]life|discontinu|last[-\s]time[-\s]buy"),
    ("FAQ", r"\bfaqs?\b|frequently[-\s]asked"),
    ("Environmental / Compliance", r"rohs|\breach\b|conflict[-\s]minerals?|material[-\s]declaration|"
                                   r"environmental|\bsvhc\b|proposition[-\s]65|\bmsds\b|\bsds\b|compliance"),
    ("Reliability / Qualification", r"reliabilit|qualific|\bmtbf\b"),
    ("Application / Technical Note", r"application[-\s]note|\bapp[-\s]note|technical[-\s](?:document|brief|paper|note)|"
                                     r"white[-\s]paper|user[-\s](?:manual|guide)|reference[-\s]manual"),
    ("Safety / Regulatory", r"safety|regulatory|certificat"),
    ("CAD / Model", r"\bstep\b|\bstp\b|ecad|footprint|3d[-\s]model|symbol"),
]
_DM_TRACKER_HINTS = ("doubleclick", "googletagmanager", "google-analytics", "facebook", "licdn",
                     "fullstory", "cookielaw", "anteriad", "adentifi", "niceincontact",
                     "lucidworks", "schema.org", "trustguard")
_DM_MOUSER_RE = _dm_re.compile(r"^(?:[a-z0-9-]+\.)*mouser\.[a-z]{2,3}(?:\.[a-z]{2,3})?$")


def _dm_clean(u):
    """Strip regex-sweep debris (e.g. url + '","event_product_category":...')."""
    u = str(u or "").strip().replace("\\/", "/")
    u = _dm_re.split(r'["\'<>\s\\]', u, maxsplit=1)[0]
    return _dm_urldefrag(u)[0].rstrip(".,;:)")


def _dm_type(url, anchors, hints):
    path = _dm_urlparse(url).path.lower()
    hay = " | ".join([*(anchors or []), *(hints or []), path]).lower()
    for label, pat in _DM_TYPE_RULES:
        if _dm_re.search(pat, hay):
            return label
    return "Other Document"


def _dm_is_doc(url):
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    if p.scheme not in ("http", "https") or not host:
        return False
    if any(t in host for t in _DM_TRACKER_HINTS):
        return False
    if path.endswith(_DM_NON_DOC_EXT) or "/productdetail/" in path:
        return False
    if not (path.endswith(_DM_DOC_EXT) or any(x in path for x in _DM_DOC_PATHS)):
        return False
    if not INCLUDE_EXTERNAL_DOCS and not _DM_MOUSER_RE.match(host):
        return False
    return True


def _dm_norm(x):
    return _dm_re.sub(r"[^a-z0-9]", "", str(x or "").lower())


def _dm_name(l, url):
    """Human-readable name for a link: anchor text > nearby heading > file/path name."""
    for cand in list(l.get("anchors") or []) + list(l.get("hints") or []):
        c = _dm_re.sub(r"\s+", " ", str(cand or "")).strip()
        if c:
            return c[:150]
    p = _dm_urlparse(url)
    last = _dm_re.sub(r"\.[A-Za-z0-9]{2,5}$", "", (p.path or "").rstrip("/").rsplit("/", 1)[-1])
    try:
        from urllib.parse import unquote
        last = unquote(last)
    except Exception:
        pass
    return (last.replace("-", " ").replace("_", " ").strip() or p.netloc)[:150]


def _dm_kind(url):
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    if any(t in host for t in _DM_TRACKER_HINTS):
        return "Tracker / third-party"
    if path.endswith(_DM_NON_DOC_EXT):
        return "Asset (image/script/style)"
    if "/productdetail/" in path:
        return "Product page (mirror/locale)" if _DM_MOUSER_RE.match(host) else "Product page"
    if _dm_is_doc(url) or path.endswith(_DM_DOC_EXT) or any(x in path for x in _DM_DOC_PATHS):
        return "Document"
    return "Mouser page" if _DM_MOUSER_RE.match(host) else "External page"


def _dm_score(url, anchors, hints, mpn):
    """Higher = better link to represent the document."""
    p = _dm_urlparse(url)
    host, path = (p.netloc or "").lower(), (p.path or "").lower()
    anchor = " ".join(anchors or [])
    sc = 0
    if anchor.strip():
        sc += 2                                   # the page itself labels this link
    if mpn and _dm_norm(mpn) in _dm_norm(anchor + path):
        sc += 3                                   # names this exact part
    if _DM_MOUSER_RE.match(host):
        sc += 2                                   # Mouser-hosted
    if path.endswith(".pdf"):
        sc += 1
    if p.query:
        sc -= 1
    return sc


def _dm_panel_rows(doc, mfr, mpn):
    """Rows straight from the page's own Documents panel (real section names)."""
    ds = doc.get("document_sections") or {}
    rows, seen = [], set()
    for r in ds.get("rows") or []:
        url = _dm_clean(r.get("url"))
        if not url:
            continue
        key = (r.get("panel"), r.get("section"), url)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"Manufacturer": mfr, "Panel": r.get("panel") or "",
                     "Section": r.get("section") or "",
                     "Name": r.get("name") or _dm_name({}, url),
                     "Doc Link": url, "Part Number": mpn})
    return rows


def build_doc_rows(doc, per_type=None):
    """Return (main_rows, alt_rows).

    If the page's Documents panel was captured (doc["document_sections"]), main_rows
    is EVERY link in that panel, in page order, with Mouser's own section name
    (Datasheet / Models / Specification Sheets / Technical Resources / ...).
    Otherwise falls back to inferring document links (best `per_type` per type).
    """
    per_type = DOC_LINKS_PER_TYPE if per_type is None else per_type
    ident = doc.get("part_identification") or {}
    mfr, mpn = ident.get("manufacturer") or "", ident.get("mpn") or ""
    panel = _dm_panel_rows(doc, mfr, mpn)
    if panel:
        return panel, [{**r, "Rank": "", "Score": "", "On Main Sheet": "Yes"} for r in panel]
    groups = {}                                   # same file on another host/locale = 1 doc
    for l in (doc.get("link_inventory") or {}).get("links", []):
        url = _dm_clean(l.get("url"))
        if not url or not _dm_is_doc(url):
            continue
        fname = _dm_urlparse(url).path.rsplit("/", 1)[-1].lower() or url.lower()
        groups.setdefault(fname, []).append((
            _dm_score(url, l.get("anchors"), l.get("hints"), mpn), url,
            _dm_type(url, l.get("anchors"), l.get("hints")), _dm_name(l, url)))
    by_type = {}
    for fname, cands in groups.items():
        sc, url, _t, name = max(cands, key=lambda c: (c[0], -len(c[1])))
        specific = [c[2] for c in cands if c[2] != "Other Document"]
        dtype = specific[0] if specific else "Other Document"   # most specific label wins
        by_type.setdefault(dtype, []).append((sc, url, name))
    order = {"Datasheet": 0, "PCN": 1, "PDN / EOL": 2}
    main, allr = [], []
    for dtype in sorted(by_type, key=lambda t: (order.get(t, 9), t)):
        ranked = sorted(by_type[dtype], key=lambda x: (-x[0], len(x[1]), x[1]))
        for n, (sc, url, name) in enumerate(ranked):
            chosen = per_type is None or n < per_type
            base = {"Manufacturer": mfr, "Panel": "(inferred)", "Section": dtype, "Name": name,
                    "Doc Link": url, "Part Number": mpn}
            if chosen:
                main.append(base)
            allr.append({**base, "Rank": n + 1, "Score": sc,
                         "On Main Sheet": "Yes" if chosen else "No"})
    if not main:
        st = (doc.get("source") or {}).get("access_status") or ""
        label = ("NO DOCUMENTS FOUND" if st == "OK" else
                 "PAGE NOT FOUND (HTTP 404/410)" if st.startswith("PAGE NOT FOUND") else
                 "NOT RETRIEVED (ACCESS FAILED)")
        ph = {"Manufacturer": mfr, "Panel": "", "Section": label, "Name": "", "Doc Link": "", "Part Number": mpn}
        main.append(ph)
        allr.append({**ph, "Rank": "", "Score": "", "On Main Sheet": "Yes"})
    return main, allr


def build_all_links(doc):
    """EVERY unique link found on the page (no filtering), each with a name."""
    ident = doc.get("part_identification") or {}
    mfr, mpn = ident.get("manufacturer") or "", ident.get("mpn") or ""
    rows, seen = [], set()
    for l in (doc.get("link_inventory") or {}).get("links", []):
        url = _dm_clean(l.get("url"))
        if not url or url in seen:
            continue
        seen.add(url)
        kind = _dm_kind(url)
        rows.append({"Manufacturer": mfr, "Part Number": mpn, "Name": _dm_name(l, url),
                     "Link": url, "Link Kind": kind,
                     "Doc Type": _dm_type(url, l.get("anchors"), l.get("hints")) if kind == "Document" else "",
                     "Found Via": ", ".join(l.get("sources") or [])})
    return rows


def write_document_table(docs, out_dir, extra_rows=None, stem="mouser_documents"):
    """Write <stem>.xlsx (sheets: Documents, Doc Alternates, Every Link Found),
    <stem>.csv (Documents) and <stem>_every_link.csv."""
    import os
    import pandas as pd
    cols = ["Manufacturer", "Panel", "Section", "Name", "Doc Link", "Part Number"]
    alt_cols = cols + ["Rank", "Score", "On Main Sheet"]
    link_cols = ["Manufacturer", "Part Number", "Name", "Link", "Link Kind", "Doc Type", "Found Via"]
    rows, allrows, linkrows = [], [], []
    for d in docs:
        m, a = build_doc_rows(d)
        rows += m
        allrows += a
        linkrows += build_all_links(d)
    for r in (extra_rows or []):
        rows.append(r)
        allrows.append({**r, "Rank": "", "Score": "", "On Main Sheet": "Yes"})
    frames = {"Documents": pd.DataFrame(rows, columns=cols).fillna("")}
    if WRITE_ALTERNATES_SHEET:
        frames["Doc Alternates"] = pd.DataFrame(allrows, columns=alt_cols).fillna("")
    if WRITE_EVERY_LINK_SHEET:
        frames["Every Link Found"] = pd.DataFrame(linkrows, columns=link_cols).fillna("")
    os.makedirs(out_dir, exist_ok=True)
    xlsx, csvp = os.path.join(out_dir, stem + ".xlsx"), os.path.join(out_dir, stem + ".csv")
    frames["Documents"].to_csv(csvp, index=False, encoding="utf-8-sig")
    if WRITE_EVERY_LINK_SHEET:
        frames["Every Link Found"].to_csv(os.path.join(out_dir, stem + "_every_link.csv"),
                                          index=False, encoding="utf-8-sig")
    widths = {"Manufacturer": 22, "Panel": 24, "Section": 28, "Part Number": 24, "Doc Type": 28, "Name": 48, "Doc Link": 90,
              "Link": 90, "Link Kind": 26, "Found Via": 22, "Rank": 7, "Score": 7, "On Main Sheet": 14}
    with pd.ExcelWriter(xlsx, engine="openpyxl") as xw:
        for name, frame in frames.items():
            frame.to_excel(xw, index=False, sheet_name=name)
            ws = xw.sheets[name]
            for idx, col in enumerate(frame.columns, 1):
                ws.column_dimensions[ws.cell(row=1, column=idx).column_letter].width = widths.get(col, 20)
                if col in ("Doc Link", "Link") and len(frame) <= HYPERLINK_MAX_ROWS:
                    for r in range(2, ws.max_row + 1):
                        c = ws.cell(row=r, column=idx)
                        if c.value and str(c.value).startswith("http") and len(str(c.value)) < 2000:
                            c.hyperlink = c.value
                            c.style = "Hyperlink"
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
    print(f"Documents written: {xlsx}  ({len(frames['Documents'])} row(s))  + {os.path.basename(csvp)}")
    return frames["Documents"]

# ---- input: spreadsheet in the same folder as this script ---------------------
import glob

def find_input_file():
    if LOCAL_URL_FILE and os.path.exists(LOCAL_URL_FILE):
        return LOCAL_URL_FILE
    for pat in ("urls.xlsx", "urls.xls", "urls.csv", "U.xlsx", "mo.xlsx"):
        p = os.path.join(BASE_DIR, pat)
        if os.path.exists(p):
            return p
    others = [f for f in sorted(glob.glob(os.path.join(BASE_DIR, "*.xlsx"))
                                + glob.glob(os.path.join(BASE_DIR, "*.xls"))
                                + glob.glob(os.path.join(BASE_DIR, "*.csv")))
              if "mouser_harvest" not in f and not os.path.basename(f).startswith("~$")]
    return others[0] if others else None

URL_LIST = []
_fname = find_input_file()
if _fname:
    print("Reading URL list from:", _fname)
    _df = (pd.read_csv(_fname) if _fname.lower().endswith(".csv") else pd.read_excel(_fname))
    _df = _df.dropna(how="all")
    url_col = _pick_col(_df, ["url", "urls", "part_url", "part url", "mouser_url",
                               "mouser url", "link"]) or _df.columns[0]
    hint_col = _pick_col(_df, ["part_hint", "part hint", "part", "mpn", "part_number", "part number"])
    mfr_col = _pick_col(_df, ["manufacturer_hint", "manufacturer hint", "manufacturer", "mfr", "brand"])
    seen_urls = set()
    for _, row in _df.iterrows():
        u_raw = _cell(row, url_col)
        if not u_raw or not u_raw.lower().startswith("http"):
            continue
        u = _fix_double_encoded_qs(u_raw)
        if u != u_raw:
            print(f"  [qs fix] double-encoded token corrected: {u_raw[:90]}")
        if u in seen_urls:
            continue
        seen_urls.add(u)
        _sh, _mh = _slug_hints(u)
        URL_LIST.append({"url": u, "part_hint": _cell(row, hint_col) or _sh,
                         "manufacturer_hint": _cell(row, mfr_col) or _mh})
    print(f"Loaded {len(URL_LIST)} unique URL(s) (URL column: '{url_col}').")
else:
    print("No .xlsx/.csv found in", BASE_DIR, "- using the demo PART_URL.")
    URL_LIST = [{"url": _fix_double_encoded_qs(PART_URL), "part_hint": PART_HINT,
                 "manufacturer_hint": MANUFACTURER_HINT}]
for _i, _item in enumerate(URL_LIST[:15], 1):
    print(f"  {_i}. {_item['url']}")
if len(URL_LIST) > 15:
    print(f"  ... and {len(URL_LIST) - 15} more")


# [10/10] Batch crawl — run the harvester for every URL in the uploaded list,
#         write per-part JSON + Markdown, build a summary spreadsheet, then
#         zip and download everything in one go.
import json
import os
import re
import shutil
import time

import pandas as pd

os.makedirs(OUT_DIR, exist_ok=True)

_delay = globals().get("INTER_PART_DELAY_S", 5)  # polite pause between parts

summary_rows = []
all_docs = []

for i, item in enumerate(URL_LIST, 1):
    url = item["url"]
    hint = item.get("part_hint")
    mfr_hint = item.get("manufacturer_hint")

    print("=" * 100)
    print(f"[{i}/{len(URL_LIST)}] {url}")
    print("=" * 100)

    try:
        doc = harvest_one(url, part_hint=hint, manufacturer_hint=mfr_hint)
    except Exception as exc:
        print(f"!! harvest failed for {url}: {exc}")
        summary_rows.append({
            "part_url": url, "mpn": hint or "", "manufacturer": mfr_hint or "",
            "access_status": f"EXCEPTION: {exc}", "http_status": None,
            "total_links": None, "documents_found": None, "documents_verified": None,
            "json_file": None, "md_file": None,
        })
        if i < len(URL_LIST) and _delay:
            time.sleep(_delay)
        continue

    all_docs.append(doc)
    ident = doc["part_identification"]
    mpn = ident.get("mpn") or hint or f"part_{i}"
    _safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(mpn)).strip("_") or f"part_{i}"

    json_path = os.path.join(OUT_DIR, f"mouser_docs_{_safe}.json")
    md_path = os.path.join(OUT_DIR, f"mouser_docs_{_safe}.md")
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=2)
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write(build_markdown(doc))

    docs_found = sum(len(recs) for cat, recs in doc["classified_documents"].items()
                      if cat != "self_page")
    docs_verified = sum(
        1 for recs in doc["classified_documents"].values() for r in recs
        if (r.get("verification") or {}).get("ok"))

    summary_rows.append({
        "part_url": url,
        "requested_url": doc["source"]["requested_url"],
        "final_url": doc["source"]["final_url"],
        "mpn": ident.get("mpn") or "",
        "manufacturer": ident.get("manufacturer") or "",
        "access_status": doc["source"]["access_status"],
        "http_status": doc["source"]["http_status"],
        "total_links": doc["link_inventory"]["total_unique"],
        "documents_found": docs_found,
        "documents_verified": docs_verified,
        "json_file": os.path.basename(json_path),
        "md_file": os.path.basename(md_path),
    })

    print(f"VERDICT: {doc['source']['access_status']}  documents={docs_found}"
          + ("" if SKIP_VERIFICATION else f" verified={docs_verified}"))

    if i < len(URL_LIST) and _delay:
        time.sleep(_delay)

# --- Mapped documents table: Manufacturer | Doc Type | Doc Link | Part Number ------
_extra = [{"Manufacturer": r.get("manufacturer", ""), "Panel": "", "Section": "NOT RETRIEVED (EXCEPTION)", "Name": "",
           "Doc Link": "", "Part Number": r.get("mpn", "")}
          for r in summary_rows if str(r.get("access_status", "")).startswith("EXCEPTION")]
write_document_table(all_docs, OUT_DIR, extra_rows=_extra)

# --- Summary spreadsheet ------------------------------------------------------
summary_df = pd.DataFrame(summary_rows)
summary_path = os.path.join(OUT_DIR, "mouser_harvest_summary.xlsx")
summary_df.to_excel(summary_path, index=False)
print()
print(f"Summary spreadsheet written: {summary_path}  ({len(summary_df)} row(s))")
try:
    from IPython.display import display
    display(summary_df)
except Exception:
    print(summary_df.to_string(index=False))

# --- Zip every deliverable and download -----------------------------------------
zip_base = os.path.join(os.path.dirname(OUT_DIR), "mouser_harvest_results")
zip_path = shutil.make_archive(zip_base, "zip", OUT_DIR)
print("Zipped output:", zip_path)

if IN_COLAB:
    try:
        from google.colab import files
        files.download(zip_path)
    except Exception as exc:
        print("Auto-download skipped:", exc)
else:
    print("Local run - results are in", OUT_DIR)


print("\nDone. Results folder:", OUT_DIR)
